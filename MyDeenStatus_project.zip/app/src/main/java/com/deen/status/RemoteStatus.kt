package com.deen.status

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Calendar

/**
 * Live statuses from a Google Sheet published as CSV.
 * Header row: date,kind,arabic,text,source,theme,bg_url
 */
object RemoteStatus {
    private const val CACHE = "live_status.csv"

    fun loadCache(ctx: Context): List<Status>? {
        val f = File(ctx.filesDir, CACHE)
        return if (f.exists()) parse(f.readText()).ifEmpty { null } else null
    }

    /** Blocking: call off the main thread. Returns null if offline / bad link. */
    fun fetch(ctx: Context, url: String): List<Status>? = try {
        val body = httpGet(url).toString(Charsets.UTF_8)
        val list = parse(body)
        if (list.isNotEmpty()) File(ctx.filesDir, CACHE).writeText(body)
        list
    } catch (e: Exception) { null }

    /** Today's dated row, otherwise rotate through undated rows by day-of-year. */
    fun pickIndex(list: List<Status>): Int {
        if (list.isEmpty()) return 0
        val c = Calendar.getInstance()
        val iso = "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        val exact = list.indexOfFirst { it.date == iso }
        return if (exact >= 0) exact else c.get(Calendar.DAY_OF_YEAR) % list.size
    }

    /** Blocking. Downloads + caches a background image; null on failure. */
    fun background(ctx: Context, url: String): Bitmap? {
        if (!url.startsWith("http")) return null
        val dir = File(ctx.cacheDir, "live_bg").apply { mkdirs() }
        val f = File(dir, sha1(url) + ".img")
        return try {
            if (!f.exists()) f.writeBytes(httpGet(directLink(url)))
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: Exception) { f.delete(); null }
    }

    private fun directLink(u: String): String {
        val id = Regex("/d/([A-Za-z0-9_-]{10,})").find(u)?.groupValues?.get(1)
            ?: Regex("[?&]id=([A-Za-z0-9_-]{10,})").find(u)?.groupValues?.get(1)
        return if (u.contains("drive.google.com") && id != null)
            "https://drive.google.com/uc?export=download&id=$id" else u
    }

    private fun httpGet(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 20000
        c.instanceFollowRedirects = true
        try {
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    private fun sha1(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    internal fun parse(csv: String): List<Status> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < csv.length) {
            val ch = csv[i]
            if (quoted && ch == '"' && i + 1 < csv.length && csv[i + 1] == '"') {
                cell.append('"'); i++
            } else if (ch == '"') {
                quoted = !quoted
            } else if (!quoted && ch == ',') {
                row.add(cell.toString()); cell.setLength(0)
            } else if (!quoted && (ch == '\n' || ch == '\r')) {
                if (ch == '\r' && i + 1 < csv.length && csv[i + 1] == '\n') i++
                row.add(cell.toString()); cell.setLength(0)
                if (row.any { it.isNotBlank() }) rows.add(row)
                row = ArrayList()
            } else {
                cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString()); rows.add(row) }
        if (rows.size < 2) return emptyList()
        val h = rows[0].map { it.trim().lowercase().removePrefix("﻿") }
        fun col(r: List<String>, n: String): String {
            val k = h.indexOf(n)
            return if (k >= 0 && k < r.size) r[k].trim() else ""
        }
        return rows.drop(1).map {
            Status(
                kind = col(it, "kind"), arabic = col(it, "arabic"), text = col(it, "text"),
                source = col(it, "source"), theme = col(it, "theme"), bgUrl = col(it, "bg_url"),
                date = col(it, "date")
            )
        }.filter { it.arabic.isNotBlank() || it.text.isNotBlank() }
    }
}
