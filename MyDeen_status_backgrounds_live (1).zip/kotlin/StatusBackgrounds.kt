package com.example.mydeen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.BitmapFactory
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.annotation.DrawableRes

/**
 * Themed backgrounds for the Daily Islamic Status image.
 * Drop the status_bg_*.jpg files into app/src/main/res/drawable-nodpi/ first.
 */
enum class StatusTheme(
    val resName: String,
    val arabicColor: Int,   // colour of the Arabic text at the top
    val bodyColor: Int,     // translation / reminder text
    val accent: Int         // divider + source line
) {
    DUA("status_bg_dua",           0xFFFFE7A8.toInt(), 0xFFFFFFFF.toInt(), 0xFFE0B95A.toInt()),
    QURAN("status_bg_quran",       0xFFF6E2A0.toInt(), 0xFFFFFFFF.toInt(), 0xFFE5C36A.toInt()),
    HADITH("status_bg_hadith",     0xFF3B2410.toInt(), 0xFF2E1B0B.toInt(), 0xFF7A4D22.toInt()),
    NAMAZ("status_bg_namaz",       0xFFFFF1CF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFE3A8.toInt()),
    SABR("status_bg_sabr",         0xFFE6FBFF.toInt(), 0xFFFFFFFF.toInt(), 0xFF9EE9EE.toInt()),
    SHUKR("status_bg_shukr",       0xFF4A1F08.toInt(), 0xFF3A1706.toInt(), 0xFF7A3B10.toInt()),
    TAUBA("status_bg_tauba",       0xFFEFE5FF.toInt(), 0xFFFFFFFF.toInt(), 0xFFC9B3FF.toInt()),
    SADAQAH("status_bg_sadaqah",   0xFFFFE9C8.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD7A0.toInt()),
    FAMILY("status_bg_family",     0xFF0F3D29.toInt(), 0xFF0B2E1F.toInt(), 0xFF1F6A45.toInt()),
    DEFAULT("status_bg_default",    0xFFF1D98A.toInt(), 0xFFFFFFFF.toInt(), 0xFFD9B85A.toInt());

    @DrawableRes
    fun res(ctx: Context): Int =
        ctx.resources.getIdentifier(resName, "drawable", ctx.packageName)
}

object StatusBackgrounds {

    private fun has(text: String, vararg keys: String) = keys.any { text.contains(it) }

    /**
     * Picks the background that matches the meaning of the status.
     * @param kind optional: "ayah" | "hadith" | "dua" | "action" (whatever DailyStatus.type uses)
     */
    fun pickTheme(arabic: String, text: String, kind: String? = null): StatusTheme {
        val t = (text + " " + arabic).lowercase()
        val k = kind?.lowercase().orEmpty()
        return when {
            has(t, "tauba", "repent", "forgive", "maaf", "bakhsh", "istighfar", "astaghfir", "seek forgiveness") -> StatusTheme.TAUBA
            has(t, "shukar", "shukr", "thank", "grateful", "nemat", "ni'mat", "ungrateful") -> StatusTheme.SHUKR
            has(t, "sabr", "patien", "mushkil", "hardship", "ease", "aasani", "burden", "taqat", "bojh") -> StatusTheme.SABR
            has(t, "namaz", "salah", "prayer", "takbir", "masjid", "mosque", "wudu", "azan", "fajr", "asr") -> StatusTheme.NAMAZ
            has(t, "sadaqa", "charity", "ghareeb", "poor", "khush", "smile", "kind", "narm", "gentle", "ihsaan", "good word", "achha lafz") -> StatusTheme.SADAQAH
            has(t, "walidain", "parents", "maa baap", "rishte", "silah", "kinship", "family", "dost", "friend", "salam", "neighbo") -> StatusTheme.FAMILY
            k.contains("dua") || has(t, "ae allah", "ae mere rab", "ae hamare rab", "ae dilon", "o allah", "my lord", "our lord", "rabbana") -> StatusTheme.DUA
            k.contains("ayah") || k.contains("quran") || has(t, "quran", "ayat", "ayaat") -> StatusTheme.QURAN
            k.contains("hadith") || has(t, "prophet", "nabi", "rasul", "hadith") -> StatusTheme.HADITH
            else -> StatusTheme.DEFAULT
        }
    }

    /**
     * Renders the 1080x1920 shareable status:
     *  - themed background image
     *  - ORIGINAL Arabic at the top (shaped by Android's text engine, RTL, auto-sized)
     *  - translation / reminder below it
     *  - source (e.g. "Bukhari", "Surah Al-Baqarah 2:286") at the bottom
     */
    fun render(
        ctx: Context,
        arabic: String,
        text: String,
        source: String? = null,
        kind: String? = null,
        arabicTypeface: Typeface? = null,       // optional: ResourcesCompat.getFont(ctx, R.font.amiri_regular)
        themeOverride: StatusTheme? = null,
        remoteBackground: Bitmap? = null        // live image from RemoteStatus; null = built-in theme art
    ): Bitmap {
        val W = 1080; val H = 1920
        val theme = themeOverride ?: pickTheme(arabic, text, kind)
        val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)

        // 1) background, centre-cropped
        val bg = remoteBackground ?: BitmapFactory.decodeResource(ctx.resources, theme.res(ctx))
        if (bg != null) {
            val s = maxOf(W / bg.width.toFloat(), H / bg.height.toFloat())
            val dw = bg.width * s; val dh = bg.height * s
            val dst = android.graphics.RectF((W - dw) / 2, (H - dh) / 2, (W + dw) / 2, (H + dh) / 2)
            c.drawBitmap(bg, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            bg.recycle()
        } else c.drawColor(Color.parseColor("#073B2E"))

        val marginX = 110
        val maxW = W - marginX * 2

        // 2) Arabic at the top (auto-shrinks to fit the top ~30%)
        var arabicBottom = 220f
        if (arabic.isNotBlank()) {
            val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = theme.arabicColor
                typeface = arabicTypeface ?: Typeface.create(Typeface.SERIF, Typeface.BOLD)
                setShadowLayer(6f, 0f, 2f, 0x66000000)
            }
            var size = 84f
            var layout: StaticLayout
            do {
                p.textSize = size
                layout = StaticLayout.Builder.obtain(arabic, 0, arabic.length, p, maxW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setTextDirection(android.text.TextDirectionHeuristics.RTL)
                    .setLineSpacing(0f, 1.45f)          // Arabic needs generous leading for diacritics
                    .setIncludePad(true)
                    .build()
                size -= 4f
            } while (layout.height > H * 0.30f && size > 36f)
            c.save(); c.translate(marginX.toFloat(), 190f); layout.draw(c); c.restore()
            arabicBottom = 190f + layout.height
        }

        // 3) divider
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = theme.accent; strokeWidth = 3f }
        val dy = arabicBottom + 50f
        c.drawLine(W / 2f - 120f, dy, W / 2f + 120f, dy, line)
        c.drawCircle(W / 2f, dy, 8f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = theme.accent })

        // 4) translation / reminder
        val bp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.bodyColor
            textSize = 46f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            setShadowLayer(4f, 0f, 2f, if (theme.bodyColor == Color.WHITE) 0x88000000.toInt() else 0x33FFFFFF)
        }
        val bl = StaticLayout.Builder.obtain(text, 0, text.length, bp, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, 1.25f)
            .build()
        c.save(); c.translate(marginX.toFloat(), dy + 50f); bl.draw(c); c.restore()

        // 5) source + app tag, kept inside the sky area above the mosque silhouette
        if (!source.isNullOrBlank()) {
            val sp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = theme.accent; textSize = 36f; textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            }
            c.drawText("— $source —", W / 2f, dy + 50f + bl.height + 70f, sp)
        }
        val tag = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = theme.accent; alpha = 200; textSize = 30f; textAlign = Paint.Align.CENTER
        }
        c.drawText("My Deen", W / 2f, H - 70f, tag)
        return out
    }
}
