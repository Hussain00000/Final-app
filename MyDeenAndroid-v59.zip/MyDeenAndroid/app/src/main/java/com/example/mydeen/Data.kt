package com.example.mydeen

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class Task(val title: String, val kind: String = "check", val reminder: Boolean = true)
data class TaskGroup(val title: String, val items: List<Task>)

object Tasks {
    const val DUROOD_TITLE = "Durood — 1,000 times"
    const val TIMER_TITLE = "2.5 hours for Deen"
    const val TIMER_GOAL_MS = 150L * 60L * 1000L // 2.5 hours
    const val TIMER_GOAL_TEXT = "2:30:00"

    /** The five Namaz shown as tick boxes in the separate "Umari Qaza" section. */
    val QAZA_NAMAZ = listOf("Fajr", "Zuhr", "Asr", "Maghrib", "Isha")

    val groups: List<TaskGroup> = listOf(
        TaskGroup("Salah & Sunnah", listOf(Task("5 daily Salah with Takbir"), Task("Sunnat-e-Muakkadah"), Task("Tahajjud"), Task("Ishraq"), Task("Chasht"), Task("Awwabin"))),
        TaskGroup("Umari Qaza", QAZA_NAMAZ.map { Task("Qaza $it", reminder = false) }),
        TaskGroup("Tasbeeh", listOf(Task("3 Tasbeeh — first daily entry"), Task("3 Tasbeeh — second daily entry"), Task(DUROOD_TITLE, "counter"))),
        TaskGroup("Quran & Learning", listOf(Task("Quran — 1 Juz"), Task("Quran Taleem"), Task("Ghar ki Taleem"))),
        TaskGroup("Deen Time", listOf(Task(TIMER_TITLE, "timer"))),
        TaskGroup("Character & Community", listOf(Task("Ghar Ghar Mulakhatan", "visits")))
    )
    val all: List<Task> = groups.flatMap { it.items }

    // ---- Day-specific tasks ----
    const val ROJA = "Roja"
    const val KAHF = "Surah Kahf"
    const val SALATUT_TASBIH = "Salatul Tasbih"

    /** Tasks that only appear on some weekdays (Calendar.MONDAY = 2 ... Calendar.FRIDAY = 6). */
    private val dayOnly: Map<String, Set<Int>> = mapOf(
        ROJA to setOf(Calendar.MONDAY, Calendar.THURSDAY),
        KAHF to setOf(Calendar.FRIDAY),
        SALATUT_TASBIH to setOf(Calendar.FRIDAY)
    )

    /** Normal tasks that are replaced on Friday. */
    private val fridayRemoved = setOf("3 Tasbeeh — first daily entry", "3 Tasbeeh — second daily entry", "Quran — 1 Juz")

    /** Where each day-specific task is shown. */
    private val extrasByGroup: Map<String, List<Task>> = mapOf(
        "Salah & Sunnah" to listOf(Task(ROJA), Task(SALATUT_TASBIH)),
        "Quran & Learning" to listOf(Task(KAHF))
    )

    /** Every task that can ever appear (normal ones first so reminder ids stay the same). */
    val every: List<Task> = all + extrasByGroup.values.flatten()

    fun dayOfWeek(dayKey: String): Int {
        val cal = Calendar.getInstance()
        try {
            SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(dayKey)?.let { cal.time = it }
        } catch (e: Exception) { }
        return cal.get(Calendar.DAY_OF_WEEK)
    }

    fun appliesOn(t: Task, dow: Int): Boolean {
        val only = dayOnly[t.title]
        if (only != null) return dow in only
        if (dow == Calendar.FRIDAY && t.title in fridayRemoved) return false
        return true
    }

    /** The checklist for one date (yyyy-MM-dd): Mon/Thu add Roja; Friday swaps in Surah Kahf and Salatul Tasbih. */
    fun groupsFor(dayKey: String): List<TaskGroup> {
        val dow = dayOfWeek(dayKey)
        return groups.map { g ->
            val items = (g.items + (extrasByGroup[g.title] ?: emptyList())).filter { appliesOn(it, dow) }
            TaskGroup(g.title, items)
        }.filter { it.items.isNotEmpty() }
    }

    fun allFor(dayKey: String): List<Task> = groupsFor(dayKey).flatMap { it.items }
}

object Store {
    fun prefs(context: Context): SharedPreferences = context.getSharedPreferences("my_deen", Context.MODE_PRIVATE)

    fun dayKey(cal: Calendar = Calendar.getInstance()): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)

    // ---- Deen timer: survives the app being closed, because it stores the start time ----
    fun timerRunning(p: SharedPreferences): Boolean = p.getLong("timer_since", 0L) > 0L
    fun timerDay(p: SharedPreferences): String = p.getString("timer_day", "") ?: ""

    fun timerMillis(p: SharedPreferences, day: String, now: Long = System.currentTimeMillis()): Long {
        var ms = p.getLong("$day:timer_ms", 0L)
        val since = p.getLong("timer_since", 0L)
        if (since > 0L && timerDay(p) == day) ms += (now - since).coerceAtLeast(0L)
        return ms
    }

    fun startTimer(p: SharedPreferences, day: String, now: Long) {
        if (!timerRunning(p)) p.edit().putLong("timer_since", now).putString("timer_day", day).apply()
    }

    fun pauseTimer(p: SharedPreferences, now: Long) {
        val since = p.getLong("timer_since", 0L)
        if (since > 0L) {
            val d = timerDay(p)
            val add = (now - since).coerceAtLeast(0L)
            p.edit().putLong("$d:timer_ms", p.getLong("$d:timer_ms", 0L) + add).putLong("timer_since", 0L).apply()
        }
    }

    fun addTimerMinutes(p: SharedPreferences, day: String, minutes: Int) {
        p.edit().putLong("$day:timer_ms", p.getLong("$day:timer_ms", 0L) + minutes * 60000L).apply()
    }

    fun resetTimer(p: SharedPreferences, day: String) {
        val e = p.edit().putLong("$day:timer_ms", 0L)
        if (timerDay(p) == day) e.putLong("timer_since", 0L)
        e.apply()
    }

    fun formatHms(ms: Long): String {
        val s = ms / 1000L
        return String.format(Locale.US, "%d:%02d:%02d", s / 3600L, (s % 3600L) / 60L, s % 60L)
    }

    // ---- Completion ----
    fun isDone(p: SharedPreferences, day: String, t: Task, now: Long = System.currentTimeMillis()): Boolean = when (t.kind) {
        "counter" -> p.getInt("$day:${t.title}", 0) >= 1000
        "visits" -> p.getInt("$day:${t.title}", 0) > 0
        "timer" -> timerMillis(p, day, now) >= Tasks.TIMER_GOAL_MS
        else -> p.getBoolean("$day:${t.title}", false)
    }

    fun doneCount(p: SharedPreferences, day: String, now: Long = System.currentTimeMillis()): Int =
        Tasks.allFor(day).count { isDone(p, day, it, now) }

    fun percent(p: SharedPreferences, day: String, now: Long = System.currentTimeMillis()): Int =
        Tasks.allFor(day).let { list -> if (list.isEmpty()) 0 else doneCount(p, day, now) * 100 / list.size }

    // ---- Submit / reopen a day ----
    fun isSubmitted(p: SharedPreferences, day: String): Boolean = p.getBoolean("$day:submitted", false)

    fun submitDay(p: SharedPreferences, day: String, now: Long) {
        pauseTimer(p, now)
        p.edit().putBoolean("$day:submitted", true).apply()
    }

    fun reopenDay(p: SharedPreferences, day: String) {
        p.edit().putBoolean("$day:submitted", false).apply()
    }
}
