package com.example.mydeen

/**
 * Makes online hadith short and easy to read.
 *
 * The online hadith texts start with a long chain of narrators ("Narrated X: ... Allah's Messenger said")
 * and often continue with a story. A status picture only needs the saying itself, so these functions cut
 * the chain away and keep only the Prophet's ﷺ words. A hadith that is a conversation or a story (more than
 * one quotation) or is still long after cutting is rejected, and the caller simply tries another one.
 */
object HadithShort {
    const val MAX_ARABIC = 150
    const val MAX_ENGLISH = 170
    const val MAX_URDU = 260
    const val MAX_ROMAN_URDU = 230

    private val storyWords = Regex("\\b(narrated|asked|came to|said to|replied|we were|i was|i went|i saw)\\b", RegexOption.IGNORE_CASE)

    private fun tidy(s: String): String =
        s.replace(Regex("<[^>]*>"), " ")
            .replace('’', '\'').replace('‘', '\'')
            .replace(Regex("[\\u200E\\u200F]"), "")
            .replace(Regex("\\s+"), " ").trim()

    private fun endWithStop(s: String): String {
        val t = s.trim().trimEnd(',', ';', ':', ' ')
        return if (t.isEmpty()) t else if (t.last() == '.' || t.last() == '!' || t.last() == '?') t else "$t."
    }

    /** The English saying only, or null when this hadith is not a short single saying. */
    fun english(raw: String): String? {
        val t = tidy(raw)
        if (t.isEmpty()) return null
        val quoteChars = t.count { it == '"' || it == '“' || it == '”' }
        var matn: String? = null
        if (quoteChars == 2) {
            val m = Regex("[\"“]([^\"“”]+)[\"”]").find(t) ?: return null
            val intro = t.substring(0, m.range.first)
            val outro = t.substring(m.range.last + 1).trim(' ', '.', ',', ';', ':', ')', '(')
            if (intro.length > 170 || outro.length > 12) return null
            matn = m.groupValues[1]
        } else if (quoteChars == 0) {
            var body = t.replace(Regex("^(Narrated|It was narrated)\\s[^:]{1,110}:\\s*"), "")
            val m = Regex("(Messenger|Prophet)[^.:\"]{0,40}?\\b(said|say|saying|says)\\b\\s*[:,]?\\s*(that\\s+)?").find(body)
            if (m != null && m.range.first < 130) {
                body = body.substring(m.range.last + 1)
                matn = body
            } else if (!Regex("^(Narrated|It was narrated)").containsMatchIn(t) && t.length <= 110) {
                matn = t
            }
        }
        val s = matn?.trim() ?: return null
        if (s.length < 12 || s.length > MAX_ENGLISH) return null
        if (storyWords.containsMatchIn(s) && quoteChars == 0) return null
        if (Regex("\\(\\s*[a-z]").containsMatchIn(s) && s.length > 120) return null
        return endWithStop(s.replaceFirstChar { it.uppercase() })
    }

    /** The Arabic saying only (the part inside the quotation marks), or null. */
    fun arabic(raw: String): String? {
        val t = tidy(raw).replace('“', '"').replace('”', '"')
        if (t.isEmpty()) return null
        val quoteChars = t.count { it == '"' }
        val matn: String = when (quoteChars) {
            2 -> {
                val a = t.indexOf('"')
                val b = t.lastIndexOf('"')
                t.substring(a + 1, b)
            }
            0 -> if (t.length <= 80) t else return null
            else -> return null
        }
        val s = matn.trim().trimEnd('.', ' ')
        if (s.length < 6 || s.length > MAX_ARABIC) return null
        return s
    }

    /** The Urdu saying only as Roman Urdu, or null. Cuts the "X ne bayan kiya" chain using the Roman Urdu converter. */
    fun romanUrdu(rawUrdu: String): String? {
        val matn = RomanUrdu.hadithMatn(rawUrdu)
        if (matn.isEmpty() || matn.length > MAX_URDU) return null
        val roman = RomanUrdu.convert(matn)
        if (roman.isEmpty() || roman.length > MAX_ROMAN_URDU) return null
        return roman
    }
}
