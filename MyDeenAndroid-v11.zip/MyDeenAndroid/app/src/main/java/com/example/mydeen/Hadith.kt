package com.example.mydeen

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import java.util.Calendar

data class HadithEntry(val text: String, val source: String, val roman: String)

/** A small offline collection; one hadith is shown per day and it changes at midnight. */
object Hadith {
    val all: List<HadithEntry> = listOf(
        HadithEntry("Actions are judged by intentions, and every person will get what they intended.", "Sahih al-Bukhari 1, Sahih Muslim 1907", "Amaal ka daromadar niyyaton par hai, aur har shakhs ko wohi milta hai jis ki usne niyyat ki."),
        HadithEntry("None of you truly believes until he loves for his brother what he loves for himself.", "Sahih al-Bukhari 13, Sahih Muslim 45", "Tum mein se koi us waqt tak momin nahi ho sakta jab tak woh apne bhai ke liye wohi pasand na kare jo apne liye pasand karta hai."),
        HadithEntry("The best of you are those who learn the Qur’an and teach it.", "Sahih al-Bukhari 5027", "Tum mein behtareen woh hai jo Quran seekhe aur sikhaye."),
        HadithEntry("Whoever believes in Allah and the Last Day, let him speak good or remain silent.", "Sahih al-Bukhari 6018, Sahih Muslim 47", "Jo Allah aur aakhirat ke din par imaan rakhta hai woh achhi baat kahe ya khamosh rahe."),
        HadithEntry("The strong person is not the one who defeats others, but the one who controls himself in anger.", "Sahih al-Bukhari 6114, Sahih Muslim 2609", "Pehalwan woh nahi jo doosron ko pachhaad de, balke asal pehalwan woh hai jo ghusse ke waqt apne aap par qaboo rakhe."),
        HadithEntry("Make things easy and do not make them difficult; give glad tidings and do not drive people away.", "Sahih al-Bukhari 69, Sahih Muslim 1734", "Aasani karo, mushkil mat daalo; khushkhabri sunao, logon ko nafrat mat dilao."),
        HadithEntry("The most beloved deeds to Allah are those done regularly, even if they are small.", "Sahih al-Bukhari 6464, Sahih Muslim 783", "Allah ko sab se pasandida amal woh hain jo hamesha kiye jayen, chahe thode hi hon."),
        HadithEntry("Allah does not look at your faces or your wealth, but He looks at your hearts and your deeds.", "Sahih Muslim 2564", "Allah tumhari shaklon aur maal ko nahi dekhta, woh tumhare dilon aur amal ko dekhta hai."),
        HadithEntry("Cleanliness is half of faith.", "Sahih Muslim 223", "Paaki aadhe imaan ka hissa hai."),
        HadithEntry("A Muslim is the one from whose tongue and hand other Muslims are safe.", "Sahih al-Bukhari 10, Sahih Muslim 40", "Muslim woh hai jis ki zabaan aur haath se doosre musalman mehfooz rahen."),
        HadithEntry("Whoever takes a path to seek knowledge, Allah makes easy for him a path to Paradise.", "Sahih Muslim 2699", "Jo shakhs ilm hasil karne ke raaste par chalta hai, Allah uske liye jannat ka raasta aasan kar deta hai."),
        HadithEntry("There are two blessings many people lose: health and free time.", "Sahih al-Bukhari 6412", "Do nemtein aisi hain jin mein bohat se log dhokhe mein hain: sehat aur faraghat (khaali waqt)."),
        HadithEntry("Be in this world as if you were a stranger or a traveller.", "Sahih al-Bukhari 6416", "Duniya mein aise reh jaise koi musafir ya raah chalta hua."),
        HadithEntry("Part of the excellence of a person’s Islam is leaving that which does not concern him.", "Jami at-Tirmidhi 2317", "Insaan ke islam ki khoobi mein se hai ke woh be-maqsad cheezein chhod de."),
        HadithEntry("Whoever does not show mercy to others will not be shown mercy.", "Sahih al-Bukhari 6013, Sahih Muslim 2318", "Jo doosron par reham nahi karta us par reham nahi kiya jata."),
        HadithEntry("Two words are light on the tongue, heavy on the scale and beloved to Ar-Rahman: SubhanAllahi wa bihamdihi, SubhanAllahil-Azim.", "Sahih al-Bukhari 6406, Sahih Muslim 2694", "Do kalme zabaan par halke, mizaan mein bhaari aur Rahman ko pyare hain: SubhanAllahi wa bihamdihi, SubhanAllahil-Azeem."),
        HadithEntry("The best of you are those with the best character.", "Sahih al-Bukhari 3559, Sahih Muslim 2321", "Tum mein sab se behtar woh hain jin ke akhlaq sab se achhe hain."),
        HadithEntry("Whoever prays Fajr is under the protection of Allah.", "Sahih Muslim 657", "Jo Fajr ki namaz parhta hai woh Allah ki hifazat mein hota hai."),
        HadithEntry("Whoever sends one blessing upon me, Allah sends ten blessings upon him.", "Sahih Muslim 408", "Jo mujh par ek baar durood bhejta hai, Allah us par das rehmatein bhejta hai."),
        HadithEntry("If a river were at the door of one of you and he bathed in it five times a day, would any dirt remain on him? So are the five prayers; Allah erases sins through them.", "Sahih al-Bukhari 528, Sahih Muslim 667", "Agar tum mein se kisi ke darwaze par nehar ho aur woh us mein din mein paanch baar nahaye, to kya uske jism par maile ka koi nishaan rahega? Paanch namazon ki misaal aisi hi hai; Allah in ke zariye gunah mita deta hai."),
        HadithEntry("Charity never decreases wealth.", "Sahih Muslim 2588", "Sadqa maal ko kam nahi karta."),
        HadithEntry("A man asked the Prophet ﷺ for advice. He said: “Do not become angry.”", "Sahih al-Bukhari 6116", "Ek shakhs ne Nabi ﷺ se naseehat maangi, aap ne farmaya: “Ghussa mat kiya karo.”"),
        HadithEntry("Whoever relieves a believer of a hardship of this world, Allah will relieve him of a hardship on the Day of Resurrection.", "Sahih Muslim 2699", "Jo kisi momin ki duniya ki koi takleef door kare, Allah qayamat ke din uski takleef door farmayega."),
        HadithEntry("Truthfulness leads to righteousness, and righteousness leads to Paradise.", "Sahih al-Bukhari 6094, Sahih Muslim 2607", "Sachchai neki ki taraf le jati hai, aur neki jannat ki taraf le jati hai."),
        HadithEntry("Beware of suspicion, for suspicion is the most untruthful of speech.", "Sahih al-Bukhari 6066, Sahih Muslim 2563", "Bad-gumani se bacho, kyunke bad-gumani sab se jhooti baat hai."),
        HadithEntry("Du‘a is worship.", "Jami at-Tirmidhi 3371", "Dua hi ibadat hai."),
        HadithEntry("Whoever is not grateful to people is not grateful to Allah.", "Sunan Abi Dawud 4811, Jami at-Tirmidhi 1954", "Jo logon ka shukar ada nahi karta woh Allah ka shukar bhi ada nahi karta."),
        HadithEntry("Smiling in the face of your brother is charity.", "Jami at-Tirmidhi 1956", "Apne bhai ke saamne muskurana sadqa hai.")
    )

    fun today(): HadithEntry {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        return all[day % all.size]
    }
}

@Composable
fun HadithCard() {
    val h = Hadith.today()
    val context = LocalContext.current
    DeenCard {
        Column(Modifier.padding(16.dp)) {
            Text("Hadees of the day", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text("“${h.roman}”", style = MaterialTheme.typography.bodyLarge, fontStyle = FontStyle.Italic, modifier = Modifier.padding(top = 8.dp))
            Text("English: ${h.text}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
            Text("— ${h.source}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { shareHadith(context, h) }) { Text("Share") }
            }
        }
    }
}

fun shareHadith(context: Context, h: HadithEntry) {
    val msg = "Hadees:\n“${h.roman}”\n\nEnglish:\n“${h.text}”\n\n— ${h.source}\n\nShared from My Deen app"
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, msg)
    }
    context.startActivity(Intent.createChooser(send, "Share Hadees").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
