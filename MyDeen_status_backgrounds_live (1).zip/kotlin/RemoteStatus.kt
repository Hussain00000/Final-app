package com.example.mydeen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Live statuses + backgrounds from a Google Sheet you own.
 *
 * Sheet columns (row 1 = header, exactly these names):
 *   date | kind | arabic | text | source | theme | bg_url
 *   - date   : optional yyyy-MM-dd, blank = any day (rotates by day-of-year)
 *   - kind   : ayah | hadith | dua | action
 *   - arabic : ORIGINAL Arabic (with harakat)
 *   - text   : translation / reminder
 *   - source : e.g. "Sahih Bukhari" or "Quran 2:286"
 *   - theme  : optional built-in fallback (dua, quran, hadith, namaz, sabr, shukr, tauba, sadaqah, family, default)
 *   - bg_url : optional direct image link (see README_LIVE.md); blank = built-in theme art
 */
data class LiveStatus(
    val date: String, val kind: String, val arabic: String, val text: String,
    val source: String, val theme: String, val bgUrl: String
)

object RemoteStatus {
    /** File > Share > Publish to web > pick the sheet tab > CSV > copy the link here. */
    const val SHEET_CSV_URL = "PASTE_YOUR_PUBLISHED_SHEET_CSV_URL_HERE"

    private const val CACHE_FILE = "live_status.csv"
    private const val MAX_AGE_MS = 6L * 60 * 60 * 1000          // refresh at most every 6 h

    suspend fun load(ctx: Context): List<LiveStatus> = withContext(Dispatchers.IO) {
        val f = File(ctx.filesDir, CACHE_FILE)
        val stale = !f.exists() || System.currentTimeMillis() - f.lastModified() > MAX_AGE_MS
        if (stale && SHEET_CSV_URL.startsWith("http")) {
            try {
                val body = httpGet(SHEET_CSV_URL).toString(Charsets.UTF_8)
                if (body.lines().size > 1) f.writeText(body)      // only replace cache with something sane
            } catch (_: Exception) { /* offline: keep old cache */ }
        }
        if (f.exists()) parse(f.readText()) else emptyList()
    }

    /** Today's status: exact date match first, otherwise rotate through undated rows by day-of-year. */
    fun today(list: List<LiveStatus>): LiveStatus? {
        if (list.isEmpty()) return null
        val cal = java.util.Calendar.getInstance()
        val iso = "%04d-%02d-%02d".format(cal.get(1), cal.get(2) + 1, cal.get(5))
        list.firstOrNull { it.date == iso }?.let { return it }
        val undated = list.filter { it.date.isBlank() }.ifEmpty { list }
        return undated[cal.get(java.util.Calendar.DAY_OF_YEAR) % undated.size]
    }

    /** Downloads (and disk-caches) the background; returns null on any failure so the caller falls back. */
    suspend fun background(ctx: Context, url: String): Bitmap? = withContext(Dispatchers.IO) {
        if (!url.startsWith("http")) return@withContext null
        val dir = File(ctx.cacheDir, "live_bg").apply { mkdirs() }
        val f = File(dir, sha1(url) + ".img")
        try {
            if (!f.exists()) f.writeBytes(httpGet(directLink(url)))
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (_: Exception) { f.delete(); null }
    }

    /** Convenience: pick today's status and render it with the live background (or built-in art on failure). */
    suspend fun renderToday(ctx: Context): Bitmap? {
        val s = today(load(ctx)) ?: return null
        val theme = StatusTheme.values().firstOrNull { it.name.equals(s.theme, true) }
        return StatusBackgrounds.render(
            ctx, s.arabic, s.text, s.source.ifBlank { null }, s.kind,
            themeOverride = theme, remoteBackground = background(ctx, s.bgUrl)
        )
    }

    // ---- helpers -------------------------------------------------------------------------------

    /** Turns a Google Drive "share" link into a direct-download link; other URLs pass through. */
    private fun directLink(u: String): String {
        val id = Regex("/d/([A-Za-z0-9_-]{10,})").find(u)?.groupValues?.get(1)
            ?: Regex("[?&]id=([A-Za-z0-9_-]{10,})").find(u)?.groupValues?.get(1)
        return if (u.contains("drive.google.com") && id != null)
            "https://drive.google.com/uc?export=download&id=$id" else u
    }

    private fun httpGet(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10_000; c.readTimeout = 20_000; c.instanceFollowRedirects = true
        try { return c.inputStream.use { it.readBytes() } } finally { c.disconnect() }
    }

    private fun sha1(s: String) =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    /** Small RFC-4180 CSV parser (quotes, commas and newlines inside cells). */
    internal fun parse(csv: String): List<LiveStatus> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>(); val cell = StringBuilder(); var q = false; var i = 0
        while (i < csv.length) {
            val ch = csv[i]
            when {
                q && ch == '"' && i + 1 < csv.length && csv[i + 1] == '"' -> { cell.append('"'); i++ }
                ch == '"' -> q = !q
                !q && ch == ',' -> { row.add(cell.toString()); cell.setLength(0) }
                !q && (ch == '\n' || ch == '\r') -> {
                    if (ch == '\r' && i + 1 < csv.length && csv[i + 1] == '\n') i++
                    row.add(cell.toString()); cell.setLength(0)
                    if (row.any { it.isNotBlank() }) rows.add(row); row = ArrayList()
                }
                else -> cell.append(ch)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString()); rows.add(row) }
        if (rows.size < 2) return emptyList()
        val h = rows[0].map { it.trim().lowercase().removePrefix("﻿") }
        fun col(r: List<String>, n: String) = h.indexOf(n).let { if (it in r.indices) r[it].trim() else "" }
        return rows.drop(1).map {
            LiveStatus(col(it, "date"), col(it, "kind"), col(it, "arabic"), col(it, "text"),
                col(it, "source"), col(it, "theme"), col(it, "bg_url"))
        }.filter { it.arabic.isNotBlank() || it.text.isNotBlank() }
    }
}
