import math, random, os, sys
from PIL import Image, ImageDraw, ImageFilter, ImageChops

W, H = 1080, 1920
S = 2  # supersample
OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)

def hexc(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)

def vgrad(stops):
    """stops: list of (pos 0..1, hex). returns RGBA image W*S x H*S"""
    w, h = W*S, H*S
    img = Image.new('RGBA', (w, h))
    px = img.load()
    cols = [(p, hexc(c)) for p, c in stops]
    for y in range(h):
        t = y / (h-1)
        for i in range(len(cols)-1):
            if cols[i][0] <= t <= cols[i+1][0]:
                a, b = cols[i], cols[i+1]
                u = (t-a[0])/max(1e-6, b[0]-a[0])
                c = tuple(int(a[1][k]+(b[1][k]-a[1][k])*u) for k in range(4))
                break
        else:
            c = cols[-1][1]
        for x in range(w):
            px[x, y] = c
    return img

def vgrad_fast(stops):
    w, h = W*S, H*S
    col = Image.new('RGBA', (1, h))
    px = col.load()
    cols = [(p, hexc(c)) for p, c in stops]
    for y in range(h):
        t = y/(h-1)
        c = cols[-1][1]
        for i in range(len(cols)-1):
            if cols[i][0] <= t <= cols[i+1][0]:
                a, b = cols[i], cols[i+1]
                u = (t-a[0])/max(1e-6, b[0]-a[0])
                c = tuple(int(a[1][k]+(b[1][k]-a[1][k])*u) for k in range(4)); break
        px[0, y] = c
    return col.resize((w, h))

def layer():
    return Image.new('RGBA', (W*S, H*S), (0,0,0,0))

def star_poly(cx, cy, r_out, r_in, n=8, rot=0):
    pts = []
    for i in range(n*2):
        r = r_out if i % 2 == 0 else r_in
        a = rot + math.pi*i/n
        pts.append((cx + r*math.cos(a), cy + r*math.sin(a)))
    return pts

def geo_pattern(color, alpha, size=150, line=2, fade_top=0.0):
    """8-point star lattice (khatam) with outlines."""
    L = layer(); d = ImageDraw.Draw(L)
    col = hexc(color, alpha)
    sz = size*S
    for gy in range(-1, int(H*S/sz)+2):
        for gx in range(-1, int(W*S/sz)+2):
            cx, cy = gx*sz + sz/2, gy*sz + sz/2
            d.line(star_poly(cx, cy, sz*0.5, sz*0.28, 8, math.pi/8) + [star_poly(cx, cy, sz*0.5, sz*0.28, 8, math.pi/8)[0]], fill=col, width=line*S)
            # inner rotated square pair
            d.polygon(star_poly(cx, cy, sz*0.2, sz*0.2, 4, math.pi/4), outline=col, width=line*S)
            # connecting diamonds at lattice corners
            d.polygon(star_poly(cx+sz/2, cy+sz/2, sz*0.14, sz*0.14, 4, 0), outline=col, width=line*S)
    return L

def mask_vertical(layer_img, y0, y1, a0, a1):
    """scale alpha of layer by gradient from a0 at y0 to a1 at y1 (0..1 of H)."""
    w, h = layer_img.size
    m = Image.new('L', (1, h))
    px = m.load()
    for y in range(h):
        t = y/(h-1)
        if t <= y0: v = a0
        elif t >= y1: v = a1
        else: v = a0+(a1-a0)*(t-y0)/(y1-y0)
        px[0, y] = int(255*v)
    m = m.resize((w, h))
    r, g, b, a = layer_img.split()
    a = ImageChops.multiply(a, m)
    return Image.merge('RGBA', (r, g, b, a))

def glow(cx, cy, r, color, alpha=120):
    L = layer(); d = ImageDraw.Draw(L)
    d.ellipse((cx*S-r*S, cy*S-r*S, cx*S+r*S, cy*S+r*S), fill=hexc(color, alpha))
    return L.filter(ImageFilter.GaussianBlur(r*S*0.45))

def crescent(cx, cy, r, color, offset=0.38):
    L = layer(); d = ImageDraw.Draw(L)
    d.ellipse(((cx-r)*S, (cy-r)*S, (cx+r)*S, (cy+r)*S), fill=hexc(color))
    cut = Image.new('L', L.size, 0); cd = ImageDraw.Draw(cut)
    cd.ellipse(((cx-r+r*offset*1.4)*S, (cy-r-r*0.05)*S, (cx+r+r*offset*1.4)*S, (cy+r-r*0.05)*S), fill=255)
    r_, g_, b_, a_ = L.split()
    a_ = ImageChops.subtract(a_, cut)
    return Image.merge('RGBA', (r_, g_, b_, a_))

def stars(n, color, seed, ymax=0.5, rmax=3.2, alpha=230):
    rnd = random.Random(seed); L = layer(); d = ImageDraw.Draw(L)
    for _ in range(n):
        x, y = rnd.random()*W, rnd.random()*H*ymax
        r = rnd.random()*rmax+0.8
        d.ellipse(((x-r)*S, (y-r)*S, (x+r)*S, (y+r)*S), fill=hexc(color, int(alpha*rnd.uniform(.4, 1))))
        if rnd.random() < 0.12:
            q = r*4
            d.line(((x-q)*S, y*S, (x+q)*S, y*S), fill=hexc(color, 160), width=S)
            d.line((x*S, (y-q)*S, x*S, (y+q)*S), fill=hexc(color, 160), width=S)
    return L

def dome(d, cx, base, w, h, col):
    d.pieslice(((cx-w/2)*S, (base-h)*S, (cx+w/2)*S, (base+h)*S), 180, 360, fill=col)
    d.rectangle(((cx-w/2)*S, base*S, (cx+w/2)*S, (base+h*0.6)*S), fill=col)
    # finial
    d.rectangle(((cx-2)*S, (base-h-34)*S, (cx+2)*S, (base-h+4)*S), fill=col)
    d.ellipse(((cx-7)*S, (base-h-44)*S, (cx+7)*S, (base-h-30)*S), fill=col)

def minaret(d, cx, base, top, w, col):
    d.rectangle(((cx-w/2)*S, top*S, (cx+w/2)*S, base*S), fill=col)
    # balcony
    d.rectangle(((cx-w*0.85)*S, (top+90)*S, (cx+w*0.85)*S, (top+104)*S), fill=col)
    d.rectangle(((cx-w*0.85)*S, (top+170)*S, (cx+w*0.85)*S, (top+182)*S), fill=col)
    # cap
    d.polygon([((cx-w*0.7)*S, top*S), ((cx+w*0.7)*S, top*S), (cx*S, (top-w*2.6)*S)], fill=col)
    d.ellipse(((cx-4)*S, (top-w*2.6-14)*S, (cx+4)*S, (top-w*2.6-2)*S), fill=col)

def mosque(base, col, scale=1.0, cx=W/2):
    L = layer(); d = ImageDraw.Draw(L)
    c = hexc(col)
    s = scale
    d.rectangle(((cx-330*s)*S, base*S, (cx+330*s)*S, H*S), fill=c)
    d.rectangle(((cx-250*s)*S, (base-120*s)*S, (cx+250*s)*S, base*S), fill=c)
    dome(d, cx, base-120*s, 300*s, 190*s, c)
    dome(d, cx-215*s, base-120*s, 120*s, 80*s, c)
    dome(d, cx+215*s, base-120*s, 120*s, 80*s, c)
    minaret(d, cx-330*s, base+10, base-420*s, 26*s, c)
    minaret(d, cx+330*s, base+10, base-420*s, 26*s, c)
    # arched windows (cutouts drawn as transparent)
    return L

def arch_windows(base, scale, cx, glowcol):
    L = layer(); d = ImageDraw.Draw(L)
    for k in (-1, 0, 1):
        x = cx + k*105*scale
        d.rectangle(((x-22*scale)*S, (base-55*scale)*S, (x+22*scale)*S, (base+60*scale)*S), fill=hexc(glowcol, 235))
        d.pieslice(((x-22*scale)*S, (base-77*scale)*S, (x+22*scale)*S, (base-33*scale)*S), 180, 360, fill=hexc(glowcol, 235))
    return L

def dunes(color, base, amp, freq, phase, alpha=255):
    L = layer(); d = ImageDraw.Draw(L)
    pts = [(0, H*S)]
    for x in range(0, W*S+1, 6):
        y = base*S + math.sin(x/S*freq+phase)*amp*S + math.sin(x/S*freq*2.3+phase*1.7)*amp*0.35*S
        pts.append((x, y))
    pts.append((W*S, H*S))
    d.polygon(pts, fill=hexc(color, alpha))
    return L

def lantern(cx, top, size, color, glowc):
    L = layer(); d = ImageDraw.Draw(L)
    c = hexc(color)
    d.line((cx*S, 0, cx*S, top*S), fill=c, width=3*S)
    w = size
    d.polygon([((cx-w*0.25)*S, top*S), ((cx+w*0.25)*S, top*S), ((cx+w*0.5)*S, (top+w*0.35)*S), ((cx-w*0.5)*S, (top+w*0.35)*S)], fill=c)
    d.rectangle(((cx-w*0.5)*S, (top+w*0.35)*S, (cx+w*0.5)*S, (top+w*1.35)*S), fill=hexc(glowc, 215), outline=c, width=4*S)
    for k in (-0.17, 0.17):
        d.line(((cx+w*k)*S, (top+w*0.35)*S, (cx+w*k)*S, (top+w*1.35)*S), fill=c, width=3*S)
    d.polygon([((cx-w*0.5)*S, (top+w*1.35)*S), ((cx+w*0.5)*S, (top+w*1.35)*S), ((cx+w*0.3)*S, (top+w*1.62)*S), ((cx-w*0.3)*S, (top+w*1.62)*S)], fill=c)
    d.ellipse(((cx-8)*S, (top+w*1.62)*S, (cx+8)*S, (top+w*1.62+16)*S), fill=c)
    return L

def arch_frame(color, alpha=200, inset=70):
    """Pointed Islamic arch window frame (double line)."""
    L = layer(); d = ImageDraw.Draw(L)
    col = hexc(color, alpha)
    for off, wd in ((0, 5), (22, 2)):
        x0, x1 = inset+off, W-inset-off
        y_b = H-inset-off
        y_spring = 520+off
        peak = 150+off
        cx = W/2
        # pointed arch via two arcs
        r = (x1-x0)*0.62
        pts = []
        for t in range(0, 91, 2):
            a = math.radians(t)
            pts.append(((x0 + r - r*math.cos(a))*S, (y_spring - (y_spring-peak)*math.sin(a)**1.0 * 1.0)*S))
        # simple: left side up, right side mirrored
        left = [(x0*S, y_b*S), (x0*S, y_spring*S)]
        right = [(x1*S, y_spring*S), (x1*S, y_b*S)]
        arc = []
        for t in range(0, 181, 3):
            a = math.radians(t)
            # ogee-like pointed arch: two circular arcs meeting at the apex
            pass
        # build pointed arch using two arcs
        rr = (x1-x0)*0.75
        lc = (x0+rr, y_spring)  # centre of left arc lies to the right
        rc = (x1-rr, y_spring)
        ang_left = math.acos(((cx)-lc[0])/rr) if abs((cx-lc[0])/rr) <= 1 else 0
        apex_y = y_spring - rr*math.sin(ang_left)
        left_arc = []
        n = 40
        a_start = math.pi
        a_end = math.pi - (math.pi - (math.pi - ang_left)) if False else None
        # parametric: left arc from (x0, y_spring) to apex
        a0 = math.pi
        a1 = math.pi - (math.pi - ang_left)  # = ang_left
        for i in range(n+1):
            a = a0 + (a1 - a0 + 0)*i/n if False else math.pi - (math.pi-ang_left)*i/n
            left_arc.append(((lc[0]+rr*math.cos(a))*S, (lc[1]-rr*math.sin(a))*S))
        right_arc = [((2*cx*S - px_), py_) for px_, py_ in reversed(left_arc)]
        d.line([(x0*S, y_b*S), (x0*S, y_spring*S)] + left_arc + right_arc + [(x1*S, y_spring*S), (x1*S, y_b*S), (x0*S, y_b*S)], fill=col, width=wd*S, joint='curve')
    return L

def rays(cx, cy, color, n=18, alpha=40, length=2400):
    L = layer(); d = ImageDraw.Draw(L)
    for i in range(n):
        a = math.pi + math.pi*(i+0.5)/n
        spread = math.pi/n*0.38
        pts = [(cx*S, cy*S), ((cx+length*math.cos(a-spread))*S, (cy+length*math.sin(a-spread))*S), ((cx+length*math.cos(a+spread))*S, (cy+length*math.sin(a+spread))*S)]
        d.polygon(pts, fill=hexc(color, alpha))
    return L.filter(ImageFilter.GaussianBlur(6*S))

def vignette(strength=170):
    L = layer(); d = ImageDraw.Draw(L)
    d.rectangle((0, 0, W*S, H*S), fill=(0, 0, 0, strength))
    m = Image.new('L', L.size, 0); md = ImageDraw.Draw(m)
    md.ellipse((-W*0.35*S, -H*0.2*S, W*1.35*S, H*1.2*S), fill=255)
    m = m.filter(ImageFilter.GaussianBlur(160*S))
    r, g, b, a = L.split()
    a = ImageChops.multiply(a, ImageChops.invert(m))
    return Image.merge('RGBA', (r, g, b, a))

def text_scrim(top=0.0, bottom=0.42, alpha=95, color='#000000'):
    """soft dark panel behind the Arabic area (top of the image)."""
    L = layer(); d = ImageDraw.Draw(L)
    d.rectangle((0, 0, W*S, int(H*S*bottom)), fill=hexc(color, alpha))
    return mask_vertical(L, 0.0, bottom, 1.0, 0.0)

def border(color, alpha=200, inset=34):
    L = layer(); d = ImageDraw.Draw(L)
    col = hexc(color, alpha)
    d.rectangle((inset*S, inset*S, (W-inset)*S, (H-inset)*S), outline=col, width=3*S)
    d.rectangle(((inset+14)*S, (inset+14)*S, (W-inset-14)*S, (H-inset-14)*S), outline=hexc(color, int(alpha*0.5)), width=S)
    # corner stars
    for (x, y) in ((inset, inset), (W-inset, inset), (inset, H-inset), (W-inset, H-inset)):
        d.polygon(star_poly(x*S, y*S, 26*S, 12*S, 8, math.pi/8), fill=col)
    return L

def compose(layers, base):
    img = base
    for l in layers:
        img = Image.alpha_composite(img, l)
    return img.convert('RGB').resize((W, H), Image.LANCZOS)

def arch_frame(color, alpha=200, inset=70):
    """Pointed (two-centre) Islamic arch frame, double line."""
    L = layer(); d = ImageDraw.Draw(L)
    col = hexc(color, alpha)
    for off, wd in ((0, 5), (22, 2)):
        x0, x1 = inset+off, W-inset-off
        yb = H-inset-off
        ys = 560+off                      # spring line
        cx = W/2
        rr = (x1-x0)*0.80                 # arc radius > half width => pointed apex
        lc = x0+rr                         # left arc centre x (on spring line)
        ang = math.acos((cx-lc)/rr)       # angle at apex from centre
        arc = []
        n = 48
        for i in range(n+1):
            a = math.pi - (math.pi-ang)*i/n
            arc.append(((lc+rr*math.cos(a))*S, (ys-rr*math.sin(a))*S))
        mirror = [(2*cx*S-px, py) for px, py in reversed(arc)]
        pts = [(x0*S, yb*S)] + arc + mirror + [(x1*S, yb*S), (x0*S, yb*S)]
        d.line(pts, fill=col, width=wd*S, joint='curve')
    return L

themes = {}

def theme(name):
    def deco(f): themes[name] = f; return f
    return deco

@theme('dua')       # night sky, crescent, hanging lantern
def _():
    base = vgrad_fast([(0, '#0b1033'), (0.5, '#1b1f5c'), (1, '#3a2a6e')])
    return compose([
        stars(160, '#fff6d6', 1, 0.7),
        glow(860, 360, 260, '#ffd98a', 90),
        crescent(860, 360, 120, '#ffe7a8'),
        mask_vertical(geo_pattern('#c9a8ff', 38, 160), 0.30, 0.7, 0.0, 1.0),
        lantern(210, 0, 150, '#d9ad4f', '#ffcf6e'),
        lantern(120, 0, 90, '#d9ad4f', '#ffcf6e'),
        mosque(1560, '#0a0d2b', 1.15),
        arch_windows(1650, 1.15, W/2, '#ffd98a'),
        vignette(120),
        border('#e0b95a', 170),
    ], base)

@theme('quran')     # emerald + gold lattice
def _():
    base = vgrad_fast([(0, '#06352a'), (0.55, '#0b5a44'), (1, '#052a21')])
    return compose([
        glow(W/2, 300, 420, '#2fbf8c', 70),
        geo_pattern('#e5c36a', 70, 150),
        text_scrim(bottom=0.45, alpha=70),
        arch_frame('#e5c36a', 210),
        stars(40, '#fff3c4', 3, 0.22, 2.4, 200),
        vignette(90),
    ], base)

@theme('hadith')    # warm sand, arch + sun disc
def _():
    base = vgrad_fast([(0, '#f3e0b8'), (0.5, '#e2b97a'), (1, '#9c6a3a')])
    return compose([
        glow(W/2, 420, 520, '#fff2cf', 150),
        rays(W/2, 520, '#fff0c4', 22, 55),
        mask_vertical(geo_pattern('#7a4d22', 40, 150), 0.35, 1.0, 0.0, 1.0),
        dunes('#b98046', 1450, 50, 0.008, 0.5),
        dunes('#8a5a2c', 1580, 60, 0.006, 2.0),
        mosque(1560, '#4a2c12', 1.0),
        arch_windows(1650, 1.0, W/2, '#ffd27a'),
        arch_frame('#6b4220', 150),
    ], base)

@theme('namaz')     # dawn gradient + mosque silhouette
def _():
    base = vgrad_fast([(0, '#1a2a5e'), (0.38, '#6a5aa8'), (0.62, '#f0a07a'), (0.8, '#ffd29a'), (1, '#2a1a3a')])
    return compose([
        glow(W/2, 1250, 420, '#fff0b8', 130),
        stars(70, '#ffffff', 7, 0.3, 2.2, 190),
        dunes('#3a2a55', 1500, 30, 0.009, 1.0, 255),
        mosque(1470, '#1a1230', 1.2),
        arch_windows(1560, 1.2, W/2, '#ffd98a'),
        text_scrim(bottom=0.40, alpha=70, color='#0a1030'),
        border('#ffe3a8', 150),
    ], base)

@theme('sabr')      # calm teal, moon over still water & dunes
def _():
    base = vgrad_fast([(0, '#06222b'), (0.45, '#0f4a56'), (0.75, '#1b7a80'), (1, '#052e34')])
    return compose([
        stars(90, '#e6fbff', 11, 0.45),
        glow(W/2, 640, 300, '#bff4ff', 90),
        crescent(W/2, 640, 130, '#e9fcff'),
        mask_vertical(geo_pattern('#8de2e8', 30, 170), 0.35, 1.0, 0.0, 0.9),
        dunes('#0b3a42', 1380, 55, 0.007, 0.3),
        dunes('#082c33', 1520, 65, 0.005, 1.8),
        dunes('#051f25', 1680, 50, 0.008, 3.1),
        border('#9ee9ee', 150),
    ], base)

@theme('shukr')     # gold sunrise, radiating rays
def _():
    base = vgrad_fast([(0, '#ffe7a3'), (0.4, '#ffbe5c'), (0.75, '#e0782b'), (1, '#8a3d12')])
    return compose([
        rays(W/2, 1000, '#fff6d0', 26, 70),
        glow(W/2, 1000, 380, '#fffbe0', 220),
        mask_vertical(geo_pattern('#7a3b10', 40, 150), 0.35, 1.0, 0.0, 1.0),
        dunes('#a64f18', 1380, 45, 0.007, 0.6),
        dunes('#7a3610', 1520, 55, 0.006, 2.4),
        mosque(1600, '#3d1a08', 0.95),
        arch_windows(1690, 0.95, W/2, '#ffe7a3'),
        arch_frame('#7a3b10', 130),
    ], base)

@theme('tauba')     # deep violet night, soft falling light
def _():
    base = vgrad_fast([(0, '#120a2a'), (0.5, '#2a1a5e'), (1, '#4a2a7e')])
    L = layer(); d = ImageDraw.Draw(L)
    rnd = random.Random(21)
    for _i in range(55):
        x = rnd.random()*W; y0 = rnd.random()*H*0.8; ln = rnd.uniform(80, 260)
        d.line((x*S, y0*S, x*S, (y0+ln)*S), fill=hexc('#d8c4ff', rnd.randint(25, 70)), width=2*S)
    L = L.filter(ImageFilter.GaussianBlur(1.2*S))
    return compose([
        stars(130, '#f1e8ff', 5, 0.6),
        L,
        glow(W/2, 560, 320, '#b99cff', 90),
        crescent(W/2, 560, 110, '#efe5ff'),
        mask_vertical(geo_pattern('#b79cf0', 34, 160), 0.35, 1.0, 0.0, 1.0),
        mosque(1620, '#0b0620', 1.0),
        arch_windows(1710, 1.0, W/2, '#e0ccff'),
        vignette(120),
        border('#c9b3ff', 160),
    ], base)

@theme('sadaqah')   # warm rose/gold, lanterns, kindness
def _():
    base = vgrad_fast([(0, '#4a0f2e'), (0.5, '#8a2a52'), (1, '#c4617a')])
    return compose([
        glow(W/2, 420, 460, '#ffb7c8', 90),
        mask_vertical(geo_pattern('#ffd7a0', 48, 150), 0.0, 1.0, 0.5, 1.0),
        lantern(180, 0, 120, '#e6b85a', '#ffd9a0'),
        lantern(900, 0, 140, '#e6b85a', '#ffd9a0'),
        lantern(540, 0, 80, '#e6b85a', '#ffd9a0'),
        mosque(1640, '#2e0a1c', 0.95),
        arch_windows(1730, 0.95, W/2, '#ffd9a0'),
        text_scrim(bottom=0.40, alpha=60, color='#260616'),
        border('#ffd7a0', 170),
    ], base)

@theme('family')    # soft green garden, arches
def _():
    base = vgrad_fast([(0, '#d8f0d0'), (0.45, '#8fcf9a'), (1, '#2f7a52')])
    return compose([
        glow(W/2, 380, 460, '#ffffff', 170),
        mask_vertical(geo_pattern('#1f6a45', 40, 150), 0.30, 1.0, 0.0, 1.0),
        dunes('#59b076', 1450, 45, 0.007, 0.9),
        dunes('#2f7a52', 1580, 55, 0.006, 2.7),
        mosque(1620, '#0f3d29', 0.95),
        arch_windows(1710, 0.95, W/2, '#fff2b8'),
        arch_frame('#1f6a45', 150),
    ], base)

@theme('default')   # classic emerald + gold crescent
def _():
    base = vgrad_fast([(0, '#073b2e'), (0.6, '#0e6b52'), (1, '#05261e')])
    return compose([
        glow(W/2, 300, 380, '#35c795', 70),
        geo_pattern('#d9b85a', 60, 150),
        text_scrim(bottom=0.45, alpha=70),
        crescent(W/2, 1010, 110, '#f1d98a'),
        glow(W/2, 1010, 200, '#f1d98a', 60),
        mosque(1640, '#04201a', 0.95),
        arch_windows(1730, 0.95, W/2, '#f1d98a'),
        vignette(100),
        border('#d9b85a', 170),
    ], base)

if __name__ == '__main__':
    names = sys.argv[2:] or list(themes)
    for n in names:
        img = themes[n]()
        img.save(os.path.join(OUT, f'status_bg_{n}.jpg'), quality=88, optimize=True)
        print('wrote', n)
