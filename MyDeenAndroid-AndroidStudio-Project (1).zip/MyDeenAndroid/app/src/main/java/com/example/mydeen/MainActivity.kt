package com.example.mydeen

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class ActivityItem(val title: String, val kind: String = "check")
private data class Group(val title: String, val items: List<ActivityItem>)
private val groups = listOf(
    Group("Salah & Sunnah", listOf(ActivityItem("5 daily Salah with Takbir"), ActivityItem("Sunnat-e-Muakkadah"), ActivityItem("Tahajjud"), ActivityItem("Ishraq"), ActivityItem("Chasht"), ActivityItem("Awwabin"))),
    Group("Qaza & Tasbeeh", listOf(ActivityItem("Umari Qaza"), ActivityItem("3 Tasbeeh — first daily entry"), ActivityItem("3 Tasbeeh — second daily entry"), ActivityItem("Durood — 1,000 times", "counter"))),
    Group("Quran & Learning", listOf(ActivityItem("Quran — 1 Juz"), ActivityItem("Quran Taleem"), ActivityItem("Ghar ki Taleem"))),
    Group("Character & Community", listOf(ActivityItem("Avoid Ghibat (backbiting)"), ActivityItem("Ghar Ghar Mulakhatan", "visits"), ActivityItem("Daily personal hygiene")))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminder.createChannel(this)
        Reminder.scheduleAll(this)
        setContent { MyDeenScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MyDeenScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("my_deen", Context.MODE_PRIVATE) }
    val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    var refresh by remember { mutableIntStateOf(0) }
    var reviewReason by remember { mutableStateOf(prefs.getString("review_reason_$day", "") ?: "") }
    var reviewPlan by remember { mutableStateOf(prefs.getString("review_plan_$day", "") ?: "") }
    var morning by remember { mutableStateOf(String.format(Locale.US, "%02d:%02d", prefs.getInt("morning_hour", 6), prefs.getInt("morning_minute", 0))) }
    var night by remember { mutableStateOf(String.format(Locale.US, "%02d:%02d", prefs.getInt("night_hour", 21), prefs.getInt("night_minute", 30))) }
    var qazaTotal by remember { mutableIntStateOf(prefs.getInt("qaza_total", 0)) }
    var qazaToday by remember { mutableIntStateOf(0) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val refreshSnapshot = refresh // Observe checklist changes so the overall progress recomputes.
    val total = groups.sumOf { it.items.size }
    val done = groups.sumOf { g -> g.items.count { item ->
        when (item.kind) {
            "counter" -> prefs.getInt("$day:${item.title}", 0) >= 1000
            "visits" -> prefs.getInt("$day:${item.title}", 0) > 0
            else -> prefs.getBoolean("$day:${item.title}", false)
        }
    } }
    val percent = if (total == 0) 0 else done * 100 / total
    Scaffold(topBar = { TopAppBar(title = { Text("My Deen  •  Daily Tracker") }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", style = MaterialTheme.typography.titleLarge)
                        Text("${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}")
                        Spacer(Modifier.height(8.dp)); Text("$percent%", style = MaterialTheme.typography.headlineLarge)
                        LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
                        Text("$done of $total activities completed")
                    }
                }
            }
            groups.forEach { group ->
                item { Text(group.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
                items(group.items, key = { it.title }) { item ->
                    val valueKey = "$day:${item.title}"
                    var checked by remember(day, item.title) { mutableStateOf(if (item.kind == "check") prefs.getBoolean(valueKey, false) else false) }
                    var amount by remember(day, item.title) { mutableIntStateOf(if (item.kind == "check") 0 else prefs.getInt(valueKey, 0)) }
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.title, modifier = Modifier.weight(1f).padding(top = 10.dp))
                            if (item.kind == "check") {
                                Checkbox(checked = checked, onCheckedChange = { checked = it; prefs.edit().putBoolean(valueKey, it).apply(); refresh++ })
                            } else {
                                OutlinedTextField(value = amount.toString(), onValueChange = { v -> amount = v.toIntOrNull()?.coerceAtLeast(0) ?: 0; prefs.edit().putInt(valueKey, amount).apply(); refresh++ }, modifier = Modifier.width(100.dp), singleLine = true, label = { Text(if (item.kind == "visits") "Visits" else "Count") })
                            }
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Nightly Muhasabah", style = MaterialTheme.typography.titleLarge)
                        Text("What made today's activities difficult?")
                        OutlinedTextField(reviewReason, { reviewReason = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        Text("What will I improve tomorrow?")
                        OutlinedTextField(reviewPlan, { reviewPlan = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        Button(onClick = { prefs.edit().putString("review_reason_$day", reviewReason).putString("review_plan_$day", reviewPlan).apply() }, modifier = Modifier.fillMaxWidth()) { Text("Save nightly review") }
                        Text("Today: $done / $total activities ($percent%)")
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Umari Qaza counter", style = MaterialTheme.typography.titleLarge)
                        Text("Total completed so far: $qazaTotal")
                        OutlinedTextField(qazaToday.toString(), { qazaToday = it.toIntOrNull()?.coerceAtLeast(0) ?: 0 }, label = { Text("Qaza completed today") }, singleLine = true)
                        Button(onClick = { qazaTotal += qazaToday; qazaToday = 0; prefs.edit().putInt("qaza_total", qazaTotal).apply() }, modifier = Modifier.fillMaxWidth()) { Text("Add today's Qaza to total") }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Daily reminders", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(morning, { morning = it }, label = { Text("Morning time (HH:mm)") }, singleLine = true)
                        OutlinedTextField(night, { night = it }, label = { Text("Nightly review time (HH:mm)") }, singleLine = true)
                        Button(onClick = {
                            fun parse(s: String, defaultH: Int, defaultM: Int): Pair<Int, Int> {
                                val p = s.split(":"); val h = p.getOrNull(0)?.toIntOrNull(); val m = p.getOrNull(1)?.toIntOrNull()
                                return if (h != null && m != null && h in 0..23 && m in 0..59) h to m else defaultH to defaultM
                            }
                            val a = parse(morning, 6, 0); val b = parse(night, 21, 30)
                            prefs.edit().putInt("morning_hour", a.first).putInt("morning_minute", a.second).putInt("night_hour", b.first).putInt("night_minute", b.second).apply()
                            Reminder.scheduleAll(context)
                            if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                            if (Build.VERSION.SDK_INT >= 31) {
                                val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                                if (!alarm.canScheduleExactAlarms()) context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Save times & enable reminders") }
                        Text("Android may ask you to allow notifications and exact alarms. Allow both for the most punctual reminders. Some battery-saving settings can still delay them.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { Text("Your checklist is stored on this phone. The two Tasbeeh labels are placeholders from the unclear handwriting and can be renamed in a later revision.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
