package com.example.mydeen

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import java.io.File

/** Which sound the alarm plays: three built-in tones, or an audio file the user picked (for example an Adhan). */
object AlarmSound {
    val names = listOf("Soft chime", "Peaceful bells", "Dawn tune", "My own sound")
    private val raws = listOf(R.raw.alarm_soft_chime, R.raw.alarm_peaceful_bells, R.raw.alarm_dawn_tune)
    const val CUSTOM = 3

    fun customFile(context: Context) = File(context.filesDir, "alarm_custom.audio")
    fun selected(context: Context): Int = Store.prefs(context).getInt("alarm_sound", 0).coerceIn(0, 3)
    fun hasCustom(context: Context) = customFile(context).exists()
    fun customName(context: Context): String = Store.prefs(context).getString("alarm_custom_name", "") ?: ""

    /** Copies the picked audio into the app so it keeps working. Returns false if it could not be read. */
    fun saveCustom(context: Context, uri: Uri, name: String): Boolean {
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return false
            input.use { customFile(context).outputStream().use { out -> it.copyTo(out) } }
            Store.prefs(context).edit().putString("alarm_custom_name", name).putInt("alarm_sound", CUSTOM).apply()
            true
        } catch (e: Exception) { false }
    }

    fun newPlayer(context: Context): MediaPlayer? {
        val sel = selected(context)
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        if (sel == CUSTOM && hasCustom(context)) {
            try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(attrs)
                mp.setDataSource(customFile(context).absolutePath)
                mp.prepare()
                mp.isLooping = false
                return mp
            } catch (e: Exception) { /* fall through to a built-in tone */ }
        }
        return try {
            val mp = MediaPlayer.create(context, raws[if (sel in raws.indices) sel else 0], attrs, 0) ?: return null
            mp.isLooping = true
            mp
        } catch (e: Exception) { null }
    }
}

/** Plays the alarm sound and shows a full-screen alarm until it is stopped or snoozed. */
class AlarmService : Service() {
    companion object {
        const val ACTION_STOP = "com.example.mydeen.STOP"
        const val ACTION_SNOOZE = "com.example.mydeen.SNOOZE"
        const val ALARM_CHANNEL = "my_deen_alarm"
        const val SNOOZE_MINUTES = 10
        private const val MAX_RING_MS = 90_000L

        fun createChannel(context: Context) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(ALARM_CHANNEL, "Deen alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Rings like an alarm for your Deen reminders"
                setSound(null, null) // the sound is played by the app itself
                enableVibration(false)
            })
        }

        fun ring(context: Context, id: Int, title: String, body: String) {
            val i = Intent(context, AlarmService::class.java).putExtra("id", id).putExtra("title", title).putExtra("body", body)
            context.startForegroundService(i)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, AlarmService::class.java).setAction(ACTION_STOP))
        }

        fun snooze(context: Context) {
            context.startService(Intent(context, AlarmService::class.java).setAction(ACTION_SNOOZE))
        }
    }

    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var curId = 0
    private var curTitle = ""
    private var curBody = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutDown(); return START_NOT_STICKY }
            ACTION_SNOOZE -> { snoozeAlarm(); shutDown(); return START_NOT_STICKY }
        }
        curId = intent?.getIntExtra("id", 0) ?: 0
        curTitle = intent?.getStringExtra("title") ?: "My Deeni Tracker"
        curBody = intent?.getStringExtra("body") ?: ""
        createChannel(this)

        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(7001, n)

        stopPlayback()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mydeen:alarm").apply { acquire(MAX_RING_MS + 30_000L) }
        } catch (e: Exception) { }
        player = AlarmSound.newPlayer(this)?.also { mp ->
            mp.setOnCompletionListener { if (!mp.isLooping) shutDown() }
            try { mp.start() } catch (e: Exception) { }
        }
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 500, 600, 1500), 0))
        } catch (e: Exception) { }
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ shutDown() }, MAX_RING_MS)
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val screen = PendingIntent.getActivity(
            this, 1,
            Intent(this, AlarmActivity::class.java).putExtra("title", curTitle).putExtra("body", curBody)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        val stop = PendingIntent.getService(this, 2, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags)
        val snooze = PendingIntent.getService(this, 3, Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE), flags)
        return NotificationCompat.Builder(this, ALARM_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(curTitle)
            .setContentText(curBody)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setContentIntent(screen)
            .setFullScreenIntent(screen, true)
            .addAction(0, "Stop", stop)
            .addAction(0, "Snooze $SNOOZE_MINUTES min", snooze)
            .build()
    }

    private fun snoozeAlarm() {
        val at = System.currentTimeMillis() + SNOOZE_MINUTES * 60_000L
        val i = Intent(this, ReminderReceiver::class.java).putExtra("id", curId).putExtra("snooze", true)
        val pending = PendingIntent.getBroadcast(this, 50000 + curId, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarm.canScheduleExactAlarms()) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
            else alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } catch (e: SecurityException) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        }
    }

    private fun stopPlayback() {
        try { player?.stop() } catch (e: Exception) { }
        player?.release()
        player = null
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (e: Exception) { }
        try { if (wake?.isHeld == true) wake?.release() } catch (e: Exception) { }
        wake = null
    }

    private fun shutDown() {
        handler.removeCallbacksAndMessages(null)
        stopPlayback()
        sendBroadcast(Intent("com.example.mydeen.ALARM_CLOSED").setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopPlayback()
        super.onDestroy()
    }
}

/** The full-screen page that appears over the lock screen while the alarm rings. */
class AlarmActivity : ComponentActivity() {
    private val closed = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val filter = android.content.IntentFilter("com.example.mydeen.ALARM_CLOSED")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(closed, filter, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(closed, filter)
        val title = intent.getStringExtra("title") ?: "My Deeni Tracker"
        val body = intent.getStringExtra("body") ?: ""
        setContent {
            MyDeenTheme {
                AlarmScreen(title, body,
                    onStop = { AlarmService.stop(this); finish() },
                    onSnooze = { AlarmService.snooze(this); finish() })
            }
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(closed) } catch (e: Exception) { }
        super.onDestroy()
    }
}

@Composable
private fun AlarmScreen(title: String, body: String, onStop: () -> Unit, onSnooze: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.primary) {
        Column(
            Modifier.fillMaxSize().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("اللّٰه", fontSize = 64.sp, color = MaterialTheme.colorScheme.onPrimary)
            Spacer(Modifier.height(16.dp))
            Text(title, fontSize = 28.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onPrimary)
            Spacer(Modifier.height(8.dp))
            Text(body, fontSize = 16.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onPrimary)
            Spacer(Modifier.height(48.dp))
            Button(
                onClick = onStop,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onPrimary, contentColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth().height(64.dp)
            ) { Text("Stop", fontSize = 22.sp) }
            Spacer(Modifier.height(14.dp))
            OutlinedButton(
                onClick = onSnooze,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onPrimary),
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("Snooze ${AlarmService.SNOOZE_MINUTES} minutes", fontSize = 18.sp) }
        }
    }
}
