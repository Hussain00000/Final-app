package com.example.mydeen

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Random

/**
 * Endless Quran verses and hadith from free public sources (no key needed, internet required):
 *  - Quran: api.alquran.cloud (Arabic, transliteration in English letters, Sahih International English, Urdu)
 *  - Hadith: the fawazahmed0 hadith-api on jsDelivr (Arabic, English, Urdu)
 * Only short ones that fit on a status picture are used.
 */
object OnlineVerses {
    private val rnd = Random()
    private const val UA = "MyDeenApp/1.0 (Android; Islamic status maker)"

    private class Collection(val id: String, val name: String, val max: Int)

    private val collections = listOf(
        // Only the two Sahih collections, so nothing graded weak can appear on a status.
        Collection("bukhari", "Sahih al-Bukhari", 7000),
        Collection("muslim", "Sahih Muslim", 5000)
    )

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 12000
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode != 200) throw java.io.IOException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun clean(s: String): String = s.replace(Regex("<[^>]*>"), "").replace(Regex("\\s+"), " ").trim()

    /**
     * The online sources only have Urdu in Urdu script. [RomanUrdu] turns it into proper Roman Urdu
     * (Urdu in English letters) offline, with a hand-written Islamic word list, so the spelling is the
     * same every time and never Urdu script.
     */
    private fun romanUrdu(urdu: String): String = RomanUrdu.convert(urdu)

    /** A new random verse or hadith. [filter] is "all", "quran" or "hadith". Null when nothing could be loaded. */
    fun random(filter: String): StatusVerse? {
        val wantQuran = when (filter) {
            "quran" -> true
            "hadith" -> false
            else -> rnd.nextBoolean()
        }
        val first = if (wantQuran) randomAyah() else randomHadith()
        if (first != null || filter != "all") return first
        return if (wantQuran) randomHadith() else randomAyah()
    }

    private fun randomAyah(): StatusVerse? {
        for (attempt in 0 until 8) {
            try {
                val n = 1 + rnd.nextInt(6236)
                val json = JSONObject(get("https://api.alquran.cloud/v1/ayah/$n/editions/quran-uthmani,en.transliteration,en.sahih,ur.jalandhry"))
                val arr = json.getJSONArray("data")
                var ar = ""; var ro = ""; var en = ""; var ur = ""
                var surahName = ""; var surahNo = 0; var inSurah = 0
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val text = clean(o.optString("text"))
                    when (o.getJSONObject("edition").optString("identifier")) {
                        "quran-uthmani" -> ar = text
                        "en.transliteration" -> ro = text
                        "en.sahih" -> en = text
                        "ur.jalandhry" -> ur = text
                    }
                    val surah = o.optJSONObject("surah")
                    if (surah != null) {
                        surahName = surah.optString("englishName")
                        surahNo = surah.optInt("number")
                    }
                    inSurah = o.optInt("numberInSurah")
                }
                if (inSurah == 1 && surahNo != 1) continue          // first verses carry the Bismillah in the text
                if (ar.isEmpty() || en.isEmpty()) continue
                if (ar.length > 170 || en.length > 260) continue    // too long for one status
                val roman = romanUrdu(ur)
                if (roman.isBlank() || roman.length > 300) continue                    // keep the picture easy to read
                return StatusVerse(ar, ro, en, roman, "Surah $surahName $surahNo:$inSurah", true)
            } catch (e: Exception) {
                // try another verse
            }
        }
        return null
    }

    private fun hadithText(json: String): String {
        val root = JSONObject(json)
        val obj = root.optJSONArray("hadiths")?.optJSONObject(0) ?: root
        return clean(obj.optString("text"))
    }

    /**
     * A short hadith: only the Prophet's ﷺ words (the chain of narrators is cut away by [HadithShort]).
     * English is checked first because it is the cheapest way to reject a long hadith.
     */
    private fun randomHadith(): StatusVerse? {
        val deadline = System.currentTimeMillis() + 25000
        var attempt = 0
        while (attempt < 40 && System.currentTimeMillis() < deadline) {
            attempt++
            try {
                val col = collections[rnd.nextInt(collections.size)]
                val n = 1 + rnd.nextInt(col.max)
                val base = "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/"
                val en = HadithShort.english(hadithText(get("${base}eng-${col.id}/$n.json"))) ?: continue
                val ar = HadithShort.arabic(hadithText(get("${base}ara-${col.id}/$n.json"))) ?: continue
                val urRaw = hadithText(get("${base}urd-${col.id}/$n.json"))
                val ur = HadithShort.romanUrdu(urRaw) ?: continue
                // the three editions must be the same hadith: Roman Urdu is normally 0.6x to 2.2x as long as the English
                val ratio = ur.length.toDouble() / en.length
                if (ratio < 0.6 || ratio > 2.2) continue
                return StatusVerse(ar, "", en, ur, "${col.name} $n", false)
            } catch (e: Exception) {
                // try another hadith
            }
        }
        return null
    }
}
