package com.example.mydeen

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

data class Mulakhat(val id: Long, val name: String, val number: String, val notes: String)

private const val CONTACTS_KEY = "mulakhat_list"

fun loadContacts(prefs: SharedPreferences): List<Mulakhat> = try {
    val arr = JSONArray(prefs.getString(CONTACTS_KEY, "[]") ?: "[]")
    (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        Mulakhat(o.getLong("id"), o.optString("name"), o.optString("number"), o.optString("notes"))
    }
} catch (e: Exception) { emptyList() }

fun saveContacts(prefs: SharedPreferences, list: List<Mulakhat>) {
    val arr = JSONArray()
    list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("number", it.number).put("notes", it.notes)) }
    prefs.edit().putString(CONTACTS_KEY, arr.toString()).apply()
}

/** Menu screen: everyone you added for Ghar Ghar Mulakhat, with number and notes. */
@Composable
fun PeopleScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var contacts by remember { mutableStateOf(loadContacts(prefs)) }
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Mulakhat?>(null) }
    var confirmDelete by remember { mutableStateOf<Mulakhat?>(null) }

    if (showDialog) {
        ContactDialog(
            initial = editing,
            onSave = { n, num, notes ->
                val cur = editing
                val list = if (cur == null) contacts + Mulakhat(System.currentTimeMillis(), n, num, notes)
                else contacts.map { if (it.id == cur.id) Mulakhat(cur.id, n, num, notes) else it }
                contacts = list
                saveContacts(prefs, list)
                showDialog = false
                editing = null
            },
            onDelete = editing?.let { cur -> { confirmDelete = cur; showDialog = false; editing = null } },
            onDismiss = { showDialog = false; editing = null }
        )
    }
    confirmDelete?.let { victim ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete ${victim.name}?") },
            text = { Text("This removes them and their notes from your list.") },
            confirmButton = {
                TextButton(onClick = {
                    val list = contacts.filter { it.id != victim.id }
                    contacts = list
                    saveContacts(prefs, list)
                    confirmDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Ghar Ghar Mulakhat — ${contacts.size} " + if (contacts.size == 1) "person" else "people", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Button(onClick = { editing = null; showDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Add a person") }
        if (contacts.isEmpty()) {
            Text("No one added yet. People you add from the checklist or here will show with their notes.", style = MaterialTheme.typography.bodyMedium)
        }
        contacts.forEach { c ->
            DeenCard {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(c.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (c.number.isNotEmpty()) Text("Number: ${c.number}", style = MaterialTheme.typography.bodyMedium)
                    if (c.notes.isNotEmpty()) Text("Notes: ${c.notes}", style = MaterialTheme.typography.bodyMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { editing = c; showDialog = true }) { Text("Edit") }
                        if (c.number.isNotEmpty()) {
                            TextButton(onClick = {
                                try {
                                    val tel = c.number.filter { it.isDigit() || it == '+' }
                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$tel")))
                                } catch (e: Exception) { }
                            }) { Text("Call") }
                        }
                        TextButton(onClick = { confirmDelete = c }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
fun ContactDialog(initial: Mulakhat?, onSave: (String, String, String) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var number by remember { mutableStateOf(initial?.number ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add person / house" else "Edit details") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it.replace("\n", " ").take(60) }, singleLine = true, label = { Text("Name / house") })
                OutlinedTextField(
                    value = number,
                    onValueChange = { v -> number = v.filter { it.isDigit() || it == '+' || it == ' ' || it == '-' }.take(20) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    label = { Text("Number (optional)") }
                )
                OutlinedTextField(value = notes, onValueChange = { notes = it.take(300) }, minLines = 2, label = { Text("Notes (optional)") })
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name.trim(), number.trim(), notes.trim()) }, enabled = name.isNotBlank()) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}
