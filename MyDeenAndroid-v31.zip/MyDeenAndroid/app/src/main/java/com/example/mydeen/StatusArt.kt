package com.example.mydeen

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import java.io.File
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** One Quran ayah or hadith: Arabic on top, Roman English (Arabic in English letters), English meaning, then the reference. */
class StatusVerse(val arabic: String, val roman: String, val translation: String, val source: String, val isQuran: Boolean)

/**
 * A background for the status picture. [kind] picks the design:
 * sky (moon + stars + flowers), photo (Makkah / Madinah picture), mosque (skyline) or pattern (Islamic stars).
 */
class StatusStyle(
    val name: String, val top: Int, val bottom: Int, val accent: Int,
    val flower: Int, val center: Int, val leaf: Int, val seed: Long,
    val kind: Int = StatusArt.KIND_SKY, val res: Int = 0
)

/**
 * Draws a 1080 x 1920 (9:16) picture, the size of a WhatsApp status:
 * gradient night sky, glowing crescent moon, stars, flower corners and a flower vine,
 * with the Arabic verse in the middle.
 */
object StatusArt {
    const val W = 1080
    const val H = 1920

    const val KIND_SKY = 0
    const val KIND_PHOTO = 1
    const val KIND_MOSQUE = 2
    const val KIND_PATTERN = 3

    val styles = listOf(
        // ---- moon, stars and flowers ----
        StatusStyle("Midnight", 0xFF0B1B3A.toInt(), 0xFF123B5C.toInt(), 0xFFF5D77A.toInt(), 0xFFFFC1D6.toInt(), 0xFFFFE08A.toInt(), 0xFF3FA66A.toInt(), 11),
        StatusStyle("Emerald", 0xFF052E1B.toInt(), 0xFF0F6B3F.toInt(), 0xFFF2D675.toInt(), 0xFFFFFFFF.toInt(), 0xFFF2C94C.toInt(), 0xFF6CC18A.toInt(), 22),
        StatusStyle("Royal Purple", 0xFF2A1250.toInt(), 0xFF5B2A86.toInt(), 0xFFFFD98A.toInt(), 0xFFFFB6D9.toInt(), 0xFFFFE9A8.toInt(), 0xFF5BBF8F.toInt(), 33),
        StatusStyle("Rose Dawn", 0xFF4A1230.toInt(), 0xFFB04A6B.toInt(), 0xFFFFE2A8.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD36B.toInt(), 0xFF5BB487.toInt(), 44),
        StatusStyle("Ocean Teal", 0xFF062C3A.toInt(), 0xFF0F7A7A.toInt(), 0xFFFFE08A.toInt(), 0xFFFFD1DC.toInt(), 0xFFFFF0A8.toInt(), 0xFF4CC38A.toInt(), 55),
        StatusStyle("Gold & Black", 0xFF0A0A0A.toInt(), 0xFF3A2A0E.toInt(), 0xFFE8C766.toInt(), 0xFFF5E3A8.toInt(), 0xFFB8862B.toInt(), 0xFF8FA84A.toInt(), 66),
        // ---- mosque skyline ----
        StatusStyle("Mosque Night", 0xFF0A1330.toInt(), 0xFF27406E.toInt(), 0xFFF5D77A.toInt(), 0xFFFFC1D6.toInt(), 0xFFFFE08A.toInt(), 0xFF3FA66A.toInt(), 77, KIND_MOSQUE),
        StatusStyle("Mosque Sunset", 0xFF3B1D5E.toInt(), 0xFFE0734A.toInt(), 0xFFFFE6A0.toInt(), 0xFFFFD1DC.toInt(), 0xFFFFE08A.toInt(), 0xFF5BB487.toInt(), 88, KIND_MOSQUE),
        StatusStyle("Mosque Green", 0xFF04261A.toInt(), 0xFF1E7A52.toInt(), 0xFFF2D675.toInt(), 0xFFFFFFFF.toInt(), 0xFFF2C94C.toInt(), 0xFF6CC18A.toInt(), 99, KIND_MOSQUE),
        // ---- Islamic star pattern ----
        StatusStyle("Star Pattern", 0xFF0E2A47.toInt(), 0xFF1D5C7A.toInt(), 0xFFF5D77A.toInt(), 0xFFFFC1D6.toInt(), 0xFFFFE08A.toInt(), 0xFF3FA66A.toInt(), 111, KIND_PATTERN),
        StatusStyle("Pattern Maroon", 0xFF3A0A1C.toInt(), 0xFF7A1F3D.toInt(), 0xFFFFD98A.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD36B.toInt(), 0xFF5BB487.toInt(), 122, KIND_PATTERN),
        // ---- Makkah and Madinah pictures ----
        StatusStyle("Makkah Day", 0xFF1B3A5C.toInt(), 0xFF2B5C8A.toInt(), 0xFFFFE08A.toInt(), 0xFFFFFFFF.toInt(), 0xFFF2C94C.toInt(), 0xFF6CC18A.toInt(), 133, KIND_PHOTO, R.drawable.bg_makkah_day),
        StatusStyle("Makkah Night", 0xFF0A0F1F.toInt(), 0xFF1B2540.toInt(), 0xFFF5D77A.toInt(), 0xFFFFFFFF.toInt(), 0xFFF2C94C.toInt(), 0xFF6CC18A.toInt(), 144, KIND_PHOTO, R.drawable.bg_makkah_night),
        StatusStyle("Madinah Day", 0xFF1E5A3C.toInt(), 0xFF3C8C64.toInt(), 0xFFFFE08A.toInt(), 0xFFFFFFFF.toInt(), 0xFFF2C94C.toInt(), 0xFF6CC18A.toInt(), 155, KIND_PHOTO, R.drawable.bg_madinah_day),
        StatusStyle("Madinah Night", 0xFF06150F.toInt(), 0xFF123A2A.toInt(), 0xFFF5D77A.toInt(), 0xFFFFFFFF.toInt(), 0xFFF2C94C.toInt(), 0xFF6CC18A.toInt(), 166, KIND_PHOTO, R.drawable.bg_madinah_night)
    )

    val verses = listOf(
        // ---- Quran ----
        StatusVerse("إِنَّ مَعَ الْعُسْرِ يُسْرًا", "Inna ma'al 'usri yusra", "Indeed, with hardship comes ease.", "Surah Ash-Sharh 94:6", true),
        StatusVerse("أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ", "Alaa bi-dhikrillaahi tatma'innul quloob", "Surely, in the remembrance of Allah do hearts find rest.", "Surah Ar-Ra‘d 13:28", true),
        StatusVerse("لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا", "Laa yukallifullaahu nafsan illaa wus'ahaa", "Allah does not burden a soul beyond what it can bear.", "Surah Al-Baqarah 2:286", true),
        StatusVerse("وَمَنْ يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ", "Wa man yatawakkal 'alallaahi fahuwa hasbuh", "And whoever relies upon Allah, He is sufficient for him.", "Surah At-Talaq 65:3", true),
        StatusVerse("فَاذْكُرُونِي أَذْكُرْكُمْ", "Fadhkuroonee adhkurkum", "So remember Me; I will remember you.", "Surah Al-Baqarah 2:152", true),
        StatusVerse("لَا تَقْنَطُوا مِنْ رَحْمَةِ اللَّهِ", "Laa taqnatoo min rahmatillaah", "Do not despair of the mercy of Allah.", "Surah Az-Zumar 39:53", true),
        StatusVerse("لَا تَحْزَنْ إِنَّ اللَّهَ مَعَنَا", "Laa tahzan innallaaha ma'anaa", "Do not grieve; indeed Allah is with us.", "Surah At-Tawbah 9:40", true),
        StatusVerse("إِنَّ اللَّهَ مَعَ الصَّابِرِينَ", "Innallaaha ma'as-saabireen", "Indeed, Allah is with the patient.", "Surah Al-Baqarah 2:153", true),
        StatusVerse("ادْعُونِي أَسْتَجِبْ لَكُمْ", "Ud'oonee astajib lakum", "Call upon Me; I will respond to you.", "Surah Ghafir 40:60", true),
        StatusVerse("لَئِنْ شَكَرْتُمْ لَأَزِيدَنَّكُمْ", "La'in shakartum la-azeedannakum", "If you are grateful, I will surely increase you.", "Surah Ibrahim 14:7", true),
        StatusVerse("حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ", "Hasbunallaahu wa ni'mal wakeel", "Allah is sufficient for us, and He is the best disposer of affairs.", "Surah Aal-Imran 3:173", true),
        StatusVerse("فَإِنِّي قَرِيبٌ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ", "Fa-innee qareeb, ujeebu da'watad-daa'i idhaa da'aan", "I am near; I respond to the call of the caller when he calls upon Me.", "Surah Al-Baqarah 2:186", true),
        StatusVerse("وَلَا تَهِنُوا وَلَا تَحْزَنُوا وَأَنْتُمُ الْأَعْلَوْنَ إِنْ كُنْتُمْ مُؤْمِنِينَ", "Wa laa tahinoo wa laa tahzanoo wa antumul a'lawna in kuntum mu'mineen", "Do not weaken and do not grieve, for you will have the upper hand if you are true believers.", "Surah Aal-Imran 3:139", true),
        // ---- Hadith ----
        StatusVerse("إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ", "Innamal a'maalu bin-niyyaat", "Actions are judged by intentions.", "Sahih al-Bukhari 1, Sahih Muslim 1907", false),
        StatusVerse("الطُّهُورُ شَطْرُ الْإِيمَانِ", "At-tuhooru shatrul eemaan", "Cleanliness is half of faith.", "Sahih Muslim 223", false),
        StatusVerse("الدُّعَاءُ هُوَ الْعِبَادَةُ", "Ad-du'aa'u huwal 'ibaadah", "Du‘a is worship.", "Jami at-Tirmidhi 3371", false),
        StatusVerse("تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ صَدَقَةٌ", "Tabassumuka fee wajhi akheeka sadaqah", "Smiling in the face of your brother is charity.", "Jami at-Tirmidhi 1956", false),
        StatusVerse("خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ", "Khayrukum man ta'allamal Qur'aana wa 'allamah", "The best of you are those who learn the Qur’an and teach it.", "Sahih al-Bukhari 5027", false),
        StatusVerse("لَا تَغْضَبْ", "Laa taghdab", "Do not become angry.", "Sahih al-Bukhari 6116", false),
        StatusVerse("مَنْ لَا يَرْحَمْ لَا يُرْحَمْ", "Man laa yarham laa yurham", "Whoever does not show mercy will not be shown mercy.", "Sahih al-Bukhari 6013, Sahih Muslim 2318", false),
        StatusVerse("مَا نَقَصَتْ صَدَقَةٌ مِنْ مَالٍ", "Maa naqasat sadaqatun min maal", "Charity never decreases wealth.", "Sahih Muslim 2588", false),
        StatusVerse("خَيْرُكُمْ أَحْسَنُكُمْ أَخْلَاقًا", "Khayrukum ahsanukum akhlaaqa", "The best of you are those with the best character.", "Sahih al-Bukhari 3559, Sahih Muslim 2321", false),
        StatusVerse("الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ", "Al-kalimatut-tayyibatu sadaqah", "A good word is charity.", "Sahih al-Bukhari 2989, Sahih Muslim 1009", false),
        StatusVerse("مَنْ صَلَّى الْفَجْرَ فَهُوَ فِي ذِمَّةِ اللَّهِ", "Man sallal fajra fahuwa fee dhimmatillaah", "Whoever prays Fajr is under the protection of Allah.", "Sahih Muslim 657", false),
        StatusVerse("لَا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ", "Laa yu'minu ahadukum hattaa yuhibba li-akheehi maa yuhibbu li-nafsih", "None of you truly believes until he loves for his brother what he loves for himself.", "Sahih al-Bukhari 13, Sahih Muslim 45", false)
    )

    private const val BISMILLAH = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"

    private fun alpha(color: Int, a: Int): Int = (a shl 24) or (color and 0x00FFFFFF)

    private fun starPath(cx: Float, cy: Float, outer: Float, inner: Float, points: Int, rotation: Double = -PI / 2): Path {
        val p = Path()
        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) outer else inner
            val a = rotation + i * PI / points
            val x = cx + (r * cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    private fun drawLeaf(c: Canvas, len: Float, paint: Paint) {
        val w = len * 0.17f
        val p = Path()
        p.moveTo(0f, 0f)
        p.quadTo(len * 0.5f, -w, len, 0f)
        p.quadTo(len * 0.5f, w, 0f, 0f)
        c.drawPath(p, paint)
        val vein = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 3f; color = alpha(Color.WHITE, 70)
        }
        c.drawLine(len * 0.08f, 0f, len * 0.9f, 0f, vein)
    }

    private fun drawFlower(c: Canvas, cx: Float, cy: Float, size: Float, style: StatusStyle, rot: Float) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.style = Paint.Style.STROKE; strokeWidth = (size * 0.02f).coerceAtLeast(1.5f)
            color = alpha(ColorUtils.blendARGB(style.flower, Color.BLACK, 0.35f), 140)
        }
        val petals = 8
        val step = 360f / petals
        fill.color = alpha(style.flower, 240)
        for (i in 0 until petals) {
            c.save(); c.rotate(rot + i * step, cx, cy)
            val r = RectF(cx - size * 0.21f, cy - size, cx + size * 0.21f, cy)
            c.drawOval(r, fill); c.drawOval(r, line)
            c.restore()
        }
        fill.color = ColorUtils.blendARGB(style.flower, Color.WHITE, 0.5f)
        for (i in 0 until petals) {
            c.save(); c.rotate(rot + step / 2f + i * step, cx, cy)
            val r = RectF(cx - size * 0.15f, cy - size * 0.66f, cx + size * 0.15f, cy)
            c.drawOval(r, fill); c.drawOval(r, line)
            c.restore()
        }
        fill.color = style.center
        c.drawCircle(cx, cy, size * 0.2f, fill)
        fill.color = alpha(Color.WHITE, 120)
        c.drawCircle(cx - size * 0.05f, cy - size * 0.05f, size * 0.06f, fill)
    }

    /** Leaves + flowers growing out of a corner. (x, y) is the corner; flips point it inward. */
    private fun drawCluster(c: Canvas, x: Float, y: Float, scale: Float, flipX: Boolean, flipY: Boolean, style: StatusStyle) {
        c.save()
        c.translate(x, y)
        c.scale(if (flipX) -scale else scale, if (flipY) -scale else scale)
        val lp = Paint(Paint.ANTI_ALIAS_FLAG)
        val angles = floatArrayOf(4f, 22f, 40f, 58f, 76f)
        val lens = floatArrayOf(330f, 270f, 300f, 250f, 320f)
        for (i in angles.indices) {
            lp.color = alpha(ColorUtils.blendARGB(style.leaf, Color.BLACK, if (i % 2 == 0) 0f else 0.28f), 240)
            c.save(); c.rotate(angles[i]); drawLeaf(c, lens[i], lp); c.restore()
        }
        drawFlower(c, 100f, 100f, 125f, style, 10f)
        drawFlower(c, 285f, 55f, 78f, style, 0f)
        drawFlower(c, 55f, 285f, 78f, style, 20f)
        drawFlower(c, 205f, 215f, 52f, style, 5f)
        drawFlower(c, 370f, 28f, 40f, style, 15f)
        drawFlower(c, 28f, 370f, 40f, style, 0f)
        c.restore()
    }

    private fun drawVine(c: Canvas, y: Float, style: StatusStyle) {
        val stem = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.style = Paint.Style.STROKE; strokeWidth = 5f; color = alpha(style.leaf, 220)
        }
        val path = Path()
        val x0 = 380f
        val x1 = W - 380f
        path.moveTo(x0, y)
        var x = x0
        var up = true
        while (x < x1) {
            val nx = x + 60f
            path.quadTo(x + 30f, if (up) y - 26f else y + 26f, nx, y)
            up = !up
            x = nx
        }
        c.drawPath(path, stem)
        val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = alpha(style.leaf, 235) }
        var k = 0
        x = x0 + 30f
        while (x < x1) {
            c.save(); c.translate(x, y); c.rotate(if (k % 2 == 0) -50f else 50f); drawLeaf(c, 46f, lp); c.restore()
            x += 60f; k++
        }
        val n = 5
        for (i in 0 until n) {
            val fx = x0 + 40f + i * ((x1 - x0 - 80f) / (n - 1))
            drawFlower(c, fx, y, if (i == n / 2) 40f else 28f, style, 0f)
        }
    }

    private fun layoutFor(text: String, paint: TextPaint, width: Int, rtl: Boolean, spacing: Float): StaticLayout {
        val b = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, spacing)
            .setIncludePad(true)
            .setBreakStrategy(Layout.BREAK_STRATEGY_BALANCED)
            .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
        if (rtl) b.setTextDirection(TextDirectionHeuristics.RTL)
        return b.build()
    }

    private fun drawBlock(c: Canvas, layout: StaticLayout, x: Float, y: Float) {
        c.save(); c.translate(x, y); layout.draw(c); c.restore()
    }

    /** Crescent shape: a disc with a second disc cut out of it. */
    private fun crescentPath(cx: Float, cy: Float, r: Float): Path {
        val outer = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        val inner = Path().apply { addCircle(cx + r * 0.34f, cy - r * 0.04f, r * 0.9f, Path.Direction.CW) }
        outer.op(inner, Path.Op.DIFFERENCE)
        return outer
    }

    /** Glowing crescent moon with a little star inside it. */
    private fun drawMoon(c: Canvas, p: Paint, style: StatusStyle, moonX: Float, moonY: Float, moonR: Float) {
        p.shader = RadialGradient(moonX, moonY, 380f, intArrayOf(alpha(style.accent, 110), alpha(style.accent, 0)), null, Shader.TileMode.CLAMP)
        c.drawCircle(moonX, moonY, 380f, p)
        p.shader = null

        c.save()
        c.rotate(-18f, moonX, moonY)
        p.shader = LinearGradient(moonX - moonR, moonY - moonR, moonX + moonR, moonY + moonR,
            ColorUtils.blendARGB(style.accent, Color.WHITE, 0.55f), style.accent, Shader.TileMode.CLAMP)
        c.drawPath(crescentPath(moonX, moonY, moonR), p)
        p.shader = null
        p.color = style.accent
        c.drawPath(starPath(moonX + moonR * 0.45f, moonY, moonR * 0.2f, moonR * 0.085f, 5), p)
        c.restore()
    }

    /** Random stars, kept out of the moon and the text area so the words stay easy to read. */
    private fun drawStars(c: Canvas, style: StatusStyle, moonX: Float, moonY: Float, moonR: Float, hasMoon: Boolean, maxY: Float) {
        val rnd = Random(style.seed)
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        val wf = W.toFloat()
        repeat(90) {
            val x = rnd.nextFloat() * wf
            val y = rnd.nextFloat() * (maxY - 60f)
            val kind = rnd.nextInt(3)
            val a = 110 + rnd.nextInt(140)
            val size = 8f + rnd.nextFloat() * 16f
            val dx = x - moonX
            val dy = y - moonY
            val nearMoon = hasMoon && dx * dx + dy * dy < (moonR * 2.2f) * (moonR * 2.2f)
            val inText = y > 520f && y < 1580f && x > 110f && x < wf - 110f
            if (nearMoon || inText) return@repeat
            when (kind) {
                0 -> { sp.color = alpha(Color.WHITE, a); c.drawCircle(x, y, 2f + size * 0.15f, sp) }
                1 -> { sp.color = alpha(Color.WHITE, a); c.drawPath(starPath(x, y, size, size * 0.28f, 4), sp) }
                else -> { sp.color = alpha(style.accent, a); c.drawPath(starPath(x, y, size * 0.9f, size * 0.4f, 5), sp) }
            }
        }
    }

    /** Makkah / Madinah picture filling the whole status, with a dark veil so the text is readable. */
    private fun drawPhoto(context: Context, c: Canvas, style: StatusStyle) {
        val wf = W.toFloat()
        val hf = H.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val photo = try { BitmapFactory.decodeResource(context.resources, style.res) } catch (e: Exception) { null }
        if (photo != null) {
            // centre-crop the picture to 9:16
            val targetRatio = wf / hf
            val srcRatio = photo.width.toFloat() / photo.height.toFloat()
            val src = if (srcRatio > targetRatio) {
                val w = (photo.height * targetRatio).toInt()
                val left = (photo.width - w) / 2
                Rect(left, 0, left + w, photo.height)
            } else {
                val h = (photo.width / targetRatio).toInt()
                val top = (photo.height - h) / 2
                Rect(0, top, photo.width, top + h)
            }
            c.drawBitmap(photo, src, RectF(0f, 0f, wf, hf), p)
            photo.recycle()
        } else {
            p.shader = LinearGradient(0f, 0f, 0f, hf, style.top, style.bottom, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, wf, hf, p)
            p.shader = null
        }
        // dark veil: lighter at the top and bottom, darker behind the text
        p.shader = LinearGradient(
            0f, 0f, 0f, hf,
            intArrayOf(alpha(Color.BLACK, 95), alpha(Color.BLACK, 150), alpha(Color.BLACK, 175), alpha(Color.BLACK, 150), alpha(Color.BLACK, 110)),
            floatArrayOf(0f, 0.25f, 0.55f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, wf, hf, p)
        p.shader = null
    }

    /** Soft Islamic eight-point star pattern over the whole picture. */
    private fun drawPattern(c: Canvas, style: StatusStyle) {
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.style = Paint.Style.STROKE; strokeWidth = 3f; color = alpha(style.accent, 55)
        }
        val cell = 180f
        var row = 0
        var y = 0f
        while (y < H + cell) {
            var x = if (row % 2 == 0) 0f else cell / 2f
            while (x < W + cell) {
                c.drawPath(starPath(x, y, 78f, 48f, 8), line)
                c.drawCircle(x, y, 26f, line)
                x += cell
            }
            y += cell / 2f
            row++
        }
    }

    /** Dark mosque skyline along the bottom: three domes, two minarets, glowing windows. */
    private fun drawMosque(c: Canvas, style: StatusStyle) {
        val wf = W.toFloat()
        val hf = H.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // glow on the horizon
        p.shader = LinearGradient(0f, 1450f, 0f, hf, alpha(style.accent, 0), alpha(style.accent, 85), Shader.TileMode.CLAMP)
        c.drawRect(0f, 1450f, wf, hf, p)
        p.shader = null

        p.color = ColorUtils.blendARGB(style.top, Color.BLACK, 0.6f)
        val ground = 1800f

        fun dome(cx: Float, base: Float, r: Float) {
            c.drawArc(RectF(cx - r, base - r, cx + r, base + r), 180f, 180f, true, p)
            c.drawRect(cx - 6f, base - r - r * 0.28f, cx + 6f, base - r + 4f, p)          // spike
            c.drawCircle(cx, base - r - r * 0.28f, 9f, p)                                   // ball
        }
        fun minaret(cx: Float) {
            c.drawRect(cx - 26f, 1520f, cx + 26f, ground, p)
            c.drawRect(cx - 38f, 1600f, cx + 38f, 1618f, p)                                 // balcony
            val cone = Path().apply { moveTo(cx - 30f, 1522f); lineTo(cx, 1430f); lineTo(cx + 30f, 1522f); close() }
            c.drawPath(cone, p)
            c.drawCircle(cx, 1426f, 8f, p)
        }

        c.drawRect(0f, ground, wf, hf, p)
        // main building and domes
        c.drawRect(400f, 1720f, 680f, ground, p)
        dome(540f, 1720f, 140f)
        c.drawRect(250f, 1750f, 400f, ground, p)
        dome(325f, 1750f, 75f)
        c.drawRect(680f, 1750f, 830f, ground, p)
        dome(755f, 1750f, 75f)
        minaret(140f)
        minaret(940f)
        // little crescent on the main dome
        p.color = style.accent
        c.drawPath(crescentPath(540f, 1545f, 20f), p)

        // glowing windows
        p.color = alpha(style.accent, 215)
        val windows = floatArrayOf(450f, 510f, 570f, 630f)
        for (wx in windows) {
            c.drawRoundRect(RectF(wx - 14f, 1750f, wx + 14f, 1794f), 14f, 14f, p)
        }
        c.drawRoundRect(RectF(311f, 1770f, 339f, 1796f), 12f, 12f, p)
        c.drawRoundRect(RectF(741f, 1770f, 769f, 1796f), 12f, 12f, p)
        c.drawRoundRect(RectF(130f, 1650f, 150f, 1690f), 10f, 10f, p)
        c.drawRoundRect(RectF(930f, 1650f, 950f, 1690f), 10f, 10f, p)
    }

    /**
     * Draws the 1080 x 1920 picture: the chosen background, then Bismillah, the Arabic verse,
     * the Roman English line (optional), a divider, the English meaning and the reference.
     */
    fun render(context: Context, style: StatusStyle, verse: StatusVerse, showRoman: Boolean = true): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val wf = W.toFloat()
        val hf = H.toFloat()
        val moonX = wf / 2f
        val moonY = 270f
        val moonR = 125f

        // 1. background
        if (style.kind == KIND_PHOTO) {
            drawPhoto(context, c, style)
        } else {
            p.shader = LinearGradient(0f, 0f, 0f, hf, style.top, style.bottom, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, wf, hf, p)
            p.shader = null
        }
        if (style.kind == KIND_PATTERN) drawPattern(c, style)

        // 2. stars and moon (not on the photo backgrounds)
        if (style.kind != KIND_PHOTO) {
            if (style.kind != KIND_PATTERN) drawStars(c, style, moonX, moonY, moonR, true, hf)
            drawMoon(c, p, style, moonX, moonY, moonR)
        }

        // 3. double gold frame
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.style = Paint.Style.STROKE }
        frame.strokeWidth = 4f; frame.color = alpha(style.accent, 170)
        c.drawRoundRect(RectF(36f, 36f, wf - 36f, hf - 36f), 36f, 36f, frame)
        frame.strokeWidth = 2f; frame.color = alpha(style.accent, 90)
        c.drawRoundRect(RectF(54f, 54f, wf - 54f, hf - 54f), 26f, 26f, frame)

        // 4. decoration that belongs to the design
        when (style.kind) {
            KIND_SKY -> {
                drawCluster(c, 0f, 0f, 0.72f, false, false, style)
                drawCluster(c, wf, 0f, 0.72f, true, false, style)
                drawCluster(c, 0f, hf, 1.0f, false, true, style)
                drawCluster(c, wf, hf, 1.0f, true, true, style)
                drawVine(c, hf - 95f, style)
            }
            KIND_MOSQUE -> {
                drawCluster(c, 0f, 0f, 0.6f, false, false, style)
                drawCluster(c, wf, 0f, 0.6f, true, false, style)
                drawMosque(c, style)
            }
            KIND_PATTERN -> {
                drawCluster(c, 0f, 0f, 0.72f, false, false, style)
                drawCluster(c, wf, 0f, 0.72f, true, false, style)
                drawCluster(c, 0f, hf, 0.9f, false, true, style)
                drawCluster(c, wf, hf, 0.9f, true, true, style)
                drawVine(c, hf - 95f, style)
            }
            else -> { // photo
                drawCluster(c, 0f, 0f, 0.6f, false, false, style)
                drawCluster(c, wf, 0f, 0.6f, true, false, style)
                drawVine(c, hf - 95f, style)
            }
        }

        // 5. text
        val textW = W - 300
        val shadow = 0x80000000.toInt()
        val withRoman = showRoman && verse.roman.isNotBlank()

        val bp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = style.accent; textSize = 46f; typeface = Typeface.DEFAULT; setShadowLayer(6f, 0f, 2f, shadow)
        }
        drawBlock(c, layoutFor(BISMILLAH, bp, textW, true, 1.2f), 150f, 440f)

        val ap = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; typeface = Typeface.DEFAULT; setShadowLayer(10f, 0f, 3f, shadow)
        }
        var size = 104f
        ap.textSize = size
        var arabic = layoutFor(verse.arabic, ap, textW, true, 1.45f)
        val maxArabic = if (withRoman) 400 else 520
        while (arabic.height > maxArabic && size > 44f) {
            size -= 4f; ap.textSize = size
            arabic = layoutFor(verse.arabic, ap, textW, true, 1.45f)
        }

        val rp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ColorUtils.blendARGB(style.accent, Color.WHITE, 0.4f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); letterSpacing = 0.02f
            setShadowLayer(6f, 0f, 2f, shadow)
        }
        var rsize = 46f
        rp.textSize = rsize
        var rom = layoutFor(if (withRoman) verse.roman else " ", rp, textW, false, 1.2f)
        while (withRoman && rom.height > 190 && rsize > 28f) {
            rsize -= 2f; rp.textSize = rsize
            rom = layoutFor(verse.roman, rp, textW, false, 1.2f)
        }

        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = alpha(Color.WHITE, 230); typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC); setShadowLayer(6f, 0f, 2f, shadow)
        }
        val maxTrans = if (withRoman) 220 else 260
        var tsize = 44f
        tp.textSize = tsize
        var trans = layoutFor(verse.translation, tp, textW, false, 1.2f)
        while (trans.height > maxTrans && tsize > 30f) {
            tsize -= 2f; tp.textSize = tsize
            trans = layoutFor(verse.translation, tp, textW, false, 1.2f)
        }

        val srcP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = style.accent; textSize = 38f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); setShadowLayer(6f, 0f, 2f, shadow)
        }
        val source = layoutFor("— " + verse.source + " —", srcP, textW, false, 1.15f)

        val gap1 = if (withRoman) 36 else 56
        val ornH = 44
        val gap2 = if (withRoman) 34 else 52
        val gapR = 26
        val gap3 = 40
        val zoneTop = 540
        val zoneBottom = if (style.kind == KIND_MOSQUE) 1500 else 1590
        val zoneH = zoneBottom - zoneTop

        fun totalHeight(): Int {
            var t = arabic.height + gap1 + ornH + gap2 + trans.height + gap3 + source.height
            if (withRoman) t += rom.height + gapR
            return t
        }
        while (totalHeight() > zoneH && size > 44f) {
            size -= 4f; ap.textSize = size
            arabic = layoutFor(verse.arabic, ap, textW, true, 1.45f)
        }

        var y = zoneTop + (zoneH - totalHeight()) / 2f
        if (y < zoneTop) y = zoneTop.toFloat()

        drawBlock(c, arabic, 150f, y)
        y += arabic.height + gap1

        // divider: gold lines with an 8-point star in the middle
        val oy = y + ornH / 2f
        val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = alpha(style.accent, 190); strokeWidth = 3f }
        c.drawLine(wf / 2f - 250f, oy, wf / 2f - 44f, oy, lp)
        c.drawLine(wf / 2f + 44f, oy, wf / 2f + 250f, oy, lp)
        p.color = style.accent
        c.drawPath(starPath(wf / 2f, oy, 22f, 11f, 8), p)
        c.drawCircle(wf / 2f - 250f, oy, 5f, p)
        c.drawCircle(wf / 2f + 250f, oy, 5f, p)
        y += ornH + gap2

        if (withRoman) {
            drawBlock(c, rom, 150f, y)
            y += rom.height + gapR
        }
        drawBlock(c, trans, 150f, y)
        y += trans.height + gap3
        drawBlock(c, source, 150f, y)

        return bmp
    }
}

/** Saving and sharing the finished picture. */
object StatusShare {
    private fun cacheFile(context: Context, bmp: Bitmap): File {
        val dir = File(context.cacheDir, "status")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "islamic_status_" + System.currentTimeMillis() + ".jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 94, it) }
        return f
    }

    /** whatsApp = true tries WhatsApp first (it then offers "My status"); otherwise the normal share sheet. */
    fun share(context: Context, bmp: Bitmap, whatsApp: Boolean) {
        val file = cacheFile(context, bmp)
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (whatsApp) {
            try {
                context.startActivity(Intent(send).setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (e: Exception) { /* WhatsApp not installed: fall through to the share sheet */ }
        }
        context.startActivity(Intent.createChooser(send, "Share status").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Saves to Pictures/MyDeen. Needs Android 10+ (no storage permission required). */
    fun saveToGallery(context: Context, bmp: Bitmap): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        return try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "MyDeen_status_" + System.currentTimeMillis() + ".jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/MyDeen")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            context.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            true
        } catch (e: Exception) {
            false
        }
    }
}
