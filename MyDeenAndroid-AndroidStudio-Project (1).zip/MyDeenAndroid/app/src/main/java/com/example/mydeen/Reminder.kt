package com.example.mydeen

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

object Reminder {
    const val CHANNEL = "my_deen_reminders"
    const val MORNING_ID = 101
    const val NIGHT_ID = 102

    fun createChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Daily Deen reminders", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Morning routine and nightly Muhasabah reminders"
        })
    }

    fun scheduleAll(context: Context) {
        schedule(context, MORNING_ID, "morning_hour", "morning_minute", 6, 0,
            "Bismillah — your Deen routine", "Review today's worship and good-deed checklist.")
        schedule(context, NIGHT_ID, "night_hour", "night_minute", 21, 30,
            "Time for nightly Muhasabah", "Complete your checklist and reflect on your day.")
    }

    private fun schedule(context: Context, id: Int, hourKey: String, minuteKey: String, defaultHour: Int, defaultMinute: Int, title: String, body: String) {
        val prefs = context.getSharedPreferences("my_deen", Context.MODE_PRIVATE)
        val hour = prefs.getInt(hourKey, defaultHour)
        val minute = prefs.getInt(minuteKey, defaultMinute)
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", title); putExtra("body", body); putExtra("alarm_id", id)
        }
        val pending = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        } else {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminder.createChannel(context)
        val title = intent.getStringExtra("title") ?: "My Deen reminder"
        val body = intent.getStringExtra("body") ?: "Open My Deen to review your activities."
        val id = intent.getIntExtra("alarm_id", 999)
        val notification = NotificationCompat.Builder(context, Reminder.CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
        context.getSystemService(NotificationManager::class.java).notify(id, notification)
        // Schedule the next day's occurrence after this alarm fires.
        Reminder.scheduleAll(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { Reminder.scheduleAll(context) }
}
