# My Deen – themed Islamic status backgrounds

Contents
- res/drawable-nodpi/status_bg_*.jpg  – 10 backgrounds, 1080x1920 (dua, quran, hadith, namaz, sabr, shukr, tauba, sadaqah, family, default). Top ~35% is kept calm so the Arabic text is readable.
- kotlin/StatusBackgrounds.kt         – picks the matching background from the status meaning and renders the share image with the ORIGINAL ARABIC AT THE TOP.
- make_bgs.py                         – generator script (python3 make_bgs.py outdir) if you want to tweak colours/designs.

Integration (Android Studio source project)
1. Copy res/drawable-nodpi/*.jpg into app/src/main/res/drawable-nodpi/
2. Copy kotlin/StatusBackgrounds.kt into app/src/main/java/com/example/mydeen/
3. In StatusScreen.kt, replace the body of buildStatusImage(...) with:

       return StatusBackgrounds.render(
           ctx = context,
           arabic = status.arabic,      // the original Arabic field
           text = status.text,          // translation / Roman-Urdu / reminder line
           source = status.source,      // e.g. "Bukhari" (null if none)
           kind = status.type           // "ayah" | "hadith" | "dua" | "action" (whatever your type holds)
       )

   (Field names are my guess from the APK: DailyStatus has `type` and `arabic`; adjust the rest to match.)
4. Optional but recommended: add an Arabic font (Amiri or Noto Naskh Arabic) to res/font/ and pass
   arabicTypeface = ResourcesCompat.getFont(context, R.font.amiri_regular)
   Without it Android's system Arabic font is used.
5. The preview card on StatusScreen can use the same theme: StatusBackgrounds.pickTheme(arabic, text, kind).res(context)
   as the card background so what you see equals what you share.

Matching rules live in pickTheme(): tauba/forgiveness, shukr/gratitude, sabr/hardship, namaz, sadaqah/kindness,
family/friends, then by kind (dua, ayah, hadith), else default.
