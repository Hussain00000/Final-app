package com.example.mydeen

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class Outcome(val ok: Boolean, val message: String, val retry: Boolean = false)

/**
 * Saves/loads one JSON file in the user's own Google Drive "app data" area (hidden, private to this app).
 * Uses Google's Authorization API + the Drive REST API directly, so no Firebase file is needed.
 */
object DriveBackup {
    private const val FILE_NAME = "mydeen_backup.json"
    private const val BASE = "https://www.googleapis.com"

    private val request: AuthorizationRequest = AuthorizationRequest.builder()
        .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.appdata"), Scope("email"), Scope("profile")))
        .build()

    fun authorize(context: Context): Task<AuthorizationResult> =
        Identity.getAuthorizationClient(context).authorize(request)

    /** Works in the background: gives a token only if the person already agreed on the login screen. */
    fun silentToken(context: Context): String? = try {
        val r = Tasks.await(authorize(context), 30, TimeUnit.SECONDS)
        if (r.hasResolution()) null else r.accessToken
    } catch (e: Exception) { null }

    private fun call(method: String, url: String, token: String, body: ByteArray? = null, contentType: String? = null, override: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.setRequestProperty("Authorization", "Bearer $token")
            if (override != null) c.setRequestProperty("X-HTTP-Method-Override", override)
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", contentType ?: "application/json")
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally {
            c.disconnect()
        }
    }

    /** Returns (email, name) of the signed-in Google account. */
    fun userInfo(token: String): Pair<String, String>? = try {
        val (code, text) = call("GET", "$BASE/oauth2/v3/userinfo", token)
        if (code in 200..299) {
            val o = JSONObject(text)
            Pair(o.optString("email"), o.optString("name"))
        } else null
    } catch (e: Exception) { null }

    /** Returns (fileId, modifiedTime) of the backup file, or null if there is none. */
    private fun findFile(token: String): Pair<String, String>? {
        val q = URLEncoder.encode("name='$FILE_NAME'", "UTF-8")
        val f = URLEncoder.encode("files(id,modifiedTime)", "UTF-8")
        val (code, text) = call("GET", "$BASE/drive/v3/files?spaces=appDataFolder&q=$q&fields=$f", token)
        if (code !in 200..299) throw IllegalStateException("Drive error $code")
        val arr: JSONArray = JSONObject(text).optJSONArray("files") ?: return null
        if (arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        return Pair(o.getString("id"), o.optString("modifiedTime"))
    }

    /** modifiedTime (ISO text) of the Drive backup, "" if none, null if it couldn't be checked. */
    fun remoteInfo(token: String): String? = try {
        findFile(token)?.second ?: ""
    } catch (e: Exception) { null }

    private fun upload(token: String, json: String) {
        val existing = findFile(token)
        val (code, text) = if (existing != null) {
            call("POST", "$BASE/upload/drive/v3/files/${existing.first}?uploadType=media", token, json.toByteArray(Charsets.UTF_8), "application/json", "PATCH")
        } else {
            val b = "mydeen_boundary_7f3a"
            val meta = JSONObject().put("name", FILE_NAME).put("parents", JSONArray().put("appDataFolder")).toString()
            val body = "--$b\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$b\r\nContent-Type: application/json\r\n\r\n$json\r\n--$b--"
            call("POST", "$BASE/upload/drive/v3/files?uploadType=multipart", token, body.toByteArray(Charsets.UTF_8), "multipart/related; boundary=$b")
        }
        if (code !in 200..299) throw IllegalStateException("Drive upload error $code $text")
    }

    fun backupNow(context: Context): Outcome {
        val token = silentToken(context) ?: return Outcome(false, "Please login with Google again.")
        return try {
            upload(token, Account.export(context))
            Store.prefs(context).edit().putLong("drive_last", System.currentTimeMillis()).apply()
            Outcome(true, "Backup saved to Google Drive.")
        } catch (e: Exception) {
            Outcome(false, "Backup failed: ${e.message}", retry = true)
        }
    }

    fun restoreNow(context: Context): Outcome {
        val token = silentToken(context) ?: return Outcome(false, "Please login with Google again.")
        return try {
            val f = findFile(token) ?: return Outcome(false, "No backup found in your Google Drive yet.")
            val (code, text) = call("GET", "$BASE/drive/v3/files/${f.first}?alt=media", token)
            if (code !in 200..299) return Outcome(false, "Restore failed (error $code).")
            val n = Account.restore(context, text)
            if (n < 0) Outcome(false, "The backup in Drive could not be read.") else Outcome(true, "Restored $n items from Google Drive. Restart the app to see everything.")
        } catch (e: Exception) {
            Outcome(false, "Restore failed: ${e.message}")
        }
    }

    /** Deletes the backup file from the person's Drive (used by "Delete my Drive backup"). */
    fun deleteBackup(context: Context): Outcome {
        val token = silentToken(context) ?: return Outcome(false, "Please login with Google again.")
        return try {
            val f = findFile(token) ?: return Outcome(true, "There is no backup in your Drive.")
            val (code, _) = call("DELETE", "$BASE/drive/v3/files/${f.first}", token)
            if (code in 200..299) {
                Store.prefs(context).edit().remove("drive_last").remove("account_drive").apply()
                DriveBackup.cancel(context)
                Outcome(true, "Your backup was deleted from Google Drive. Automatic backup is now off.")
            } else Outcome(false, "Could not delete the backup (error $code).")
        } catch (e: Exception) {
            Outcome(false, "Could not delete the backup: ${e.message}")
        }
    }

    private fun constraints() = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    /** Daily automatic backup (needs internet). */
    fun schedule(context: Context) {
        val req = PeriodicWorkRequestBuilder<BackupWorker>(1, TimeUnit.DAYS).setConstraints(constraints()).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("mydeen_backup_daily", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    /** A backup shortly after you leave the app, if automatic backup is on. */
    fun backupSoon(context: Context) {
        if (!Store.prefs(context).getBoolean("account_drive", false)) return
        val req = OneTimeWorkRequestBuilder<BackupWorker>().setConstraints(constraints()).setInitialDelay(5, TimeUnit.SECONDS).build()
        WorkManager.getInstance(context).enqueueUniqueWork("mydeen_backup_now", ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(context: Context) {
        val wm = WorkManager.getInstance(context)
        wm.cancelUniqueWork("mydeen_backup_daily")
        wm.cancelUniqueWork("mydeen_backup_now")
    }
}

class BackupWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        if (!Store.prefs(applicationContext).getBoolean("account_drive", false)) return Result.success()
        val o = DriveBackup.backupNow(applicationContext)
        return if (o.ok || !o.retry) Result.success() else Result.retry()
    }
}
