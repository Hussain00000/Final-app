package com.example.mydeen

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.File

class BgPreset(val label: String, val res: Int)

/** The app background: a plain colour, one of the bundled Makkah / Madinah pictures, or your own photo. */
object Bg {
    const val KIND_COLOR = "color"
    const val KIND_PRESET = "preset"
    const val KIND_CUSTOM = "custom"
    val DEFAULT_COLOR = 0xFFCDE9D1.toInt()

    val presets = listOf(
        BgPreset("Makkah — Kaaba (day)", R.drawable.bg_makkah_day),
        BgPreset("Makkah — Kaaba (night)", R.drawable.bg_makkah_night),
        BgPreset("Madinah — Green Dome (day)", R.drawable.bg_madinah_day),
        BgPreset("Madinah — Green Dome (night)", R.drawable.bg_madinah_night)
    )

    val colors = listOf(
        "Green" to 0xFFCDE9D1.toInt(), "Mint" to 0xFFD9F2E6.toInt(), "Sky" to 0xFFCFE6F7.toInt(), "Lavender" to 0xFFE2D9F3.toInt(),
        "Rose" to 0xFFF6D9E1.toInt(), "Peach" to 0xFFFBE0CC.toInt(), "Sand" to 0xFFF0E4C8.toInt(), "Cream" to 0xFFFAF6E9.toInt(),
        "Lemon" to 0xFFF7F3C2.toInt(), "Aqua" to 0xFFC9EEF0.toInt(), "Grey" to 0xFFE3E6E4.toInt(), "White" to 0xFFFFFFFF.toInt()
    )

    private fun customFile(context: Context) = File(context.filesDir, "background.jpg")

    fun loadCustom(context: Context): Bitmap? {
        val f = customFile(context)
        return if (f.exists()) try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null } else null
    }

    /** Copies the picked photo into the app (shrunk to a phone-sized picture) so it stays after the original is deleted. */
    fun saveCustom(context: Context, uri: Uri): Bitmap? {
        return try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1600 && bounds.outHeight / (sample * 2) >= 1600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val orientation = try {
                resolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                    ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            var bmp = decoded
            if (degrees != 0f) bmp = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(degrees) }, true)
            val longSide = maxOf(bmp.width, bmp.height)
            if (longSide > 1600) {
                val s = 1600f / longSide
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
            }
            customFile(context).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            bmp
        } catch (e: Exception) {
            null
        }
    }

    private fun averageColor(bmp: Bitmap): Int = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0) or 0xFF000000.toInt()

    /** The main colour of the current background; the app's header, text and cards are tinted from it. */
    fun baseColor(context: Context, st: BgState): Int = when {
        st.kind == KIND_COLOR -> st.color
        st.kind == KIND_PRESET -> try {
            val o = BitmapFactory.Options().apply { inSampleSize = 8 }
            val b = BitmapFactory.decodeResource(context.resources, presets[st.preset.coerceIn(0, presets.size - 1)].res, o)
            if (b != null) averageColor(b) else DEFAULT_COLOR
        } catch (e: Exception) { DEFAULT_COLOR }
        st.kind == KIND_CUSTOM && st.custom != null -> averageColor(st.custom!!)
        else -> DEFAULT_COLOR
    }

    fun removeCustom(context: Context) { customFile(context).delete() }
}

/** Everything the app needs to draw the chosen background. */
class BgState(var kind: String, var color: Int, var preset: Int, var custom: Bitmap?)

fun loadBgState(context: Context, p: SharedPreferences): BgState =
    BgState(
        kind = p.getString("bg_kind", Bg.KIND_COLOR) ?: Bg.KIND_COLOR,
        color = p.getInt("bg_color", Bg.DEFAULT_COLOR),
        preset = p.getInt("bg_preset", 0).coerceIn(0, Bg.presets.size - 1),
        custom = Bg.loadCustom(context)
    )

/** Draws behind the whole app. Pictures get a soft light veil so the text on top stays easy to read. */
@Composable
fun BackgroundLayer(kind: String, color: Int, preset: Int, custom: Bitmap?, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize()) {
        val veil = Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.50f))
        when {
            kind == Bg.KIND_PRESET -> {
                Image(painterResource(Bg.presets[preset.coerceIn(0, Bg.presets.size - 1)].res), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(veil)
            }
            kind == Bg.KIND_CUSTOM && custom != null -> {
                Image(custom.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(veil)
            }
            else -> Box(Modifier.fillMaxSize().background(Color(if (kind == Bg.KIND_COLOR) color else Bg.DEFAULT_COLOR)))
        }
    }
}

@Composable
fun BackgroundScreen(state: BgState, onChange: (kind: String, color: Int, preset: Int, custom: Bitmap?) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }

    fun apply(kind: String, color: Int = state.color, preset: Int = state.preset, custom: Bitmap? = state.custom) {
        prefs.edit().putString("bg_kind", kind).putInt("bg_color", color).putInt("bg_preset", preset).apply()
        onChange(kind, color, preset, custom)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Bg.saveCustom(context, uri)?.let { apply(Bg.KIND_CUSTOM, custom = it) }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Colours", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Bg.colors.chunked(4).forEach { rowItems ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        rowItems.forEach { (name, c) ->
                            val selected = state.kind == Bg.KIND_COLOR && state.color == c
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    Modifier.size(52.dp).clip(CircleShape).background(Color(c))
                                        .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline), CircleShape)
                                        .clickable { apply(Bg.KIND_COLOR, color = c) },
                                    contentAlignment = Alignment.Center
                                ) { if (selected) Text("✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
                                Text(name, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Makkah & Madinah", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Bg.presets.chunked(2).forEachIndexed { rowIndex, rowItems ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowItems.forEachIndexed { colIndex, p ->
                            val index = rowIndex * 2 + colIndex
                            val selected = state.kind == Bg.KIND_PRESET && state.preset == index
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Image(
                                    painterResource(p.res), contentDescription = p.label, contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(12.dp))
                                        .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline), RoundedCornerShape(12.dp))
                                        .clickable { apply(Bg.KIND_PRESET, preset = index) }
                                )
                                Text((if (selected) "✓ " else "") + p.label, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        }

        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Your own photo", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                val custom = state.custom
                if (custom != null) {
                    val selected = state.kind == Bg.KIND_CUSTOM
                    Image(
                        custom.asImageBitmap(), contentDescription = "Your background photo", contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(12.dp))
                            .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline), RoundedCornerShape(12.dp))
                            .clickable { apply(Bg.KIND_CUSTOM) }
                    )
                    if (selected) Text("✓ In use", style = MaterialTheme.typography.labelMedium)
                }
                Button(
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (custom == null) "Choose a photo from gallery" else "Choose a different photo") }
                if (custom != null) {
                    OutlinedButton(
                        onClick = {
                            Bg.removeCustom(context)
                            apply(if (state.kind == Bg.KIND_CUSTOM) Bg.KIND_COLOR else state.kind, color = if (state.kind == Bg.KIND_CUSTOM) Bg.DEFAULT_COLOR else state.color, custom = null)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Remove my photo") }
                }
                Text("Pictures are lightened a little so the text stays easy to read.", style = MaterialTheme.typography.bodySmall)
            }
        }

        OutlinedButton(
            onClick = { apply(Bg.KIND_COLOR, color = Bg.DEFAULT_COLOR) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Back to the default green") }
    }
}
