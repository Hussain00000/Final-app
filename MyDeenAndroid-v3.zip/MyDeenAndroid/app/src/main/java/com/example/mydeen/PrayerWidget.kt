package com.example.mydeen

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Calendar

/** Compact Namaz timings card for the home page. Uses the same location and method as the Prayer Times screen. */
@Composable
fun PrayerWidget() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var lat by remember { mutableStateOf(prefs.getString("loc_lat", null)?.toDoubleOrNull()) }
    var lon by remember { mutableStateOf(prefs.getString("loc_lon", null)?.toDoubleOrNull()) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(30000L)
        }
    }

    fun onLocation(loc: Location?) {
        loading = false
        if (loc != null) {
            lat = loc.latitude
            lon = loc.longitude
            prefs.edit().putString("loc_lat", loc.latitude.toString()).putString("loc_lon", loc.longitude.toString()).apply()
            status = ""
        } else {
            status = "Couldn’t get your location. Turn on Location (GPS) and try again."
        }
    }

    fun fetchLocation() {
        loading = true
        status = "Finding your location…"
        LocationHelper.fetch(context, true) { loc -> onLocation(loc) }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) fetchLocation()
        else status = "Location permission was denied. Allow it in your phone’s app settings for My Deen."
    }

    fun locate() {
        val granted = context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
        } else {
            fetchLocation()
        }
    }

    val la = lat
    val lo = lon
    DeenCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Namaz timings", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            if (la == null || lo == null) {
                Text("Allow your location once to see today’s Namaz times here.")
                Button(onClick = { locate() }, enabled = !loading, modifier = Modifier.fillMaxWidth()) { Text("Use my location") }
                if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodySmall)
            } else {
                val method = prefs.getInt("pt_method", 0)
                val hanafi = prefs.getBoolean("pt_hanafi", true)
                val cal = Calendar.getInstance().apply { timeInMillis = now }
                val dayKey = Store.dayKey(cal)
                val times = remember(la, lo, method, hanafi, dayKey) { PrayerCalc.compute(cal, la, lo, method, hanafi) }
                val dayStart = (cal.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis

                var nextName = ""
                var nextMs = 0L
                for (t in times) {
                    val h = t.hours ?: continue
                    if (t.name == "Sunrise") continue
                    val ms = dayStart + (h * 3600000.0).toLong()
                    if (ms > now) { nextName = t.name; nextMs = ms; break }
                }
                if (nextName.isEmpty()) {
                    val f = times.firstOrNull { it.name == "Fajr" }?.hours
                    if (f != null) { nextName = "Fajr"; nextMs = dayStart + (f * 3600000.0).toLong() + 86400000L }
                }
                if (nextName.isNotEmpty()) {
                    val mins = ((nextMs - now) / 60000L).toInt()
                    val inText = if (mins >= 60) "${mins / 60} h ${mins % 60} min" else "$mins min"
                    Text("Next: $nextName in $inText", fontWeight = FontWeight.Bold)
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    times.filter { it.name != "Sunrise" }.forEach { t ->
                        val isNext = t.name == nextName
                        val parts = PrayerCalc.format(t.hours).split(" ")
                        Column(
                            modifier = Modifier.weight(1f)
                                .background(
                                    if (isNext) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(t.name, style = MaterialTheme.typography.labelMedium, fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal, textAlign = TextAlign.Center)
                            Text(parts[0], style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text(parts.getOrElse(1) { "" }, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                val sunrise = times.firstOrNull { it.name == "Sunrise" }
                if (sunrise != null) Text("Sunrise ${PrayerCalc.format(sunrise.hours)}", style = MaterialTheme.typography.bodySmall)
                if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { locate() }, enabled = !loading) { Text("Update my location") }
            }
        }
    }
}
