package com.example.mydeen

import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Gmail account + backup/restore. Everything is saved to the person's own Gmail as an email to themselves. */
object Account {
    private const val KEY_EMAIL = "account_email"
    private const val MARK = "MYDEEN-BACKUP-V1"

    fun email(context: Context): String = Store.prefs(context).getString(KEY_EMAIL, "") ?: ""
    fun signIn(context: Context, email: String) { Store.prefs(context).edit().putString(KEY_EMAIL, email.trim().lowercase(Locale.US)).apply() }
    fun signOut(context: Context) { Store.prefs(context).edit().remove(KEY_EMAIL).apply() }

    fun isGmail(e: String): Boolean {
        val x = e.trim().lowercase(Locale.US)
        return android.util.Patterns.EMAIL_ADDRESS.matcher(x).matches() && (x.endsWith("@gmail.com") || x.endsWith("@googlemail.com"))
    }

    /** All saved data (checklist, tasbih, timer, settings…) as one JSON text. */
    fun export(context: Context): String {
        val root = JSONObject()
        for ((k, v) in Store.prefs(context).all) {
            val o = JSONObject()
            when (v) {
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Set<*> -> { o.put("t", "set"); o.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            root.put(k, o)
        }
        return root.toString()
    }

    /** Returns how many items were restored, or -1 if the text is not a valid backup. */
    fun restore(context: Context, text: String): Int {
        return try {
            val a = text.indexOf('{')
            val b = text.lastIndexOf('}')
            if (a < 0 || b <= a) return -1
            val root = JSONObject(text.substring(a, b + 1))
            val e = Store.prefs(context).edit()
            var n = 0
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val o = root.getJSONObject(k)
                when (o.getString("t")) {
                    "b" -> e.putBoolean(k, o.getBoolean("v"))
                    "i" -> e.putInt(k, o.getInt("v"))
                    "l" -> e.putLong(k, o.getLong("v"))
                    "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                    "s" -> e.putString(k, o.getString("v"))
                    "set" -> {
                        val arr = o.getJSONArray("v")
                        e.putStringSet(k, (0 until arr.length()).map { arr.getString(it) }.toSet())
                    }
                    else -> continue
                }
                n++
            }
            e.apply()
            n
        } catch (ex: Exception) { -1 }
    }

    /** Opens Gmail with a ready email to yourself containing the backup. */
    fun sendBackup(context: Context) {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val body = "$MARK\nKeep this email. To restore: open it, copy this whole message, then in My Deen go to Menu > Account & Backup > Restore.\n\n${export(context)}"
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_EMAIL, arrayOf(email(context)))
            putExtra(Intent.EXTRA_SUBJECT, "My Deen backup $day")
            putExtra(Intent.EXTRA_TEXT, body)
        }
        try {
            context.startActivity(Intent(send).setPackage("com.google.android.gm").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            context.startActivity(Intent.createChooser(send, "Send backup").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun clipboardText(context: Context): String {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString() ?: ""
    }
}

@Composable
fun AccountScreen() {
    val context = LocalContext.current
    var saved by remember { mutableStateOf(Account.email(context)) }
    var input by remember { mutableStateOf("") }
    var pasted by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Gmail account", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                if (saved.isEmpty()) {
                    Text("Login with your Gmail address to save your data to your own Gmail.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, singleLine = true,
                        label = { Text("yourname@gmail.com") }, modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = {
                        if (Account.isGmail(input)) { Account.signIn(context, input); saved = Account.email(context); msg = "Logged in." }
                        else msg = "Please enter a valid Gmail address."
                    }, modifier = Modifier.fillMaxWidth()) { Text("Login") }
                } else {
                    Text("Logged in as $saved", style = MaterialTheme.typography.bodyLarge)
                    OutlinedButton(onClick = { Account.signOut(context); saved = ""; msg = "Logged out." }, modifier = Modifier.fillMaxWidth()) { Text("Logout") }
                }
                if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (saved.isNotEmpty()) {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Save data to Gmail", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Opens Gmail with an email to yourself that holds all your checklist, tasbih, timer and settings. Just tap Send.", style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { Account.sendBackup(context) }, modifier = Modifier.fillMaxWidth()) { Text("Backup to Gmail") }
                }
            }
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Restore from Gmail", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Open your backup email in Gmail, copy the whole message, then paste it here.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(value = pasted, onValueChange = { pasted = it }, label = { Text("Paste backup here") }, maxLines = 4, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pasted = Account.clipboardText(context) }) { Text("Paste from clipboard") }
                        Button(onClick = {
                            val n = Account.restore(context, pasted)
                            msg = if (n >= 0) "Restored $n items. Restart the app to see everything." else "That doesn’t look like a My Deen backup."
                            if (n >= 0) pasted = ""
                        }) { Text("Restore") }
                    }
                }
            }
        }
    }
}
