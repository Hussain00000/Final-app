package com.example.mydeen

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Islamic Status maker: pick a background (moon & flowers, mosque, star pattern, Makkah / Madinah) and a Quran ayah or hadith (Arabic + Roman English),
 * then share it to WhatsApp Status (or any app) or save it to the gallery.
 */
@Composable
fun StatusScreen() {
    val context = LocalContext.current
    var styleIdx by rememberSaveable { mutableIntStateOf(0) }
    var filter by rememberSaveable { mutableStateOf("all") }   // all / quran / hadith
    var pos by rememberSaveable { mutableIntStateOf(0) }
    var showRoman by rememberSaveable { mutableStateOf(true) }   // Roman English line under the Arabic

    val shown = remember(filter) {
        when (filter) {
            "quran" -> StatusArt.verses.filter { it.isQuran }
            "hadith" -> StatusArt.verses.filter { !it.isQuran }
            else -> StatusArt.verses
        }
    }
    val safePos = pos.coerceIn(0, shown.size - 1)
    val verse = shown[safePos]
    val style = StatusArt.styles[styleIdx.coerceIn(0, StatusArt.styles.size - 1)]

    val appContext = context.applicationContext
    val bmp by produceState<Bitmap?>(initialValue = null, styleIdx, filter, safePos, showRoman) {
        value = withContext(Dispatchers.Default) { StatusArt.render(appContext, style, verse, showRoman) }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // preview, same 9:16 shape as a WhatsApp status
        Box(
            Modifier.fillMaxWidth(0.72f).aspectRatio(9f / 16f).clip(RoundedCornerShape(16.dp))
                .background(Color(style.top)),
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b != null) {
                Image(b.asImageBitmap(), contentDescription = "Status preview", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                CircularProgressIndicator(color = Color.White)
            }
        }

        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Background (${StatusArt.styles.size})", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    StatusArt.styles.forEachIndexed { i, s ->
                        val selected = i == styleIdx
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(60.dp).clip(CircleShape)
                                    .background(Brush.verticalGradient(listOf(Color(s.top), Color(s.bottom))))
                                    .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline), CircleShape)
                                    .clickable { styleIdx = i },
                                contentAlignment = Alignment.Center
                            ) {
                                if (s.kind == StatusArt.KIND_PHOTO && s.res != 0) {
                                    Image(painterResource(s.res), contentDescription = s.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                }
                                val symbol = when (s.kind) {
                                    StatusArt.KIND_MOSQUE -> "🕌"
                                    StatusArt.KIND_PATTERN -> "✦"
                                    StatusArt.KIND_PHOTO -> ""
                                    else -> "☾"
                                }
                                val mark = if (selected) "✓" else symbol
                                if (mark.isNotEmpty()) Text(mark, color = Color(s.accent))
                            }
                            Text(s.name, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                OutlinedButton(
                    onClick = { styleIdx = (0 until StatusArt.styles.size).random() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("🎨 Random background") }
            }
        }

        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Quran & Hadees", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Roman English", style = MaterialTheme.typography.bodyLarge)
                        Text("Arabic written in English letters", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = showRoman, onCheckedChange = { showRoman = it })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("all" to "All", "quran" to "Quran", "hadith" to "Hadees").forEach { (key, label) ->
                        FilterChip(selected = filter == key, onClick = { filter = key; pos = 0 }, label = { Text(label) })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pos = (safePos - 1 + shown.size) % shown.size }, modifier = Modifier.weight(1f)) { Text("◀ Previous") }
                    OutlinedButton(onClick = { pos = (safePos + 1) % shown.size }, modifier = Modifier.weight(1f)) { Text("Next ▶") }
                }
                OutlinedButton(onClick = { pos = (0 until shown.size).random() }, modifier = Modifier.fillMaxWidth()) { Text("🔀 Surprise me") }
                Text("${safePos + 1} of ${shown.size}", style = MaterialTheme.typography.bodySmall)
            }
        }

        Button(
            onClick = { bmp?.let { StatusShare.share(context, it, whatsApp = true) } },
            enabled = bmp != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Share to WhatsApp Status") }
        OutlinedButton(
            onClick = { bmp?.let { StatusShare.share(context, it, whatsApp = false) } },
            enabled = bmp != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Share in another app") }
        OutlinedButton(
            onClick = {
                bmp?.let {
                    val ok = StatusShare.saveToGallery(context, it)
                    Toast.makeText(
                        context,
                        if (ok) "Saved in Pictures/MyDeen" else "Saving needs Android 10 or newer. Use Share instead.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            enabled = bmp != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save to gallery") }
        Text(
            "In WhatsApp choose “My status” to post it. The picture is 1080 × 1920, the full-screen status size.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
