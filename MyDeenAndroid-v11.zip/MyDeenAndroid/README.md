# My Deeni Tracker (Android, Kotlin + Jetpack Compose)

Version 3.0 features: daily checklist with Submit Day, 2.5-hour Deen timer, Qaza namaz tick boxes, Hadith of the day, Namaz timings widget and profile photo on the home page, digital Tasbih,
prayer times from your location (calculated offline), per-task alarm reminders,
weekly and monthly analysis, green theme and a menu on the right of the top bar.

## Build without a computer
Upload this zip to a GitHub repo together with `.github/workflows/build.yml`.
GitHub Actions builds `MyDeen.apk` and attaches it to a Release.
Name new versions MyDeenAndroid-v3.zip, v4 ... so the newest one is built.

## Build with Android Studio
Open the `MyDeenAndroid` folder, let Gradle sync, then Run or Build > Build APK(s).
The project ships its own debug keystore (app/debug.keystore) so every build is signed
with the same key and new versions install over old ones without losing data.
