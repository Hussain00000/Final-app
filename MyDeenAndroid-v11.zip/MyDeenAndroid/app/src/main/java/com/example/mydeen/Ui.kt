package com.example.mydeen

import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.graphics.ColorUtils

val DeenGreen = Color(0xFF1B5E20)
val DeenInk = Color(0xFF10281A)

private val GreenScheme = lightColorScheme(
    primary = DeenGreen, onPrimary = Color.White,
    primaryContainer = Color(0xFFB5DEBC), onPrimaryContainer = DeenInk,
    secondary = Color(0xFF2E7D32), onSecondary = Color.White,
    secondaryContainer = Color(0xFFA5D6AD), onSecondaryContainer = DeenInk,
    tertiary = Color(0xFF00695C), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFB2DFDB), onTertiaryContainer = DeenInk,
    background = Color(0xFFCDE9D1), onBackground = DeenInk,
    surface = Color(0xFFF3FAF4), onSurface = DeenInk,
    surfaceVariant = Color(0xFFDCEBDE), onSurfaceVariant = Color(0xFF2F4A38),
    surfaceTint = DeenGreen,
    outline = Color(0xFF4F7058), outlineVariant = Color(0xFFB0CDB5),
    surfaceBright = Color(0xFFF3FAF4), surfaceDim = Color(0xFFC3DCC8),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF3FAF4),
    surfaceContainer = Color(0xFFEAF5EC), surfaceContainerHigh = Color(0xFFE3F1E6), surfaceContainerHighest = Color(0xFFDCEBDE)
)

/**
 * Builds the whole colour scheme (header, text, cards, buttons) from the background's colour,
 * so everything follows the chosen background. The default green keeps the original look.
 */
fun deenScheme(base: Int): ColorScheme {
    if (base == Bg.DEFAULT_COLOR) return GreenScheme
    val hsl = FloatArray(3)
    ColorUtils.colorToHSL(base, hsl)
    val h = if (hsl[1] < 0.08f) 130f else hsl[0]          // grey / white backgrounds keep a green accent
    val sat = if (hsl[1] < 0.08f) 0.35f else hsl[1].coerceIn(0.25f, 0.6f)
    fun c(hue: Float, s: Float, l: Float): Color = Color(ColorUtils.HSLToColor(floatArrayOf(((hue % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), l.coerceIn(0f, 1f))))
    val ink = c(h, 0.35f, 0.10f)
    val surfaceSat = (sat * 0.6f).coerceIn(0.15f, 0.4f)
    return lightColorScheme(
        primary = c(h, sat, 0.24f), onPrimary = Color.White,
        primaryContainer = c(h, sat, 0.80f), onPrimaryContainer = ink,
        secondary = c(h, sat, 0.30f), onSecondary = Color.White,
        secondaryContainer = c(h, sat, 0.78f), onSecondaryContainer = ink,
        tertiary = c(h + 40f, sat, 0.28f), onTertiary = Color.White,
        tertiaryContainer = c(h + 40f, sat, 0.82f), onTertiaryContainer = ink,
        background = c(h, surfaceSat, 0.86f), onBackground = ink,
        surface = c(h, surfaceSat, 0.965f), onSurface = ink,
        surfaceVariant = c(h, surfaceSat, 0.90f), onSurfaceVariant = c(h, 0.30f, 0.25f),
        surfaceTint = c(h, sat, 0.24f),
        outline = c(h, 0.20f, 0.40f), outlineVariant = c(h, 0.20f, 0.75f),
        surfaceBright = c(h, surfaceSat, 0.965f), surfaceDim = c(h, surfaceSat, 0.82f),
        surfaceContainerLowest = Color.White, surfaceContainerLow = c(h, surfaceSat, 0.965f),
        surfaceContainer = c(h, surfaceSat, 0.94f), surfaceContainerHigh = c(h, surfaceSat, 0.92f), surfaceContainerHighest = c(h, surfaceSat, 0.90f)
    )
}

@Composable
fun MyDeenTheme(base: Int = Bg.DEFAULT_COLOR, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = remember(base) { deenScheme(base) }, content = content)
}

@Composable
fun DeenCard(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color, contentColor = MaterialTheme.colorScheme.onSurface),
        content = content
    )
}
