package com.example.mydeen

/**
 * Offline Urdu (Urdu script) -> Roman Urdu converter used for the Quran and Hadees Roman Urdu line.
 *
 * Why this exists: the online Quran / Hadith sources only give Urdu in Urdu script, and the old
 * auto-romaniser gave wrong, unreadable spellings. Urdu script does not write short vowels, so a
 * plain letter-by-letter conversion is poor. This converter works like a translator would:
 *  1. honorific phrases are tidied (صلی اللہ علیہ وسلم becomes ﷺ, "razi Allahu anhu" is dropped),
 *  2. every word (and common 2-3 word phrase) is looked up in a hand-written Islamic dictionary with
 *     one consistent spelling (Allah, namaz, imaan, rehmat, jannat ...),
 *  3. only words that are not in the dictionary use letter rules.
 * Needs no internet and always returns Latin letters only.
 */
object RomanUrdu {

    fun hasUrduScript(s: String): Boolean = s.any { it.code in 0x0600..0x06FF }

    /** Roman Urdu for [urdu]. Returns "" when the input is blank. */
    fun convert(urdu: String): String {
        if (urdu.isBlank()) return ""
        var s = normalize(urdu)
        for ((rx, rep) in honorifics) s = rx.replace(s, rep)
        s = Regex("\\s+").replace(s, " ").trim()

        val words = ArrayList<String>()
        for (m in tokenRx.findAll(s)) words.add(m.value)

        val out = ArrayList<Pair<Char, String>>()   // 'w' = word, 'p' = punctuation
        var sentStart = true
        var i = 0
        while (i < words.size) {
            val w = words[i]
            if (!isLetter(w[0])) {
                if (w == "ﷺ") {
                    out.add(Pair('w', "ﷺ"))
                } else {
                    out.add(Pair('p', w))
                    if (w.any { it == '.' || it == '?' || it == '!' }) sentStart = true
                }
                i++
                continue
            }
            // phrases of 3 then 2 words
            var matched = false
            for (span in intArrayOf(3, 2)) {
                if (i + span <= words.size) {
                    var allLetters = true
                    for (k in i until i + span) if (!isLetter(words[k][0])) allLetters = false
                    if (allLetters) {
                        val key = words.subList(i, i + span).joinToString(" ")
                        val hit = dict[key]
                        if (hit != null) {
                            out.add(Pair('w', hit))
                            i += span
                            sentStart = false
                            matched = true
                            break
                        }
                    }
                }
            }
            if (matched) continue

            // future endings written as a separate word (گا گی گے) join the verb before them
            if ((w == "گا" || w == "گی" || w == "گے") && out.isNotEmpty() && out.last().first == 'w' && out.last().second != "ﷺ") {
                val ending = if (w == "گا") "ga" else if (w == "گی") "gi" else "ge"
                out[out.size - 1] = Pair('w', out.last().second + ending)
                i++
                continue
            }

            val r = contextWord(words, i, sentStart) ?: dict[w] ?: fallback(w)
            out.add(Pair('w', r))
            sentStart = false
            i++
        }

        val sb = StringBuilder()
        for ((kind, t) in out) {
            if (kind == 'p') sb.append(t) else {
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(t)
            }
        }
        var res = sb.toString()
        res = Regex("\\s+([,.;:?!])").replace(res, "\$1")
        res = Regex("([,.;:?!])(?=[^\\s,.;:?!])").replace(res, "\$1 ")
        res = Regex("\\s+").replace(res, " ").trim()
        res = Regex("(^|[.?!]\\s+)([a-z])").replace(res) { m -> m.groupValues[1] + m.groupValues[2].uppercase() }
        // never let Urdu script through
        return if (hasUrduScript(res)) "" else res
    }

    /**
     * For a hadith: the Urdu text after "... ﷺ نے فرمایا کہ", still in Urdu script, so the long chain of
     * narrators in front of it is cut away. Returns "" when the saying cannot be found.
     */
    fun hadithMatn(urdu: String): String {
        var s = normalize(urdu)
        for ((rx, rep) in honorifics) s = rx.replace(s, rep)
        s = Regex("\\s+").replace(s, " ").trim()
        val m = sayingRx.find(s) ?: return ""
        val rest = s.substring(m.range.last + 1).trim(' ', ',', ':', ';', '.')
        return if (rest.length < 8) "" else rest
    }

    private val sayingRx = Regex("ﷺ (نے )?(یہ )?(ارشاد )?(فرمایا|فرماتے تھے)( کہ)?[,:]? ?")

    // ---------------------------------------------------------------- normalising

    private val tokenRx = Regex("[\\u0621-\\u064A\\u066E-\\u06D3]+|[^\\s\\u0621-\\u064A\\u066E-\\u06D3]+")

    private val honorifics: List<Pair<Regex, String>> = listOf(
        Pair(Regex("صلی اللہ علیہ و? ?آلہ و? ?سلم"), " ﷺ "),
        Pair(Regex("صلی اللہ علیہ و? ?سلم"), " ﷺ "),
        Pair(Regex("صلی اللہ تعالی علیہ و? ?سلم"), " ﷺ "),
        Pair(Regex("صلعم"), " ﷺ "),
        Pair(Regex("رضی اللہ (تعالی )?عن(ہ|ہا|ہم|ہما|ھم|ھما|ھا)"), " "),
        Pair(Regex("(علیہ|علیھا|علیہم|علیہما) السلام"), " "),
        Pair(Regex("رحمۃ اللہ علیہ|رحمہ اللہ|رحمة اللہ علیہ"), " "),
        Pair(Regex("(جل جلالہ|عز و? ?جل|سبحانہ و? ?تعالی|تبارک و? ?تعالی)"), " ")
    )

    private fun normalize(input: String): String {
        val src = input.replace("ﷲ", "اللہ")
        val sb = StringBuilder(src.length)
        for (ch in src) {
            val code = ch.code
            if (code in 0x064B..0x065F || code == 0x0670 || code == 0x0640 || code in 0x06D6..0x06ED) continue
            when {
                code in 0x0660..0x0669 -> sb.append('0' + (code - 0x0660))
                code in 0x06F0..0x06F9 -> sb.append('0' + (code - 0x06F0))
                ch == 'ي' || ch == 'ى' -> sb.append('ی')
                ch == 'ك' -> sb.append('ک')
                ch == 'ە' || ch == 'ه' || ch == 'ۃ' || ch == 'ۀ' -> sb.append('ہ')
                ch == 'أ' || ch == 'إ' || ch == 'ٱ' -> sb.append('ا')
                ch == 'ۓ' -> sb.append('ے')
                ch == '،' -> sb.append(',')
                ch == '۔' -> sb.append('.')
                ch == '؟' -> sb.append('?')
                ch == '؛' -> sb.append(';')
                ch == '‌' -> sb.append(' ')
                ch == '‍' || ch == '‎' || ch == '‏' || ch == '﻿' -> { }
                ch == '(' || ch == ')' || ch == '[' || ch == ']' || ch == '{' || ch == '}' ||
                    ch == '"' || ch == '“' || ch == '”' || ch == '«' || ch == '»' ||
                    ch == '‘' || ch == '’' || ch == '\'' -> sb.append(' ')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun isLetter(c: Char): Boolean = c in 'ء'..'ي' || c in 'ٮ'..'ۓ'

    // ---------------------------------------------------------------- words that depend on neighbours

    private val postpositions = setOf("نے", "کو", "کا", "کی", "کے", "سے", "پر")
    private val mainBefore = setOf("تو", "اور", "کہ", "جب", "پس", "پھر", "بلکہ", "اگر")
    private val mainNext = setOf(
        "تمہیں", "تمھیں", "تم", "تجھے", "اسے", "انہیں", "ہم", "اس", "ان",
        "ہوں", "نے", "کروں", "دوں", "لوں", "جانتا", "جانتی", "دیکھتا", "سنتا", "کہتا", "چاہتا", "ڈرتا", "تو", "ہی"
    )
    private val kyaNext = setOf("ہے", "ہیں", "ہوں", "تھا", "تم", "تمہیں", "تو", "وہ", "یہ", "ہم")

    private fun contextWord(toks: List<String>, i: Int, sentStart: Boolean): String? {
        val w = toks[i]
        val prev = if (i > 0) toks[i - 1] else ""
        val next = if (i + 1 < toks.size) toks[i + 1] else ""
        return when (w) {
            "اس" -> if (next in postpositions) "us" else "is"
            "ان" -> if (next in postpositions) "un" else "in"
            "میں" -> when {
                prev in mainBefore && next != "سے" && next != "ہی" -> "main"
                next in mainNext || next.endsWith("گا") -> "main"
                else -> "mein"
            }
            "کیا" -> if (sentStart || next in kyaNext) "kya" else "kiya"
            "ہوا" -> "hua"
            else -> null
        }
    }

    // ---------------------------------------------------------------- letter rules (unknown words only)

    private val cons: Map<Char, String> = mapOf(
        'ب' to "b", 'پ' to "p", 'ت' to "t", 'ٹ' to "t", 'ث' to "s", 'ج' to "j", 'چ' to "ch", 'ح' to "h",
        'خ' to "kh", 'د' to "d", 'ڈ' to "d", 'ذ' to "z", 'ر' to "r", 'ڑ' to "r", 'ز' to "z", 'ژ' to "zh",
        'س' to "s", 'ش' to "sh", 'ص' to "s", 'ض' to "z", 'ط' to "t", 'ظ' to "z", 'غ' to "gh", 'ف' to "f",
        'ق' to "q", 'ک' to "k", 'گ' to "g", 'ل' to "l", 'م' to "m", 'ن' to "n", 'ہ' to "h"
    )

    private class Tk(val kind: Char, var text: String)

    private fun fallback(w: String): String {
        val toks = ArrayList<Tk>()
        val n = w.length
        var i = 0
        while (i < n) {
            val c = w[i]
            val nxt = if (i + 1 < n) w[i + 1] else '\u0000'
            val last = (i == n - 1)
            val prevV = toks.isNotEmpty() && toks.last().kind == 'V'
            val prevC = toks.isNotEmpty() && toks.last().kind == 'C'
            when {
                c == 'ھ' -> {
                    if (prevC) toks.last().text = toks.last().text + "h" else toks.add(Tk('C', "h"))
                }
                c == 'ں' -> toks.add(Tk('N', "n"))
                c == 'آ' -> toks.add(Tk('V', "aa"))
                c == 'ا' -> {
                    if (i == 0) toks.add(Tk('V', "a"))
                    else if (last && prevC) toks.add(Tk('V', "a"))
                    else toks.add(Tk('V', "aa"))
                }
                c == 'ع' -> {
                    if (!(last || nxt == 'ا' || nxt == 'و' || nxt == 'ی' || nxt == 'ے')) toks.add(Tk('V', "a"))
                }
                c == 'ء' || c == 'ئ' -> {
                    if (c == 'ئ' && (nxt == 'ی' || nxt == 'ے')) toks.add(Tk('C', "y"))
                }
                c == 'و' || c == 'ؤ' -> {
                    if (i == 0) toks.add(Tk('C', "w"))
                    else if (prevV) toks.add(Tk('V', "o"))
                    else if (last) toks.add(Tk('V', "o"))
                    else if (c == 'ؤ') toks.add(Tk('V', "o"))
                    else toks.add(Tk('V', "oo"))
                }
                c == 'ی' -> {
                    if (i == 0) toks.add(Tk('C', "y"))
                    else if (last) toks.add(Tk('V', "i"))
                    else if (nxt == 'ں' && i + 2 == n) toks.add(Tk('V', "ei"))
                    else if (prevV) toks.add(Tk('V', "y"))
                    else toks.add(Tk('V', "ee"))
                }
                c == 'ے' -> toks.add(Tk('V', "e"))
                c == 'ہ' && last && prevC -> toks.add(Tk('V', "a"))
                cons.containsKey(c) -> toks.add(Tk('C', cons[c] ?: ""))
                else -> { }
            }
            i++
        }

        // consonant clusters: Urdu words do not start with two consonants, so add a short 'a'
        val res = StringBuilder()
        val run = ArrayList<String>()
        var started = false
        fun flush() {
            if (run.isEmpty()) return
            var k = 0
            if (!started && run.size >= 2) {
                res.append(run[0]).append("a")
                k = 1
            }
            while (k < run.size) {
                res.append(run[k])
                if (run.size - k - 1 >= 2) res.append("a")
                k++
            }
            run.clear()
        }
        for (t in toks) {
            if (t.kind == 'C') {
                run.add(t.text)
            } else {
                flush()
                started = true
                res.append(t.text)
            }
        }
        flush()
        return res.toString()
    }

    // ---------------------------------------------------------------- dictionary

    private val dict: HashMap<String, String> by lazy { buildDict() }

    private fun buildDict(): HashMap<String, String> {
        val d = HashMap<String, String>(4096)
        for (chunk in listOf(D1, D2, D3, D4, D5, D6, D7, D8, D9, D10)) {
            for (line in chunk.lineSequence()) {
                val eq = line.indexOf('=')
                if (eq <= 0) continue
                val key = Regex("\\s+").replace(normalize(line.substring(0, eq)), " ").trim()
                val value = line.substring(eq + 1).trim()
                if (key.isNotEmpty() && value.isNotEmpty()) d[key] = value
            }
        }
        return d
    }

    private const val D1 = """
اور=aur
یا=ya
کہ=ke
کا=ka
کی=ki
کے=ke
کو=ko
سے=se
پر=par
نے=ne
تک=tak
بھی=bhi
ہی=hi
تو=to
نہ=na
نہیں=nahin
نہیں ہے=nahin hai
مت=mat
ہے=hai
ہیں=hain
ہوں=hoon
ہو=ho
ہوا=hua
ہوئی=hui
ہوئے=hue
ہوتا=hota
ہوتے=hote
ہوتی=hoti
ہونا=hona
ہونے=hone
ہوگا=hoga
ہوگی=hogi
ہوں گے=honge
ہونگے=honge
ہوجائے=ho jaye
ہوجائیں=ho jayein
ہوجاتا=ho jaata
تھا=tha
تھے=the
تھی=thi
تھیں=thin
گا=ga
گی=gi
گے=ge
وہ=woh
وہی=wohi
یہ=yeh
یہی=yehi
ہم=hum
تم=tum
تمہیں=tumhein
تمہارے=tumhare
تمہارا=tumhara
تمہاری=tumhari
تمھارے=tumhare
تمھارا=tumhara
تمھاری=tumhari
ہمیں=humein
ہمارے=hamare
ہمارا=hamara
ہماری=hamari
مجھ=mujh
مجھے=mujhe
میرا=mera
میری=meri
میرے=mere
اسے=use
انہیں=unhein
انھیں=unhein
انہوں=unhon
انھوں=unhon
اسی=isi
اسکو=usko
اپنا=apna
اپنی=apni
اپنے=apne
آپ=aap
تجھ=tujh
تجھے=tujhe
تیرا=tera
تیری=teri
تیرے=tere
جو=jo
جس=jis
جن=jin
جنہوں=jinhon
جنہیں=jinhein
جب=jab
تب=tab
اگر=agar
پھر=phir
سو=so
پس=pas
مگر=magar
لیکن=lekin
بلکہ=balke
کیونکہ=kyunke
کیوں=kyun
کون=kaun
کس=kis
کسی=kisi
کوئی=koi
کچھ=kuch
سب=sab
سارے=saare
تمام=tamam
ہر=har
بعض=baaz
دوسرے=doosre
دوسرا=doosra
دوسری=doosri
ایک=ek
دو=do
تین=teen
چار=chaar
پانچ=paanch
چھ=chhe
سات=saat
آٹھ=aath
نو=nau
دس=das
سو سال=sau saal
ہزار=hazaar
ہزاروں=hazaaron
لاکھ=laakh
یہاں=yahan
وہاں=wahan
کہاں=kahan
اب=ab
آج=aaj
کل=kal
ہمیشہ=hamesha
کبھی=kabhi
ابھی=abhi
جہاں=jahan
ساتھ=saath
سامنے=saamne
پاس=paas
بعد=baad
پہلے=pehle
پیچھے=peechhe
اوپر=oopar
نیچے=neeche
درمیان=darmiyan
اندر=andar
باہر=bahar
لئے=liye
لیے=liye
واسطے=waaste
بغیر=baghair
"""

    private const val D2 = """
سوا=siwa
علاوہ=alawa
طرف=taraf
جیسے=jaise
جیسا=jaisa
جیسی=jaisi
ایسا=aisa
ایسے=aise
ایسی=aisi
اتنا=itna
اتنے=itne
بہت=bohat
بڑا=bada
بڑی=badi
بڑے=bade
چھوٹا=chhota
چھوٹی=chhoti
چھوٹے=chhote
زیادہ=zyada
کم=kam
سخت=sakht
نیک=nek
نیکو=neko
برا=bura
بری=buri
برے=bure
اچھا=achha
اچھی=achhi
اچھے=achhe
بہتر=behtar
بہترین=behtareen
بھلائی=bhalai
برائی=burai
برائیاں=buraiyan
برائیوں=buraiyon
بے=be
بے شک=be-shak
بیشک=be-shak
بےشک=be-shak
ضرور=zaroor
یقیناً=yaqeenan
یقین=yaqeen
تاکہ=taake
چاہئے=chahiye
چاہیئے=chahiye
چاہیے=chahiye
چاہتا=chahta
چاہتے=chahte
چاہو=chaho
چاہے=chahe
چاہا=chaha
بلاشبہ=bila-shubah
اللہ=Allah
اللہ تعالی=Allah Ta'ala
اللّٰہ=Allah
خدا=Khuda
خدائے=Khuda ke
رب=Rab
پروردگار=Parwardigar
پرورد گار=Parwardigar
رحمان=Rehman
رحمن=Rehman
رحیم=Raheem
رحمت=rehmat
رحمتیں=rehmatein
رحمتوں=rehmaton
مہربان=meherban
مہربانی=meherbani
رحم=reham
بخشنے=bakhshne
بخشش=bakhshish
بخش=bakhsh
بخشے=bakhshe
مغفرت=maghfirat
بخشنے والا=bakhshne wala
عذاب=azaab
جہنم=jahannam
دوزخ=dozakh
دوزخیوں=dozakhiyon
جنت=jannat
جنتوں=jannaton
جنتیں=jannatein
باغات=baghaat
باغ=bagh
باغوں=baghon
نہریں=nehrein
نہر=nehar
آخرت=aakhirat
قیامت=qayamat
دنیا=duniya
زندگی=zindagi
موت=maut
مرنے=marne
مرجائے=mar jaye
مرگیا=mar gaya
روز=roz
دن=din
دنوں=dinon
رات=raat
راتوں=raaton
ایمان=imaan
مومن=momin
مومنوں=mominon
مومنین=momineen
مسلمان=musalman
مسلمانوں=musalmanon
مسلمانو=musalmano
کافر=kafir
کافروں=kafiron
منافق=munafiq
منافقوں=munafiqon
مشرک=mushrik
مشرکوں=mushrikon
ظالم=zalim
ظالموں=zalimon
ظلم=zulm
فاسق=faasiq
گنہگار=gunahgaar
گناہ=gunah
گناہوں=gunahon
نیکی=neki
نیکیاں=nekiyan
نیکیوں=nekiyon
ثواب=sawab
اجر=ajr
بدلہ=badla
جزا=jaza
سزا=saza
حساب=hisaab
کتاب=kitab
کتابیں=kitaabein
قرآن=Quran
آیت=aayat
آیتیں=aayatein
آیات=aayaat
نبی=Nabi
نبیوں=Nabiyon
پیغمبر=Paighambar
پیغمبروں=Paighambaron
رسول=Rasool
رسولوں=Rasoolon
رسول اللہ=Rasoolullah
فرشتے=farishte
فرشتہ=farishta
فرشتوں=farishton
شیطان=Shaitan
شیطانوں=Shaitanon
ابلیس=Iblees
وحی=wahi
دین=deen
"""

    private const val D3 = """
اسلام=Islam
شریعت=shariat
نماز=namaz
نمازیں=namazein
نمازوں=namazon
زکوٰۃ=zakat
زکوۃ=zakat
روزہ=roza
روزے=roze
حج=Hajj
عمرہ=Umrah
قربانی=qurbani
صدقہ=sadqa
صدقات=sadaqaat
خیرات=khairaat
دعا=dua
دعائیں=duaein
دعاؤں=duaon
عبادت=ibadat
بندگی=bandagi
بندہ=banda
بندے=bande
بندوں=bandon
توبہ=tauba
صبر=sabr
شکر=shukar
توکل=tawakkul
تقویٰ=taqwa
تقوی=taqwa
پرہیزگار=parhezgaar
پرہیزگاروں=parhezgaaron
پرہیزگاری=parhezgaari
ڈرو=daro
ڈرتے=darte
ڈرتا=darta
ڈر=dar
ڈراؤ=daraao
ڈرنے=darne
خوف=khauf
امید=umeed
ہدایت=hidayat
گمراہ=gumrah
گمراہی=gumrahi
سیدھا=seedha
سیدھی=seedhi
راستہ=raasta
راستے=raaste
راہ=raah
راہوں=raahon
صراط=siraat
حق=haq
باطل=baatil
سچ=sach
سچا=sachcha
سچی=sachchi
سچے=sachche
سچائی=sachchai
جھوٹ=jhoot
جھوٹا=jhoota
جھوٹے=jhoote
جھٹلایا=jhutlaya
علم=ilm
عالم=aalim
علماء=ulama
حکمت=hikmat
عقل=aql
عقلمند=aqalmand
دل=dil
دلوں=dilon
آنکھ=aankh
آنکھیں=aankhein
آنکھوں=aankhon
کان=kaan
کانوں=kaanon
زبان=zabaan
ہاتھ=haath
ہاتھوں=haathon
پاؤں=paaon
جان=jaan
جانیں=jaanein
نفس=nafs
روح=rooh
جسم=jism
سینہ=seena
سینوں=seenon
چہرہ=chehra
چہرے=chehre
چہروں=chehron
مال=maal
مالوں=maalon
دولت=daulat
اولاد=aulad
بیٹا=beta
بیٹے=bete
بیٹی=beti
بیٹیاں=betiyan
بیٹوں=beton
والدین=walidain
ماں=maa
باپ=baap
ماں باپ=maa baap
بھائی=bhai
بھائیوں=bhaiyon
بہن=behan
بہنیں=behnein
بیوی=biwi
بیویاں=biwiyan
بیویوں=biwiyon
شوہر=shauhar
خاوند=khaawand
عورت=aurat
عورتیں=auratein
عورتوں=auraton
مرد=mard
مردوں=mardon
لوگ=log
لوگوں=logon
انسان=insaan
انسانوں=insaanon
قوم=qaum
قومیں=qaumein
قوموں=qaumon
بستی=basti
بستیوں=bastiyon
شہر=shehar
زمین=zameen
آسمان=aasmaan
آسمانوں=aasmanon
سورج=sooraj
چاند=chaand
ستارے=sitare
پانی=paani
پہاڑ=pahaar
پہاڑوں=pahaaron
سمندر=samundar
دریا=darya
بارش=baarish
رزق=rizq
روزی=rozi
کھانا=khaana
کھاؤ=khao
کھاتے=khaate
کھاتا=khaata
پیو=piyo
پیتے=peete
پینا=peena
حکم=hukm
احکام=ahkaam
منع=mana
روکتا=rokta
"""

    private const val D4 = """
روکتے=rokte
روکو=roko
فرض=farz
حلال=halal
حرام=haram
جائز=jaiz
نیت=niyyat
نیتوں=niyyaton
عمل=amal
اعمال=aamaal
عملوں=amalon
کام=kaam
کاموں=kaamon
کہو=kaho
کہا=kaha
کہہ=keh
کہتے=kehte
کہتا=kehta
کہتی=kehti
کہنا=kehna
کہنے=kehne
کہیں=kahin
فرمایا=farmaya
فرماتا=farmata
فرماتے=farmate
فرمائے=farmaye
بتایا=bataya
بتاؤ=batao
بتا=bata
بتانا=batana
دیا=diya
دیتا=deta
دیتے=dete
دیتی=deti
دی=di
دیے=diye
دئیے=diye
دے=de
دیں=dein
دینا=dena
دینے=dene
دوں=doon
لو=lo
لیا=liya
لیتے=lete
لیتا=leta
لیں=lein
لے=le
لینا=lena
لینے=lene
لوں=loon
کرو=karo
کرتے=karte
کرتا=karta
کرتی=karti
کریں=karein
کرے=kare
کرنا=karna
کروں=karoon
کر=kar
کیے=kiye
کئے=kiye
کرنے=karne
کرنے والے=karne waale
کرنے والا=karne wala
کرنے والی=karne wali
والا=wala
والے=waale
والی=wali
والوں=waalon
کرکے=karke
کردیا=kar diya
کرچکے=kar chuke
کرلو=kar lo
کی ہے=ki hai
جاؤ=jao
جاتا=jaata
جاتے=jaate
جاتی=jaati
جائے=jaye
جائیں=jayein
جانے=jaane
جانا=jaana
گیا=gaya
گئے=gaye
گئی=gayi
گئیں=gayin
آیا=aaya
آئے=aaye
آئی=aayi
آئیں=aayein
آؤ=aao
آتا=aata
آتے=aate
آتی=aati
آنا=aana
آنے=aane
بھیجا=bheja
بھیجے=bheje
بھیج=bhej
بھیجتا=bhejta
دیکھ=dekh
دیکھو=dekho
دیکھا=dekha
دیکھتے=dekhte
دیکھتا=dekhta
دیکھنے=dekhne
سنو=suno
سنا=suna
سنتا=sunta
سنتے=sunte
سنتی=sunti
سننے=sunne
جانتا=jaanta
جانتے=jaante
جانتی=jaanti
جانو=jaano
جان لو=jaan lo
سمجھ=samajh
سمجھو=samjho
سمجھتے=samajhte
سمجھا=samjha
مانو=maano
مانا=maana
مانتے=maante
مانیں=maanein
لائے=laaye
لایا=laaya
لاؤ=lao
لانے=laane
رکھ=rakh
رکھا=rakha
رکھتا=rakhta
رکھتے=rakhte
رکھو=rakho
رکھیں=rakhein
رہو=raho
رہا=raha
رہے=rahe
رہی=rahi
رہتے=rehte
رہتا=rehta
رہنا=rehna
رہیں=rahein
بنایا=banaya
بنائے=banaaye
بناؤ=banao
بنا=bana
بنے=bane
پیدا=paida
"""

    private const val D5 = """
پیدا کیا=paida kiya
مارو=maaro
مارا=maara
قتل=qatl
ہلاک=halaak
بچاؤ=bachao
بچا=bacha
بچو=bacho
بچتے=bachte
بچنا=bachna
چھوڑ=chhor
چھوڑو=chhoro
چھوڑ دو=chhor do
چھوڑتا=chhorta
چلو=chalo
چلتے=chalte
چلا=chala
چلنے=chalne
پڑھو=parho
پڑھا=parha
پڑھتے=parhte
پڑھنا=parhna
پڑھنے=parhne
لکھا=likha
لکھ=likh
لکھی=likhi
سکھا=sikha
سیکھ=seekh
سکھائے=sikhaye
سیکھے=seekhe
ملا=mila
ملے=mile
ملتا=milta
ملیں=milein
پاؤ=paao
پائے=paaye
پایا=paaya
پاتے=paate
مانگو=mango
مانگتے=maangte
مانگا=manga
پوچھو=poochho
پوچھتے=poochhte
پوچھا=poochha
پوچھیں=poochhein
بولو=bolo
بولتے=bolte
بول=bol
بیان=bayan
بیان کیا=bayan kiya
بھولو=bhoolo
بھول=bhool
بھولا=bhoola
یاد=yaad
یاد کرو=yaad karo
یاد رکھو=yaad rakho
ذکر=zikr
خوش=khush
خوشخبری=khushkhabri
خوشخبری سنا=khushkhabri suna
غم=gham
غمگین=ghamgeen
اداس=udaas
پاک=paak
پاکیزہ=paakeeza
پاکی=paaki
پاکیزگی=paakeezgi
صاف=saaf
ناپاک=naapaak
اعلی=aala
بلند=buland
عظیم=azeem
بزرگ=buzurg
بزرگی=buzurgi
کریم=Kareem
علیم=Aleem
حکیم=Hakeem
غفور=Ghafoor
ودود=Wadood
سمیع=Samee
بصیر=Baseer
خبیر=Khabeer
عزیز=Azeez
غالب=ghaalib
رزاق=Razzaq
مالک=maalik
بادشاہ=baadshah
بادشاہی=baadshahi
حکومت=hukoomat
ملک=mulk
سلطنت=saltanat
قدرت=qudrat
قادر=qaadir
طاقت=taaqat
چیز=cheez
چیزوں=cheezon
چیزیں=cheezein
بات=baat
باتیں=baatein
باتوں=baaton
بارے=baare
معاملہ=muamla
معاملات=muamlaat
حال=haal
حالت=haalat
وقت=waqt
مدت=muddat
زمانہ=zamana
محمد=Muhammad
موسی=Musa
عیسی=Isa
ابراہیم=Ibrahim
اسماعیل=Ismail
اسحاق=Ishaq
یعقوب=Yaqub
یوسف=Yusuf
نوح=Nooh
آدم=Aadam
داؤد=Dawood
سلیمان=Sulaiman
ایوب=Ayyub
یونس=Yunus
ہارون=Haroon
فرعون=Firaun
مریم=Maryam
لوط=Lut
ہود=Hood
صالح=Saleh
شعیب=Shuaib
زکریا=Zakariyya
یحیی=Yahya
اسرائیل=Israel
بنی اسرائیل=Bani Israel
مکہ=Makkah
مدینہ=Madinah
کعبہ=Kaaba
جبرائیل=Jibreel
جبریل=Jibreel
حدیث=hadees
صحابہ=sahaba
سنت=sunnat
امت=ummat
مسجد=masjid
مسجدوں=masjidon
جماعت=jamaat
امام=imam
جمعہ=Jumah
فجر=Fajr
ظہر=Zuhr
عصر=Asr
"""

    private const val D6 = """
مغرب=Maghrib
عشاء=Isha
عشا=Isha
رمضان=Ramzan
قبر=qabr
قبروں=qabron
جنازہ=janaza
وضو=wuzu
طہارت=taharat
غسل=ghusl
سلام=salaam
درود=durood
تسبیح=tasbeeh
استغفار=istighfaar
ہجرت=hijrat
جہاد=jihad
پڑوسی=padosi
پڑوسیوں=padosiyon
ہمسایہ=hamsaya
مہمان=mehmaan
یتیم=yateem
یتیموں=yateemon
مسکین=miskeen
مسکینوں=miskeenon
فقیر=faqeer
غریب=ghareeb
غریبوں=ghareebon
امیر=ameer
تجارت=tijarat
سود=sood
امانت=amanat
وعدہ=wada
عہد=ahad
خیانت=khayanat
جھگڑا=jhagra
غیبت=gheebat
چغلی=chughli
حسد=hasad
تکبر=takabbur
غرور=ghuroor
عاجزی=aajzi
حیا=haya
شرم=sharm
غصہ=ghussa
غصے=ghusse
نرمی=narmi
سخاوت=sakhawat
بخل=bukhl
رشتہ=rishta
رشتے=rishte
رشتہ داروں=rishtedaaron
رشتہ دار=rishtedaar
صلہ رحمی=sila rehmi
نعمت=nemat
نعمتیں=nemtein
نعمتوں=nematon
فضل=fazl
احسان=ehsaan
تکلیف=takleef
مصیبت=museebat
مصیبتیں=museebatein
آزمائش=aazmaish
آزمائیں=aazmaein
آزمایا=aazmaya
مشکل=mushkil
مشکلات=mushkilaat
آسانی=aasaani
آسان=aasaan
سہولت=sahoolat
تنگی=tangi
تنگدستی=tangdasti
فقر=faqr
بھوک=bhook
پیاس=pyaas
ڈرنا=darna
گواہ=gawah
گواہی=gawahi
گواہ ہے=gawah hai
شاہد=shaahid
نگہبان=nigehbaan
وکیل=wakeel
کافی=kaafi
مددگار=madadgaar
مدد=madad
مدد کرنا=madad karna
دوست=dost
دوستو=dosto
دشمن=dushman
دشمنوں=dushmanon
دشمنی=dushmani
محبت=mohabbat
پیار=pyaar
پسند=pasand
نفرت=nafrat
ناراض=naaraaz
راضی=raazi
خوشی=khushi
فتح=fatah
نصرت=nusrat
کامیابی=kaamyabi
کامیاب=kaamyaab
نقصان=nuqsaan
خسارہ=khasaara
فائدہ=faida
فائدے=faide
نفع=nafa
بھلا=bhala
بہتری=behtari
بہتیرے=bahutere
اکیلا=akela
اکیلے=akele
شریک=shareek
شریکوں=shareekon
معبود=maabood
معبودوں=maaboodon
عبادت کرو=ibadat karo
پوجا=pooja
بت=but
بتوں=buton
غیب=ghaib
بھید=bhed
ظاہر=zaahir
چھپا=chhupa
چھپے=chhupe
کھلا=khula
کھلے=khule
ایمان والو=imaan walo
ایمان والوں=imaan waalon
ایمان والے=imaan waale
اے لوگو=aye logo
اے=aye
او=o
جی=ji
ہاں=haan
نا=na
کیسے=kaise
کیسا=kaisa
کتنا=kitna
کتنے=kitne
کیونکر=kyunkar
جیسے کہ=jaise ke
مانند=maanind
برابر=barabar
سوائے=siwaye
مگر یہ کہ=magar yeh ke
اس لئے=is liye
اس لیے=is liye
اسلئے=is liye
اسی لئے=isi liye
تو بھی=to bhi
"""

    private const val D7 = """
پھر بھی=phir bhi
اگرچہ=agarche
جبکہ=jabke
حالانکہ=halanke
بلکہ یہ=balke yeh
تاہم=taahum
ورنہ=warna
وغیرہ=waghaira
غرض=gharz
مثلا=masalan
مثال=misaal
مثالیں=misaalein
مانند ہے=maanind hai
مثل=misl
بتایا ہے=bataya hai
پیدائش=paidaish
اولین=awwaleen
آخر=aakhir
آخری=aakhri
پہلا=pehla
پہلی=pehli
اول=awwal
نئی=nayi
نیا=naya
نئے=naye
پرانا=puraana
پرانے=puraane
زندہ=zinda
مردہ=murda
مردے=murde
مردوں کو=mardon ko
بیمار=beemaar
بیماری=beemaari
شفا=shifa
صحت=sehat
تندرستی=tandurusti
فراغت=faraghat
فرصت=fursat
مسافر=musafir
سفر=safar
گھر=ghar
گھروں=gharon
دروازہ=darwaza
دروازے=darwaze
راستے میں=raaste mein
بازار=bazaar
بازاروں=bazaaron
قریب=qareeb
دور=door
اونچا=ooncha
اونچی=oonchi
نزدیک=nazdeek
بہت زیادہ=bohat zyada
بہتات=bohtaat
تھوڑا=thoda
تھوڑی=thodi
تھوڑے=thode
تھوڑی سی=thodi si
ہلکا=halka
ہلکے=halke
بھاری=bhaari
وزن=wazan
ترازو=tarazu
میزان=mizaan
عدل=adl
انصاف=insaaf
ظلم نہ کرو=zulm na karo
بھروسہ=bharosa
بھروسا=bharosa
اعتماد=aitmaad
شکر کرو=shukar karo
شکر گزار=shukar guzaar
ناشکری=naashukri
ناشکرا=naashukra
احسان مند=ehsaan mand
بدگمانی=badgumani
گمان=gumaan
شک=shak
شبہ=shubah
رازق=raaziq
خالق=khaaliq
مخلوق=makhlooq
مخلوقات=makhlooqaat
دانا=daana
جاننے=jaanne
جاننے والا=jaanne wala
خبر=khabar
خبردار=khabardaar
خبر رکھنے والا=khabar rakhne wala
دیکھنے والا=dekhne wala
سننے والا=sunne wala
معاف=maaf
معاف کرنے=maaf karne
معاف کرنے والا=maaf karne wala
درگزر=dar guzar
توبہ قبول=tauba qabool
قبول=qabool
قبول کرنے=qabool karne
قبول کرتا=qabool karta
پکارتا=pukarta
پکارنے=pukaarne
پکارو=pukaaro
پکارنے والا=pukaarne wala
دریافت=daryaft
جواب=jawaab
مدد مانگو=madad mango
سہارا=sahaara
پناہ=panaah
پناہ مانگو=panaah mango
حفاظت=hifazat
محفوظ=mehfooz
ذمہ=zimma
ذمے=zimme
فرض ہے=farz hai
واجب=waajib
سنتیں=sunnatein
نفل=nafl
نفلی=nafli
تہجد=tahajjud
رکعت=rakat
رکعتیں=rakatein
سجدہ=sajda
سجدے=sajde
رکوع=ruku
قیام=qayam
قعدہ=qaada
تلاوت=tilawat
حافظ=haafiz
قاری=qaari
مؤذن=muazzin
اذان=azaan
اقامت=iqamat
صف=saf
صفیں=safein
پہلی صف=pehli saf
عید=Eid
عیدین=Eidain
فطرہ=fitra
فدیہ=fidya
کفارہ=kaffara
قسم=qasam
قسمیں=qasmein
قسم کھاؤ=qasam khao
نذر=nazar
منت=mannat
وراثت=wiraasat
میراث=meeraas
وصیت=wasiyat
نکاح=nikah
شادی=shaadi
"""

    private const val D8 = """
طلاق=talaaq
مہر=mehr
حیض=haiz
پردہ=parda
حجاب=hijaab
لباس=libaas
زینت=zeenat
خوشبو=khushboo
زیور=zewar
سونا=sona
چاندی=chaandi
مال و دولت=maal o daulat
مال و اولاد=maal o aulad
عزت=izzat
ذلت=zillat
رسوائی=ruswai
شرمندہ=sharminda
فخر=fakhr
شان=shaan
شہرت=shohrat
نام=naam
نام لو=naam lo
نام سے=naam se
کلمہ=kalima
کلمات=kalimaat
لفظ=lafz
لفظوں=lafzon
بولی=boli
خطبہ=khutba
وعظ=waaz
نصیحت=naseehat
نصیحتیں=naseehatein
عبرت=ibrat
سبق=sabaq
تعلیم=taleem
معلم=muallim
استاد=ustaad
طالب علم=talib-e-ilm
شاگرد=shagird
مدرسہ=madrasa
دعوت=daawat
دعوت دو=daawat do
تبلیغ=tableegh
پیغام=paighaam
خوشخبری دینے=khushkhabri dene
ڈرانے=daraane
ڈرانے والا=daraane wala
خبردار کرنے=khabardaar karne
کرنے والوں=karne waalon
پہنچا=pahuncha
پہنچانا=pahunchana
پہنچاؤ=pahunchao
آدمی=aadmi
آدمیوں=aadmiyon
ابوہریرہ=Abu Hurairah
ابو ہریرہ=Abu Hurairah
اطمینان=itminaan
حضرت=Hazrat
دارومدار=daaromadaar
روایت=riwayat
لائیں=laayein
پائیں=paayein
شخص=shakhs
اشخاص=ashkhaas
داخل=daakhil
داخل ہوگا=daakhil hoga
اللہ تعالیٰ=Allah Ta'ala
نبی کریم=Nabi Kareem
اطاعت=itaat
فرمانبرداری=farmaanbardaari
نافرمانی=nafarmaani
زیادتی=zyaadti
حد=had
حد سے=had se
سن رکھو=sun rakho
سن لو=sun lo
خاموش=khaamosh
خاموشی=khaamoshi
مسکرانا=muskurana
مسکراہٹ=muskurahat
اخلاق=akhlaaq
عادت=aadat
عادتیں=aadatein
جھگڑے=jhagre
ہمت=himmat
ناامید=naa-umeed
ناامید نہ=naa-umeed na
کھول=khol
کھول دے=khol de
جھٹلاؤ=jhutlao
جھٹلاؤ گے=jhutlaoge
جھٹلاتے=jhutlaate
کون کون=kaun kaun
بھروسہ رکھے=bharosa rakhe
رکھتا ہو=rakhta ho
رکھتے ہو=rakhte ho
رکھتے ہیں=rakhte hain
مسلمان محفوظ=musalman mehfooz
محفوظ رہیں=mehfooz rahein
مانتے رہنا=maante rehna
احسان مانتے=ehsaan maante
نصف=nisf
آدھا=aadha
آدھی=aadhi
بےنیاز=be-niyaaz
بے نیاز=be-niyaaz
نیاز=niyaaz
برحق=barhaq
معبود برحق=maabood-e-barhaq
واجب القتل=waajib-ul-qatl
ذات=zaat
ذات پاک=zaat-e-paak
اولاد کی=aulad ki
انس=ins
جن و انس=jinn o ins
تمہی=tumhi
تم ہی=tum hi
رہو گے=rahoge
کرو گے=karoge
کریں گے=karenge
کرے گا=karega
دے گا=dega
دیں گے=denge
ملیں گے=milenge
جائیں گے=jayenge
آئیں گے=aayenge
جانتا ہے=jaanta hai
جانتے ہیں=jaante hain
جانتے ہو=jaante ho
ہے اور=hai aur
ہیں اور=hain aur
بخش دے=bakhsh de
بخش دو=bakhsh do
کرم=karam
مہر=meher
شفقت=shafqat
سلوک=sulook
حسن سلوک=husn-e-sulook
بدسلوکی=badsulooki
بدی=badi
بدیاں=badiyan
ہمدردی=hamdardi
اتحاد=ittehaad
اختلاف=ikhtilaaf
تفرقہ=tafarqa
فرقے=firqe
جماعتیں=jamaatein
پکڑ=pakad
پکڑو=pakdo
مضبوط=mazboot
"""

    private const val D9 = """
مضبوطی=mazbooti
رسی=rassi
تھام=thaam
تھامو=thaamo
سہل=sahal
آسانی کرو=aasaani karo
دشواری=dushwaari
بوجھ=bojh
بوجھ نہیں=bojh nahin
طاقت سے=taaqat se
گنجائش=gunjaish
خیر=khair
شر=shar
فتنہ=fitna
فتنے=fitne
فساد=fasaad
امن=aman
سلامتی=salamati
اطمینان ملتا=itminaan milta
آرام=aaraam
آرام پاتے=aaraam paate
دلوں کو=dilon ko
دل سے=dil se
جی=jee
رکھنے=rakhne
رکھنے والا=rakhne wala
رکھنے والے=rakhne waale
ہونے والا=hone wala
ہونے والے=hone waale
سکتا=sakta
سکتے=sakte
سکتی=sakti
سکو=sako
سکیں=sakein
سکے=sake
ادا=ada
ادا کرنا=ada karna
ادا کرتا=ada karta
ادا کرو=ada karo
حاصل=haasil
حاصل کرنے=haasil karne
حاصل کرنا=haasil karna
رہنے=rehne
کہے=kahe
چلتا=chalta
ہارو=haaro
قدموں=qadmon
قدم=qadam
بندو=bando
جانوں=jaanon
سی=si
سے ہی=se hi
اٹھ=uth
اٹھو=utho
اٹھا=utha
اٹھے=uthe
بیٹھ=baith
بیٹھو=baitho
بیٹھا=baitha
جاگ=jaag
سوتا=sota
سوئے=soye
نکل=nikal
نکلو=niklo
نکلا=nikla
نکالا=nikaala
نکالو=nikalo
داخل ہو=daakhil ho
داخل کرے=daakhil kare
داخل کرتا=daakhil karta
بیٹھنا=baithna
کھڑے=khade
کھڑا=khada
کھڑی=khadi
ٹھہرو=thehro
ٹھہرا=thehra
چھپاؤ=chhupao
چھپانا=chhupana
ظاہر کرو=zaahir karo
دکھا=dikha
دکھاؤ=dikhao
دکھائی=dikhai
ملاؤ=milao
ملانا=milana
جمع=jama
جمع کرو=jama karo
بانٹ=baant
بانٹو=baanto
دینے والا=dene wala
دینے والے=dene waale
لینے والا=lene wala
لینے والے=lene waale
ہاتھ سے=haath se
ہاتھ میں=haath mein
اوپر والا=oopar wala
نیچے والا=neeche wala
اوپر کا ہاتھ=oopar ka haath
نیچے کے ہاتھ=neeche ke haath
ہاتھ بہتر=haath behtar
سے بہتر=se behtar
بہتر ہے=behtar hai
افضل=afzal
اعلیٰ=aala
بہترین ہے=behtareen hai
پسندیدہ=pasandeeda
محبوب=mehboob
پیارا=pyaara
پیارے=pyaare
پیاری=pyaari
ناپسند=naapasand
مبغوض=mabghooz
ناراضگی=naaraazgi
غضب=ghazab
غضب سے=ghazab se
رحمت غضب=rehmat ghazab
غالب ہے=ghaalib hai
غالب رہے=ghaalib rahe
آگ=aag
آگ سے=aag se
آگ میں=aag mein
کھجور=khajoor
کھجور کا=khajoor ka
ٹکڑا=tukra
ٹکڑے=tukre
آدھی کھجور=aadhi khajoor
پہلوان=pehalwan
طاقتور=taaqatwar
پچھاڑ=pachhaar
پچھاڑے=pachhaade
قابو=qaabu
قابو میں=qaabu mein
رکھے=rakhe
مسافر کی=musafir ki
راہ چلتا=raah chalta
اجنبی=ajnabi
غریب الوطن=ghareeb-ul-watan
بے مقصد=be-maqsad
بے کار=bekaar
فضول=fuzool
فضول باتیں=fuzool baatein
مفید=mufeed
نفع بخش=nafa bakhsh
صدقہ جاریہ=sadqa-e-jaariya
نیک اولاد=nek aulad
دعا کرنے=dua karne
دعا کرنے والی=dua karne wali
جاری=jaari
منقطع=munqata
منقطع ہو جاتا=munqata ho jaata
ہو جاتا=ho jaata
"""

    private const val D10 = """
ہو جاتے=ho jaate
ہو جاتی=ho jaati
ہو جائے=ho jaye
ہو جائیں=ho jayein
ہو گیا=ho gaya
ہو گئے=ho gaye
ہو گئی=ho gayi
ہو سکتا=ho sakta
ہو سکتی=ho sakti
ہو سکتے=ho sakte
نہ ہو=na ho
نہ ہوگا=na hoga
ہوتے ہیں=hote hain
ہوتی ہے=hoti hai
ہوتا ہے=hota hai
ہوتا ہو=hota ho
دیا جاتا=diya jaata
کیا جاتا=kiya jaata
کیا جائے=kiya jaye
کیا گیا=kiya gaya
دیا گیا=diya gaya
کہا گیا=kaha gaya
بتایا گیا=bataya gaya
پڑھا جاتا=parha jaata
پیدا ہوا=paida hua
پیدا ہوئے=paida hue
پیدا ہوتا=paida hota
جمعہ کا دن=Jumah ka din
دن جس=din jis
سب سے=sab se
سب سے بہتر=sab se behtar
سب سے اچھا=sab se achha
سب سے اچھے=sab se achhe
سب سے زیادہ=sab se zyada
سب سے پہلے=sab se pehle
سب سے بڑا=sab se bada
سب سے بڑی=sab se badi
سب سے بڑے=sab se bade
مقابلے=muqable
مقابلے میں=muqable mein
فرمانے=farmane
فرمانے والے=farmane waale
خدمت=khidmat
خدمت کرو=khidmat karo
حاجت=haajat
حاجت مند=haajat mand
ضرورت=zaroorat
ضرورت مند=zaroorat mand
ضرورتیں=zarooratein
پوری=poori
پورا=poora
پورے=poore
مکمل=mukammal
کامل=kaamil
باقی=baaqi
بس=bas
صرف=sirf
فقط=faqat
محض=mahaz
ہی نہیں=hi nahin
نہ کہ=na ke
مثلاً=masalan
خصوصاً=khusoosan
خاص=khaas
عام=aam
عامۃ=aamma
عمومی=umoomi
خود=khud
بذات خود=bizzaat khud
آپس=aapas
آپس میں=aapas mein
ایک دوسرے=ek doosre
ایک دوسرے کو=ek doosre ko
ایک دوسرے سے=ek doosre se
ایک دوسرے کے=ek doosre ke
ایک دوسرے کا=ek doosre ka
دونوں=dono
دونوں کے=dono ke
سبھی=sabhi
سب کو=sab ko
سب کچھ=sab kuch
کچھ بھی=kuch bhi
کچھ نہیں=kuch nahin
کوئی بھی=koi bhi
کوئی نہیں=koi nahin
کسی کو=kisi ko
کسی کا=kisi ka
کسی کی=kisi ki
کسی کے=kisi ke
کسی سے=kisi se
کسی نے=kisi ne
ہر ایک=har ek
ہر شخص=har shakhs
ہر چیز=har cheez
ہر وقت=har waqt
ہر روز=har roz
ہر دن=har din
ہر رات=har raat
ہر نماز=har namaz
ہر نماز کے=har namaz ke
ہر مشکل=har mushkil
ہر مشکل کے=har mushkil ke
ہر کام=har kaam
ہر نیک=har nek
ہر نیک کام=har nek kaam
ہر بھلائی=har bhalai
ہر برائی=har burai
"""
}
