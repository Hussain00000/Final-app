package com.example.mydeen

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import java.util.Calendar

data class HadithEntry(val text: String, val source: String)

/** A small offline collection; one hadith is shown per day and it changes at midnight. */
object Hadith {
    val all: List<HadithEntry> = listOf(
        HadithEntry("Actions are judged by intentions, and every person will get what they intended.", "Sahih al-Bukhari 1, Sahih Muslim 1907"),
        HadithEntry("None of you truly believes until he loves for his brother what he loves for himself.", "Sahih al-Bukhari 13, Sahih Muslim 45"),
        HadithEntry("The best of you are those who learn the Qur’an and teach it.", "Sahih al-Bukhari 5027"),
        HadithEntry("Whoever believes in Allah and the Last Day, let him speak good or remain silent.", "Sahih al-Bukhari 6018, Sahih Muslim 47"),
        HadithEntry("The strong person is not the one who defeats others, but the one who controls himself in anger.", "Sahih al-Bukhari 6114, Sahih Muslim 2609"),
        HadithEntry("Make things easy and do not make them difficult; give glad tidings and do not drive people away.", "Sahih al-Bukhari 69, Sahih Muslim 1734"),
        HadithEntry("The most beloved deeds to Allah are those done regularly, even if they are small.", "Sahih al-Bukhari 6464, Sahih Muslim 783"),
        HadithEntry("Allah does not look at your faces or your wealth, but He looks at your hearts and your deeds.", "Sahih Muslim 2564"),
        HadithEntry("Cleanliness is half of faith.", "Sahih Muslim 223"),
        HadithEntry("A Muslim is the one from whose tongue and hand other Muslims are safe.", "Sahih al-Bukhari 10, Sahih Muslim 40"),
        HadithEntry("Whoever takes a path to seek knowledge, Allah makes easy for him a path to Paradise.", "Sahih Muslim 2699"),
        HadithEntry("There are two blessings many people lose: health and free time.", "Sahih al-Bukhari 6412"),
        HadithEntry("Be in this world as if you were a stranger or a traveller.", "Sahih al-Bukhari 6416"),
        HadithEntry("Part of the excellence of a person’s Islam is leaving that which does not concern him.", "Jami at-Tirmidhi 2317"),
        HadithEntry("Whoever does not show mercy to others will not be shown mercy.", "Sahih al-Bukhari 6013, Sahih Muslim 2318"),
        HadithEntry("Two words are light on the tongue, heavy on the scale and beloved to Ar-Rahman: SubhanAllahi wa bihamdihi, SubhanAllahil-Azim.", "Sahih al-Bukhari 6406, Sahih Muslim 2694"),
        HadithEntry("The best of you are those with the best character.", "Sahih al-Bukhari 3559, Sahih Muslim 2321"),
        HadithEntry("Whoever prays Fajr is under the protection of Allah.", "Sahih Muslim 657"),
        HadithEntry("Whoever sends one blessing upon me, Allah sends ten blessings upon him.", "Sahih Muslim 408"),
        HadithEntry("If a river were at the door of one of you and he bathed in it five times a day, would any dirt remain on him? So are the five prayers; Allah erases sins through them.", "Sahih al-Bukhari 528, Sahih Muslim 667"),
        HadithEntry("Charity never decreases wealth.", "Sahih Muslim 2588"),
        HadithEntry("A man asked the Prophet ﷺ for advice. He said: “Do not become angry.”", "Sahih al-Bukhari 6116"),
        HadithEntry("Whoever relieves a believer of a hardship of this world, Allah will relieve him of a hardship on the Day of Resurrection.", "Sahih Muslim 2699"),
        HadithEntry("Truthfulness leads to righteousness, and righteousness leads to Paradise.", "Sahih al-Bukhari 6094, Sahih Muslim 2607"),
        HadithEntry("Beware of suspicion, for suspicion is the most untruthful of speech.", "Sahih al-Bukhari 6066, Sahih Muslim 2563"),
        HadithEntry("Du‘a is worship.", "Jami at-Tirmidhi 3371"),
        HadithEntry("Whoever is not grateful to people is not grateful to Allah.", "Sunan Abi Dawud 4811, Jami at-Tirmidhi 1954"),
        HadithEntry("Smiling in the face of your brother is charity.", "Jami at-Tirmidhi 1956")
    )

    fun today(): HadithEntry {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        return all[day % all.size]
    }
}

@Composable
fun HadithCard() {
    val h = Hadith.today()
    DeenCard {
        Column(Modifier.padding(16.dp)) {
            Text("Hadith of the day", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text("“${h.text}”", style = MaterialTheme.typography.bodyLarge, fontStyle = FontStyle.Italic, modifier = Modifier.padding(top = 8.dp))
            Text("— ${h.source}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
