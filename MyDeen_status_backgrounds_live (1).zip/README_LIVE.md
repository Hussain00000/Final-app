# Live statuses + backgrounds from Google (Sheet + Drive)

## 1. Create the Google Sheet
Make a sheet with this header row (copy sample_status_sheet.csv via File > Import):

    date | kind | arabic | text | source | theme | bg_url

Add one row per status. Leave `date` blank to rotate daily, or use yyyy-MM-dd to schedule.

## 2. Publish it
File > Share > Publish to web > choose the tab > format **CSV** > Publish. Copy the link and paste it into
`RemoteStatus.SHEET_CSV_URL`. Edits to the sheet go live in the app within ~6 hours (and on next launch after that).

## 3. Backgrounds (optional)
- Upload your own images (1080x1920, calm top area) to Google Drive, set sharing to **Anyone with the link**, paste the
  share link in `bg_url`. The app converts it to a direct download automatically.
- Use only images you own or that are licensed for this (e.g. your own designs, CC0/Unsplash/Pexels). Don't pull from
  Google Image Search – no official API and the images are copyrighted.
- Blank `bg_url` = built-in themed background from the first pack, chosen by `theme` or by the status meaning.

## 4. Wire it in
Add `RemoteStatus.kt` next to `StatusBackgrounds.kt`. In the status screen:

    val bmp = RemoteStatus.renderToday(context)          // in a coroutine (LaunchedEffect / viewModelScope)
        ?: StatusBackgrounds.render(context, arabic, text, source, kind)   // offline/empty-sheet fallback

Needs `<uses-permission android:name="android.permission.INTERNET"/>` (the app already has it for Drive/login).
Cleartext is not needed; all links are https.

## 5. Build the APK on GitHub
.github/workflows/android.yml builds a debug APK on every push (Actions tab > latest run > Artifacts > MyDeen-debug-apk).
Put your Android Studio project at the repo root (needs gradlew and an `app/` module), then copy this pack's files in
as described above and commit.
