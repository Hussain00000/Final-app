package com.example.mydeen

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Classic Islamic footer icons, drawn as vector shapes so they take the theme colour. */
enum class IslamicIcon {
    ARCH_HOME,   // pointed-arch (mihrab) house
    MOSQUE,      // dome with two minarets
    BEADS,       // tasbih / prayer beads
    CRESCENT,    // crescent moon and star
    STAR         // eight-pointed star (Rub el Hizb)
}

@Composable
fun IslamicIconView(icon: IslamicIcon, tint: Color, size: Dp = 26.dp) {
    Canvas(Modifier.size(size).clearAndSetSemantics { }) {
        val s = this.size.width / 24f
        when (icon) {
            IslamicIcon.ARCH_HOME -> archHome(tint, s)
            IslamicIcon.MOSQUE -> mosque(tint, s)
            IslamicIcon.BEADS -> beads(tint, s)
            IslamicIcon.CRESCENT -> crescent(tint, s)
            IslamicIcon.STAR -> eightStar(tint, s)
        }
    }
}

/** Pointed (ogee) arch shape from x1..x2, springing at yBase and rising to yTip. */
private fun Path.archShape(x1: Float, x2: Float, yBase: Float, yTip: Float, yBottom: Float, s: Float) {
    val mid = (x1 + x2) / 2f
    val rise = yBase - yTip
    moveTo(x1 * s, yBottom * s)
    lineTo(x1 * s, yBase * s)
    cubicTo(x1 * s, (yBase - rise * 0.55f) * s, (mid - (mid - x1) * 0.35f) * s, (yTip + rise * 0.25f) * s, mid * s, yTip * s)
    cubicTo((mid + (x2 - mid) * 0.35f) * s, (yTip + rise * 0.25f) * s, x2 * s, (yBase - rise * 0.55f) * s, x2 * s, yBase * s)
    lineTo(x2 * s, yBottom * s)
    close()
}

private fun Path.onionDome(cx: Float, w: Float, baseY: Float, tipY: Float, s: Float) {
    val h = baseY - tipY
    moveTo((cx - w) * s, baseY * s)
    cubicTo((cx - w * 1.3f) * s, (baseY - h * 0.45f) * s, (cx - w * 0.35f) * s, (baseY - h * 0.62f) * s, cx * s, tipY * s)
    cubicTo((cx + w * 0.35f) * s, (baseY - h * 0.62f) * s, (cx + w * 1.3f) * s, (baseY - h * 0.45f) * s, (cx + w) * s, baseY * s)
    close()
}

private fun DrawScope.archHome(c: Color, s: Float) {
    val body = Path().apply {
        fillType = PathFillType.EvenOdd
        archShape(3.5f, 20.5f, 11f, 2.2f, 21.5f, s)
        archShape(9.3f, 14.7f, 16.2f, 12.2f, 21.5f, s)   // doorway cut-out
    }
    drawPath(body, c)
    // small finial on top of the arch
    drawRect(c, Offset(11.7f * s, 0.6f * s), Size(0.6f * s, 1.8f * s))
}

private fun DrawScope.mosque(c: Color, s: Float) {
    val p = Path().apply {
        fillType = PathFillType.EvenOdd
        // main hall
        moveTo(6.5f * s, 11f * s); lineTo(17.5f * s, 11f * s); lineTo(17.5f * s, 21.5f * s); lineTo(6.5f * s, 21.5f * s); close()
        // doorway cut-out
        archShape(10.2f, 13.8f, 17f, 14f, 21.5f, s)
    }
    drawPath(p, c)
    // central dome + finial
    drawPath(Path().apply { onionDome(12f, 5.6f, 11f, 3.4f, s) }, c)
    drawRect(c, Offset(11.75f * s, 1.2f * s), Size(0.5f * s, 2.4f * s))
    // minarets: shaft, balcony and pointed cap
    listOf(3.4f, 20.6f).forEach { x ->
        drawRect(c, Offset((x - 1f) * s, 9f * s), Size(2f * s, 12.5f * s))
        drawRect(c, Offset((x - 1.5f) * s, 8.2f * s), Size(3f * s, 0.9f * s))
        drawPath(Path().apply {
            moveTo((x - 1f) * s, 8.2f * s); lineTo(x * s, 3.8f * s); lineTo((x + 1f) * s, 8.2f * s); close()
        }, c)
    }
    drawRect(c, Offset(1f * s, 21.5f * s), Size(22f * s, 1.2f * s))
}

private fun DrawScope.beads(c: Color, s: Float) {
    val cx = 12f
    val cy = 9.6f
    val r = 6.6f
    for (i in 0 until 12) {
        if (i == 3) continue                                    // gap at the bottom for the tassel
        val a = (i * 30.0 + 0.0) * PI / 180.0
        drawCircle(c, 1.55f * s, Offset((cx + r * cos(a).toFloat()) * s, (cy + r * sin(a).toFloat()) * s))
    }
    // lead bead, cord and tassel
    drawCircle(c, 1.2f * s, Offset(12f * s, 17.2f * s))
    drawLine(c, Offset(12f * s, 15.8f * s), Offset(12f * s, 19f * s), strokeWidth = 1f * s)
    drawPath(Path().apply {
        moveTo(10.7f * s, 19f * s); lineTo(13.3f * s, 19f * s); lineTo(14.2f * s, 23.2f * s); lineTo(9.8f * s, 23.2f * s); close()
    }, c)
}

private fun starPath(cx: Float, cy: Float, outer: Float, inner: Float, points: Int, rotDeg: Float, s: Float): Path {
    val p = Path()
    for (i in 0 until points * 2) {
        val rad = if (i % 2 == 0) outer else inner
        val a = (rotDeg + i * 180f / points) * PI / 180.0
        val x = (cx + rad * cos(a).toFloat()) * s
        val y = (cy + rad * sin(a).toFloat()) * s
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return p
}

private fun DrawScope.crescent(c: Color, s: Float) {
    val outer = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(11f * s, 12f * s), 9f * s)) }
    val cut = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(15f * s, 10.2f * s), 7.4f * s)) }
    drawPath(Path.combine(PathOperation.Difference, outer, cut), c)
    drawPath(starPath(16.8f, 8.6f, 3.4f, 1.4f, 5, -90f, s), c)
}

private fun DrawScope.eightStar(c: Color, s: Float) {
    // Rub el Hizb: two overlapping squares, one turned 45 degrees, with a ring cut out of the middle
    fun square(rot: Double): Path {
        val p = Path()
        for (i in 0 until 4) {
            val a = rot + i * PI / 2
            val x = (12f + 10.4f * cos(a).toFloat()) * s
            val y = (12f + 10.4f * sin(a).toFloat()) * s
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }
    val union = Path.combine(PathOperation.Union, square(PI / 4), square(0.0))
    val ring = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(12f * s, 12f * s), 4.6f * s)) }
    val hole = Path.combine(PathOperation.Difference, union, ring)
    drawPath(hole, c)
    drawCircle(c, 2.1f * s, Offset(12f * s, 12f * s))
}
