package com.example.mydeen

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import java.util.Random

/**
 * Endless Quran verses and hadith from free public sources (no key needed, internet required):
 *  - Quran: api.alquran.cloud (Arabic, transliteration in English letters, Sahih International English, Urdu)
 *  - Hadith: the fawazahmed0 hadith-api on jsDelivr (Arabic, English, Urdu)
 * Only short ones that fit on a status picture are used.
 */
object OnlineVerses {
    private val rnd = Random()
    private const val UA = "MyDeenApp/1.0 (Android; Islamic status maker)"

    private class Collection(val id: String, val name: String, val max: Int)

    private val collections = listOf(
        Collection("bukhari", "Sahih al-Bukhari", 7000),
        Collection("muslim", "Sahih Muslim", 5000),
        Collection("tirmidhi", "Jami at-Tirmidhi", 3800),
        Collection("abudawud", "Sunan Abi Dawud", 5000),
        Collection("ibnmajah", "Sunan Ibn Majah", 4300),
        Collection("nasai", "Sunan an-Nasa'i", 5600)
    )

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 12000
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode != 200) throw java.io.IOException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun clean(s: String): String = s.replace(Regex("<[^>]*>"), "").replace(Regex("\\s+"), " ").trim()

    /**
     * Urdu script -> Roman Urdu (Urdu written in English letters), using Google's free romanization.
     * Machine made, so it can be a little off. Returns null when it can't be done (the Urdu script is shown instead).
     */
    private fun romanUrdu(urdu: String): String? {
        if (urdu.isBlank()) return null
        return try {
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=ur&tl=en&dt=t&dt=rm&q=" +
                URLEncoder.encode(urdu, "UTF-8")
            val first = JSONArray(get(url)).optJSONArray(0) ?: return null
            val sb = StringBuilder()
            for (i in 0 until first.length()) {
                val e = first.optJSONArray(i) ?: continue
                if (e.length() >= 4 && e.isNull(0)) {
                    val t = e.optString(3)
                    if (t.isNotBlank()) {
                        if (sb.isNotEmpty()) sb.append(' ')
                        sb.append(t)
                    }
                }
            }
            // drop the accent marks (ā -> a) so it reads like normal Roman Urdu
            val plain = Normalizer.normalize(sb.toString(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").trim()
            if (plain.isEmpty()) null else plain.replaceFirstChar { it.uppercase() }
        } catch (e: Exception) {
            null
        }
    }

    /** A new random verse or hadith. [filter] is "all", "quran" or "hadith". Null when nothing could be loaded. */
    fun random(filter: String): StatusVerse? {
        val wantQuran = when (filter) {
            "quran" -> true
            "hadith" -> false
            else -> rnd.nextBoolean()
        }
        val first = if (wantQuran) randomAyah() else randomHadith()
        if (first != null || filter != "all") return first
        return if (wantQuran) randomHadith() else randomAyah()
    }

    private fun randomAyah(): StatusVerse? {
        for (attempt in 0 until 8) {
            try {
                val n = 1 + rnd.nextInt(6236)
                val json = JSONObject(get("https://api.alquran.cloud/v1/ayah/$n/editions/quran-uthmani,en.transliteration,en.sahih,ur.jalandhry"))
                val arr = json.getJSONArray("data")
                var ar = ""; var ro = ""; var en = ""; var ur = ""
                var surahName = ""; var surahNo = 0; var inSurah = 0
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val text = clean(o.optString("text"))
                    when (o.getJSONObject("edition").optString("identifier")) {
                        "quran-uthmani" -> ar = text
                        "en.transliteration" -> ro = text
                        "en.sahih" -> en = text
                        "ur.jalandhry" -> ur = text
                    }
                    val surah = o.optJSONObject("surah")
                    if (surah != null) {
                        surahName = surah.optString("englishName")
                        surahNo = surah.optInt("number")
                    }
                    inSurah = o.optInt("numberInSurah")
                }
                if (inSurah == 1 && surahNo != 1) continue          // first verses carry the Bismillah in the text
                if (ar.isEmpty() || en.isEmpty()) continue
                if (ar.length > 170 || en.length > 260) continue    // too long for one status
                val urRoman = romanUrdu(ur)
                return StatusVerse(ar, ro, en, urRoman ?: ur, "Surah $surahName $surahNo:$inSurah", true, urduRtl = urRoman == null)
            } catch (e: Exception) {
                // try another verse
            }
        }
        return null
    }

    private fun hadithText(json: String): String {
        val root = JSONObject(json)
        val obj = root.optJSONArray("hadiths")?.optJSONObject(0) ?: root
        return clean(obj.optString("text"))
    }

    private fun randomHadith(): StatusVerse? {
        for (attempt in 0 until 14) {
            try {
                val col = collections[rnd.nextInt(collections.size)]
                val n = 1 + rnd.nextInt(col.max)
                val base = "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/"
                val ar = hadithText(get("${base}ara-${col.id}/$n.json"))
                if (ar.isEmpty() || ar.length > 200) continue
                val en = hadithText(get("${base}eng-${col.id}/$n.json"))
                if (en.isEmpty() || en.length > 280) continue
                val ur = try { hadithText(get("${base}urd-${col.id}/$n.json")) } catch (e: Exception) { "" }
                val urShort = if (ur.length <= 300) ur else ""
                val urRoman = romanUrdu(urShort)
                return StatusVerse(ar, "", en, urRoman ?: urShort, "${col.name} $n", false, urduRtl = urRoman == null)
            } catch (e: Exception) {
                // try another hadith
            }
        }
        return null
    }
}
