package com.example.mydeen

import android.Manifest
import android.content.pm.PackageManager
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import coil.compose.AsyncImage

private data class ActivityItem(val title: String, val kind: String = "check")
private data class Group(val title: String, val items: List<ActivityItem>)
private val groups = listOf(
    Group("Qaza & Tasbeeh", listOf(ActivityItem("Umari Qaza"), ActivityItem("3 Tasbeeh — first daily entry"), ActivityItem("3 Tasbeeh — second daily entry"), ActivityItem("Durood — 1,000 times", "counter"))),
    Group("Daily Namaz", listOf(ActivityItem("Fajr"), ActivityItem("Dhuhr"), ActivityItem("Asr"), ActivityItem("Maghrib"), ActivityItem("Isha"))),
    Group("Salah & Sunnah", listOf(ActivityItem("Sunnat-e-Muakkadah"), ActivityItem("Tahajjud"), ActivityItem("Ishraq"), ActivityItem("Chasht"), ActivityItem("Awwabin"))),
    Group("Quran & Learning", listOf(ActivityItem("Quran — 1 Juz"), ActivityItem("Quran Taleem"), ActivityItem("Ghar ki Taleem"))),
    Group("Character & Community", listOf(ActivityItem("Ghar Ghar Mulakhatan", "visits")))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminder.createChannel(this)
        Reminder.scheduleAll(this)
        setContent { MyDeenScreen() }
    }
}


@Composable
private fun DeenTimerCard(context: Context, prefs: android.content.SharedPreferences, day: String) {
    val targetMillis = 2L * 60L * 60L * 1000L + 30L * 60L * 1000L
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val totalKey = "deen_timer_total_$day"
    val startKey = "deen_timer_started_at_$day"

    var accumulated by remember(day) {
        mutableLongStateOf(prefs.getLong(totalKey, 0L).coerceAtLeast(0L))
    }
    var startedAt by remember(day) {
        mutableLongStateOf(prefs.getLong(startKey, 0L).coerceAtLeast(0L))
    }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(startedAt, day) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val elapsed = (accumulated + if (startedAt > 0L) (now - startedAt).coerceAtLeast(0L) else 0L)
    val progress = (elapsed.toFloat() / targetMillis.toFloat()).coerceIn(0f, 1f)

    // Stop automatically at 2.5 hours and notify once for this calendar day.
    LaunchedEffect(elapsed, startedAt, day) {
        if (startedAt > 0L && elapsed >= targetMillis) {
            accumulated = targetMillis
            startedAt = 0L
            now = System.currentTimeMillis()
            prefs.edit().putLong(totalKey, targetMillis).remove(startKey).apply()

            val notifiedKey = "deen_timer_goal_notified_$day"
            if (!prefs.getBoolean(notifiedKey, false)) {
                Reminder.createChannel(context)
                val notification = NotificationCompat.Builder(context, Reminder.CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Alhamdulillah! Daily Deen goal achieved")
                    .setContentText("You completed your 2 hours 30 minutes of Deen time today.")
                    .setStyle(NotificationCompat.BigTextStyle().bigText(
                        "Alhamdulillah! You completed your daily 2 hours 30 minutes of Deen time. Keep going tomorrow."
                    ))
                    .setAutoCancel(true)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .build()

                val permissionGranted = Build.VERSION.SDK_INT < 33 ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                if (permissionGranted) {
                    NotificationManagerCompat.from(context).notify(2501, notification)
                }
                prefs.edit().putBoolean(notifiedKey, true).apply()
            }
        }
    }

    fun formatDuration(ms: Long): String {
        val seconds = ms / 1000L
        val hours = seconds / 3600L
        val minutes = (seconds % 3600L) / 60L
        val remainingSeconds = seconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, remainingSeconds)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Daily Deen Timer", style = MaterialTheme.typography.titleLarge)
            Text("Your daily goal: 2 hours 30 minutes")
            Text(
                formatDuration(elapsed),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            Text(
                if (elapsed >= targetMillis) "Daily goal achieved — Alhamdulillah!"
                else "${formatDuration(targetMillis - elapsed)} remaining to reach your goal",
                style = MaterialTheme.typography.bodyMedium
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    enabled = elapsed < targetMillis || startedAt > 0L,
                    onClick = {
                        if (startedAt == 0L && elapsed < targetMillis) {
                            if (Build.VERSION.SDK_INT >= 33 &&
                                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                            ) {
                                notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            val start = System.currentTimeMillis()
                            startedAt = start
                            now = start
                            prefs.edit().putLong(startKey, start).apply()
                        } else {
                            val updated = accumulated + (System.currentTimeMillis() - startedAt).coerceAtLeast(0L)
                            accumulated = updated
                            startedAt = 0L
                            now = System.currentTimeMillis()
                            prefs.edit().putLong(totalKey, updated).remove(startKey).apply()
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (elapsed >= targetMillis) "Goal completed" else if (startedAt > 0L) "Pause" else "Start")
                }
                OutlinedButton(
                    onClick = {
                        accumulated = 0L
                        startedAt = 0L
                        now = System.currentTimeMillis()
                        prefs.edit().putLong(totalKey, 0L).remove(startKey).remove("deen_timer_goal_notified_$day").apply()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Reset today")
                }
            }
            Text(
                "Time is saved on this phone. The timer continues while the app is closed if you leave it running. It stops automatically at 2 hours 30 minutes and sends a congratulation notification (if notifications are allowed). It starts a fresh count each day.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}


@Composable
private fun DeenInsightsCard(prefs: android.content.SharedPreferences) {
    val goalMillis = 2L * 60L * 60L * 1000L + 30L * 60L * 1000L
    var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            clock = System.currentTimeMillis()
            delay(60_000L)
        }
    }

    val today = LocalDate.now()
    fun key(date: LocalDate) = "deen_timer_total_${date.format(DateTimeFormatter.ISO_LOCAL_DATE)}"
    fun completed(date: LocalDate): Boolean = prefs.getLong(key(date), 0L) >= goalMillis

    val weekDates = (6 downTo 0).map { today.minusDays(it.toLong()) }
    val weekValues = weekDates.map { date ->
        val raw = prefs.getLong(key(date), 0L)
        val running = if (date == today) {
            val started = prefs.getLong("deen_timer_started_at_${date.format(DateTimeFormatter.ISO_LOCAL_DATE)}", 0L)
            if (started > 0L) (clock - started).coerceAtLeast(0L) else 0L
        } else 0L
        (raw + running).coerceAtMost(goalMillis)
    }
    val monthStart = today.withDayOfMonth(1)
    val monthDates = (0 until today.dayOfMonth).map { monthStart.plusDays(it.toLong()) }
    val monthTotal = monthDates.sumOf { date ->
        val raw = prefs.getLong(key(date), 0L)
        val running = if (date == today) {
            val started = prefs.getLong("deen_timer_started_at_${date.format(DateTimeFormatter.ISO_LOCAL_DATE)}", 0L)
            if (started > 0L) (clock - started).coerceAtLeast(0L) else 0L
        } else 0L
        raw + running
    }
    var streak = 0
    var cursor = today
    while (completed(cursor)) {
        streak++
        cursor = cursor.minusDays(1)
    }
    val weekGoalDays = weekValues.count { it >= goalMillis }
    fun hours(ms: Long) = String.format(Locale.US, "%.1f h", ms / 3_600_000f)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Your Deen dashboard", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🔥 Streak", style = MaterialTheme.typography.labelLarge)
                        Text("$streak days", style = MaterialTheme.typography.headlineSmall)
                        Text("Daily goal completed", style = MaterialTheme.typography.bodySmall)
                    }
                }
                Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("This month", style = MaterialTheme.typography.labelLarge)
                        Text(hours(monthTotal), style = MaterialTheme.typography.headlineSmall)
                        Text("Deen time so far", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            Text("Last 7 days", style = MaterialTheme.typography.titleMedium)
            Row(
                modifier = Modifier.fillMaxWidth().height(112.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = androidx.compose.ui.Alignment.Bottom
            ) {
                weekDates.forEachIndexed { index, date ->
                    val value = weekValues[index]
                    Column(
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        verticalArrangement = Arrangement.Bottom,
                        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                    ) {
                        Text(hours(value), style = MaterialTheme.typography.labelSmall)
                        Box(
                            modifier = Modifier.fillMaxWidth(0.72f)
                                .height((76f * (value.toFloat() / goalMillis.toFloat()).coerceIn(0.04f, 1f)).dp)
                                .clip(androidx.compose.foundation.shape.RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                .background(if (value >= goalMillis) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                        )
                        Text(date.dayOfWeek.name.take(1), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Text("Weekly goal: $weekGoalDays of 7 days completed", style = MaterialTheme.typography.bodyMedium)
            LinearProgressIndicator(
                progress = { weekGoalDays / 7f },
                modifier = Modifier.fillMaxWidth()
            )
            Text("Monthly Deen time: ${hours(monthTotal)}", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun HadithCard() {
    val hadiths = listOf(
        "The most beloved deeds to Allah are those that are most consistent, even if they are small." to "Sahih al-Bukhari 6464",
        "Whoever believes in Allah and the Last Day should speak good or remain silent." to "Sahih al-Bukhari 6018",
        "Cleanliness is half of faith." to "Sahih Muslim 223"
    )
    val index = (LocalDate.now().dayOfYear - 1) % hadiths.size
    val (quote, source) = hadiths[index]
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Hadith of the day", style = MaterialTheme.typography.titleLarge)
            Text("“$quote”", style = MaterialTheme.typography.bodyLarge)
            Text(source, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
        }
    }
}

private suspend fun loadPrayerTimes(city: String): Map<String, String> = withContext(Dispatchers.IO) {
    val encoded = URLEncoder.encode(city.trim(), "UTF-8")
    val connection = (URL("https://api.aladhan.com/v1/timingsByCity?city=$encoded&country=India&method=1").openConnection() as HttpURLConnection)
    try {
        connection.connectTimeout = 12000
        connection.readTimeout = 12000
        connection.requestMethod = "GET"
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val timings = JSONObject(body).getJSONObject("data").getJSONObject("timings")
        listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha").associateWith { name ->
            timings.getString(name).substringBefore(" ")
        }
    } finally {
        connection.disconnect()
    }
}

@Composable
private fun PrayerTimesCard(prefs: android.content.SharedPreferences) {
    var city by remember { mutableStateOf(prefs.getString("prayer_city", "Nellore") ?: "Nellore") }
    var timings by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun refreshTimes() {
        if (city.isBlank()) { error = "Enter your city name."; return }
        scope.launch {
            loading = true
            error = null
            try {
                timings = loadPrayerTimes(city)
                prefs.edit().putString("prayer_city", city.trim()).apply()
            } catch (_: Exception) {
                error = "Couldn't load prayer times. Check your internet and city name, then try again."
            } finally { loading = false }
        }
    }
    LaunchedEffect(Unit) { refreshTimes() }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Namaz timings", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = city, onValueChange = { city = it }, label = { Text("City in India") },
                singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = { refreshTimes() }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                Text(if (loading) "Loading timings…" else "Update prayer timings")
            }
            if (timings.isNotEmpty()) {
                listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha").forEach { name ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(name, style = MaterialTheme.typography.bodyLarge)
                        Text(timings[name] ?: "—", style = MaterialTheme.typography.titleMedium)
                    }
                }
                Text("Calculation: University of Islamic Sciences, Karachi (method 1). Verify local mosque timings where they differ.", style = MaterialTheme.typography.bodySmall)
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

@Composable
private fun ProfileCard(
    profileUri: String?,
    onChoosePhoto: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            if (profileUri != null) {
                AsyncImage(model = profileUri, contentDescription = "Profile photo", modifier = Modifier.size(68.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.size(68.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = androidx.compose.ui.Alignment.Center) {
                    Text("م", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("My Deen profile", style = MaterialTheme.typography.titleMedium)
                Text("Add or change your profile photo", style = MaterialTheme.typography.bodySmall)
            }
            OutlinedButton(onClick = onChoosePhoto) { Text(if (profileUri == null) "Add photo" else "Change") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MyDeenScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("my_deen", Context.MODE_PRIVATE) }
    var profileUri by remember { mutableStateOf(prefs.getString("profile_photo_uri", null)) }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            profileUri = uri.toString()
            prefs.edit().putString("profile_photo_uri", profileUri).apply()
        }
    }
    val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    var refresh by remember { mutableIntStateOf(0) }
    var reviewReason by remember { mutableStateOf(prefs.getString("review_reason_$day", "") ?: "") }
    var reviewPlan by remember { mutableStateOf(prefs.getString("review_plan_$day", "") ?: "") }
    var morning by remember { mutableStateOf(String.format(Locale.US, "%02d:%02d", prefs.getInt("morning_hour", 6), prefs.getInt("morning_minute", 0))) }
    var night by remember { mutableStateOf(String.format(Locale.US, "%02d:%02d", prefs.getInt("night_hour", 21), prefs.getInt("night_minute", 30))) }
    var qazaTotal by remember { mutableIntStateOf(prefs.getInt("qaza_total", 0)) }
    var qazaToday by remember { mutableIntStateOf(0) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val refreshSnapshot = refresh // Observe checklist changes so the overall progress recomputes.
    val total = groups.sumOf { it.items.size }
    val done = groups.sumOf { g -> g.items.count { item ->
        when (item.kind) {
            "counter" -> prefs.getInt("$day:${item.title}", 0) >= 1000
            "visits" -> prefs.getInt("$day:${item.title}", 0) > 0
            else -> prefs.getBoolean("$day:${item.title}", false)
        }
    } }
    val percent = if (total == 0) 0 else done * 100 / total
    Scaffold(topBar = { TopAppBar(title = { Text("My Deen", style = MaterialTheme.typography.titleLarge) }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
            item { ProfileCard(profileUri = profileUri, onChoosePhoto = { photoPicker.launch(arrayOf("image/*")) }) }
            item { PrayerTimesCard(prefs = prefs) }
            item { HadithCard() }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", style = MaterialTheme.typography.titleLarge)
                        Text("A little progress, every day", style = MaterialTheme.typography.titleMedium)
                        Text("${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}", style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(8.dp)); Text("$percent%", style = MaterialTheme.typography.headlineLarge)
                        LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
                        Text("$done of $total activities completed")
                    }
                }
            }
            item {
                DeenTimerCard(context = context, prefs = prefs, day = day)
            }
            item {
                DeenInsightsCard(prefs = prefs)
            }
            groups.forEach { group ->
                item { Text(group.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
                items(group.items, key = { it.title }) { item ->
                    val valueKey = "$day:${item.title}"
                    var checked by remember(day, item.title) { mutableStateOf(prefs.getBoolean(valueKey, false)) }
                    var amount by remember(day, item.title) { mutableIntStateOf(prefs.getInt(valueKey, 0)) }
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.title, modifier = Modifier.weight(1f).padding(top = 10.dp))
                            if (item.kind == "check") {
                                Checkbox(checked = checked, onCheckedChange = { checked = it; prefs.edit().putBoolean(valueKey, it).apply(); refresh++ })
                            } else {
                                OutlinedTextField(value = amount.toString(), onValueChange = { v -> amount = v.toIntOrNull()?.coerceAtLeast(0) ?: 0; prefs.edit().putInt(valueKey, amount).apply(); refresh++ }, modifier = Modifier.width(100.dp), singleLine = true, label = { Text(if (item.kind == "visits") "Visits" else "Count") })
                            }
                        }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Nightly Muhasabah", style = MaterialTheme.typography.titleLarge)
                        Text("What made today's activities difficult?")
                        OutlinedTextField(reviewReason, { reviewReason = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        Text("What will I improve tomorrow?")
                        OutlinedTextField(reviewPlan, { reviewPlan = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                        Button(onClick = { prefs.edit().putString("review_reason_$day", reviewReason).putString("review_plan_$day", reviewPlan).apply() }, modifier = Modifier.fillMaxWidth()) { Text("Save nightly review") }
                        Text("Today: $done / $total activities ($percent%)")
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Umari Qaza counter", style = MaterialTheme.typography.titleLarge)
                        Text("Total completed so far: $qazaTotal")
                        OutlinedTextField(qazaToday.toString(), { qazaToday = it.toIntOrNull()?.coerceAtLeast(0) ?: 0 }, label = { Text("Qaza completed today") }, singleLine = true)
                        Button(onClick = { qazaTotal += qazaToday; qazaToday = 0; prefs.edit().putInt("qaza_total", qazaTotal).apply() }, modifier = Modifier.fillMaxWidth()) { Text("Add today's Qaza to total") }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Daily reminders", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(morning, { morning = it }, label = { Text("Morning time (HH:mm)") }, singleLine = true)
                        OutlinedTextField(night, { night = it }, label = { Text("Nightly review time (HH:mm)") }, singleLine = true)
                        Button(onClick = {
                            fun parse(s: String, defaultH: Int, defaultM: Int): Pair<Int, Int> {
                                val p = s.split(":"); val h = p.getOrNull(0)?.toIntOrNull(); val m = p.getOrNull(1)?.toIntOrNull()
                                return if (h != null && m != null && h in 0..23 && m in 0..59) h to m else defaultH to defaultM
                            }
                            val a = parse(morning, 6, 0); val b = parse(night, 21, 30)
                            prefs.edit().putInt("morning_hour", a.first).putInt("morning_minute", a.second).putInt("night_hour", b.first).putInt("night_minute", b.second).apply()
                            Reminder.scheduleAll(context)
                            if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                            if (Build.VERSION.SDK_INT >= 31) {
                                val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                                if (!alarm.canScheduleExactAlarms()) context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Save times & enable reminders") }
                        Text("Android may ask you to allow notifications and exact alarms. Allow both for the most punctual reminders. Some battery-saving settings can still delay them.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            item { Text("Your checklist and profile photo are saved on this phone. Prayer timings are fetched for the city you enter.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
