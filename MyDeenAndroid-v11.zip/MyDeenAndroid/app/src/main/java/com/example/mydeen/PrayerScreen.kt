package com.example.mydeen

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs

@Composable
fun PrayerScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var lat by remember { mutableStateOf(prefs.getString("loc_lat", null)?.toDoubleOrNull()) }
    var lon by remember { mutableStateOf(prefs.getString("loc_lon", null)?.toDoubleOrNull()) }
    var method by remember { mutableIntStateOf(prefs.getInt("pt_method", 0)) }
    var hanafi by remember { mutableStateOf(prefs.getBoolean("pt_hanafi", true)) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(30000L)
            now = System.currentTimeMillis()
        }
    }

    fun onLocation(loc: Location?) {
        loading = false
        if (loc != null) {
            lat = loc.latitude
            lon = loc.longitude
            prefs.edit().putString("loc_lat", loc.latitude.toString()).putString("loc_lon", loc.longitude.toString()).apply()
            status = "Location updated."
        } else {
            status = "Couldn’t get your location. Turn on Location (GPS) in your phone settings and tap the button again."
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) {
            loading = true
            status = "Finding your location…"
            LocationHelper.fetch(context, true) { loc -> onLocation(loc) }
        } else {
            status = "Location permission was denied. Allow it for My Deeni Tracker in your phone’s app settings to get prayer times for where you are."
        }
    }

    fun locate() {
        val granted = context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            return
        }
        loading = true
        status = "Finding your location…"
        LocationHelper.fetch(context, true) { loc -> onLocation(loc) }
    }

    val la = lat
    val lo = lon
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (la != null && lo != null) {
                    val ns = if (la >= 0) "N" else "S"
                    val ew = if (lo >= 0) "E" else "W"
                    Text("Your location: " + String.format(Locale.US, "%.2f°%s, %.2f°%s", abs(la), ns, abs(lo), ew), style = MaterialTheme.typography.titleMedium)
                } else {
                    Text("Prayer times are worked out on your phone from where you are. Allow location to begin.", style = MaterialTheme.typography.bodyLarge)
                }
                Button(onClick = { locate() }, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                    Text(if (la != null) "Update my location" else "Use my location")
                }
                if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (la != null && lo != null) {
            val cal = Calendar.getInstance().apply { timeInMillis = now }
            val dayKey = Store.dayKey(cal)
            val times = remember(la, lo, method, hanafi, dayKey) { PrayerCalc.compute(cal, la, lo, method, hanafi) }
            val dayStart = (cal.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis

            var nextName = ""
            var nextMs = 0L
            for (t in times) {
                val h = t.hours ?: continue
                if (t.name == "Sunrise") continue
                val ms = dayStart + (h * 3600000.0).toLong()
                if (ms > now) { nextName = t.name; nextMs = ms; break }
            }
            if (nextName.isEmpty()) {
                val f = times.firstOrNull { it.name == "Fajr" }?.hours
                if (f != null) { nextName = "Fajr"; nextMs = dayStart + (f * 3600000.0).toLong() + 86400000L }
            }
            if (nextName.isNotEmpty()) {
                val mins = ((nextMs - now) / 60000L).toInt()
                val inText = if (mins >= 60) "${mins / 60} h ${mins % 60} min" else "$mins min"
                DeenCard(color = MaterialTheme.colorScheme.primaryContainer) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Next prayer", style = MaterialTheme.typography.labelLarge)
                        Text("$nextName in $inText", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }

            times.forEach { t ->
                val isNext = t.name == nextName
                DeenCard(color = if (isNext) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(t.name, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal)
                        Text(PrayerCalc.format(t.hours), style = MaterialTheme.typography.titleMedium, fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }

            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Calculation method", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PrayerCalc.methodNames.forEachIndexed { i, name ->
                            FilterChip(
                                selected = method == i,
                                onClick = { method = i; prefs.edit().putInt("pt_method", i).apply() },
                                label = { Text(name) }
                            )
                        }
                    }
                    Text(PrayerCalc.methodNotes[method.coerceIn(0, 3)], style = MaterialTheme.typography.bodySmall)
                    Text("Asr", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = hanafi, onClick = { hanafi = true; prefs.edit().putBoolean("pt_hanafi", true).apply() }, label = { Text("Hanafi") })
                        FilterChip(selected = !hanafi, onClick = { hanafi = false; prefs.edit().putBoolean("pt_hanafi", false).apply() }, label = { Text("Standard") })
                    }
                    Text("Times are calculated, not downloaded, so they work offline. They can differ from your local masjid by a few minutes, so follow your masjid’s timetable if it differs.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
