package com.example.mydeen

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

/** hours = local clock time in hours (e.g. 13.5 = 1:30 PM), or null if the sun never reaches that angle. */
data class PrayerTime(val name: String, val hours: Double?)

/** Offline prayer-time calculation (standard solar-angle method). */
object PrayerCalc {
    val methodNames = listOf("Karachi", "Muslim World League", "ISNA", "Egyptian")
    val methodNotes = listOf("Fajr 18°, Isha 18°", "Fajr 18°, Isha 17°", "Fajr 15°, Isha 15°", "Fajr 19.5°, Isha 17.5°")
    private val fajrAngle = doubleArrayOf(18.0, 18.0, 15.0, 19.5)
    private val ishaAngle = doubleArrayOf(18.0, 17.0, 15.0, 17.5)

    fun compute(cal: Calendar, lat: Double, lon: Double, method: Int, hanafi: Boolean): List<PrayerTime> {
        val m = method.coerceIn(0, 3)
        val tz = TimeZone.getDefault().getOffset(cal.timeInMillis) / 3600000.0
        val jd = julian(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)) - lon / 360.0
        val adj = tz - lon / 15.0
        fun shift(v: Double?): Double? = if (v == null) null else v + adj
        return listOf(
            PrayerTime("Fajr", shift(angleTime(jd, lat, fajrAngle[m], 5.0 / 24.0, true))),
            PrayerTime("Sunrise", shift(angleTime(jd, lat, 0.833, 6.0 / 24.0, true))),
            PrayerTime("Dhuhr", shift(midDay(jd, 12.0 / 24.0))),
            PrayerTime("Asr", shift(asrTime(jd, lat, if (hanafi) 2.0 else 1.0, 13.0 / 24.0))),
            PrayerTime("Maghrib", shift(angleTime(jd, lat, 0.833, 18.0 / 24.0, false))),
            PrayerTime("Isha", shift(angleTime(jd, lat, ishaAngle[m], 18.0 / 24.0, false)))
        )
    }

    fun format(h: Double?): String {
        if (h == null) return "--:--"
        val total = Math.round(fixHour(h) * 60.0).toInt() % 1440
        val hh = total / 60
        val mm = total % 60
        val ampm = if (hh >= 12) "PM" else "AM"
        val h12 = if (hh % 12 == 0) 12 else hh % 12
        return String.format(Locale.US, "%d:%02d %s", h12, mm, ampm)
    }

    private fun sinD(d: Double): Double = sin(Math.toRadians(d))
    private fun cosD(d: Double): Double = cos(Math.toRadians(d))
    private fun tanD(d: Double): Double = tan(Math.toRadians(d))
    private fun fixAngle(a: Double): Double = a - 360.0 * floor(a / 360.0)
    private fun fixHour(h: Double): Double = h - 24.0 * floor(h / 24.0)

    private fun julian(year: Int, month: Int, day: Int): Double {
        var y = year
        var mo = month
        if (mo <= 2) { y -= 1; mo += 12 }
        val a = floor(y / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (mo + 1)) + day + b - 1524.5
    }

    /** Returns [declination in degrees, equation of time in hours]. */
    private fun sun(jd: Double, t: Double): DoubleArray {
        val d = jd + t - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sinD(g) + 0.020 * sinD(2.0 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(Math.toDegrees(atan2(cosD(e) * sinD(l), cosD(l))) / 15.0)
        val eqt = q / 15.0 - ra
        val decl = Math.toDegrees(asin(sinD(e) * sinD(l)))
        return doubleArrayOf(decl, eqt)
    }

    private fun midDay(jd: Double, t: Double): Double = fixHour(12.0 - sun(jd, t)[1])

    private fun angleTime(jd: Double, lat: Double, angle: Double, t: Double, before: Boolean): Double? {
        val decl = sun(jd, t)[0]
        val x = (-sinD(angle) - sinD(decl) * sinD(lat)) / (cosD(decl) * cosD(lat))
        if (x.isNaN() || x < -1.0 || x > 1.0) return null
        val h = Math.toDegrees(acos(x)) / 15.0
        val noon = midDay(jd, t)
        return if (before) noon - h else noon + h
    }

    private fun asrTime(jd: Double, lat: Double, factor: Double, t: Double): Double? {
        val decl = sun(jd, t)[0]
        val angle = -Math.toDegrees(atan(1.0 / (factor + tanD(abs(lat - decl)))))
        return angleTime(jd, lat, angle, t, false)
    }
}
