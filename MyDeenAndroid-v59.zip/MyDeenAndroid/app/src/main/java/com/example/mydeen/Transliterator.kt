package com.example.mydeen

/**
 * Turns Arabic text that has its vowel marks (tashkeel) into Roman English letters,
 * e.g. "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ" -> "Innamaa al-a'maalu bin-niyyaati".
 * Works for fully vowelled text only; [coverage] tells how much of the text has vowel marks,
 * so callers can skip text that would come out wrong.
 */
object Transliterator {
    private val cons = mapOf(
        'ب' to "b", 'ت' to "t", 'ث' to "th", 'ج' to "j", 'ح' to "h", 'خ' to "kh", 'د' to "d", 'ذ' to "dh",
        'ر' to "r", 'ز' to "z", 'س' to "s", 'ش' to "sh", 'ص' to "s", 'ض' to "d", 'ط' to "t", 'ظ' to "z",
        'ع' to "'", 'غ' to "gh", 'ف' to "f", 'ق' to "q", 'ك' to "k", 'ک' to "k", 'ل' to "l", 'م' to "m",
        'ن' to "n", 'ه' to "h", 'و' to "w", 'ي' to "y", 'ی' to "y",
        'ء' to "'", 'أ' to "'", 'إ' to "'", 'ؤ' to "'", 'ئ' to "'"
    )
    private const val SUN = "تثدذرزسشصضطظلن"
    private const val HAMZA = "ءأإؤئ"

    private class U(var ch: Char) {
        var f = false; var d = false; var k = false
        var sh = false; var sk = false; var dag = false; var madd = false
        var tan: Char = ' '
        fun vowel() = f || d || k || tan != ' '
    }

    private fun parse(word: String): MutableList<U> {
        val us = mutableListOf<U>()
        for (c0 in word) {
            val c = if (c0 == 'ٱ') 'ا' else c0
            val last = us.lastOrNull()
            when (c) {
                '\u064E' -> last?.f = true
                '\u064F' -> last?.d = true
                '\u0650' -> last?.k = true
                '\u0651' -> last?.sh = true
                '\u0652' -> last?.sk = true
                '\u064B' -> last?.tan = 'f'
                '\u064C' -> last?.tan = 'd'
                '\u064D' -> last?.tan = 'k'
                '\u0670' -> last?.dag = true
                'آ' -> { val u = U('ا'); u.madd = true; us.add(u) }
                else -> if ((c in '\u0621'..'\u064A') || c == 'ک' || c == 'ی') us.add(U(c))
            }
        }
        return us
    }

    private fun article(us: List<U>, i: Int): Int? {   // returns the lam index, or null
        val n = us.size
        if (us[i].ch == 'ا' && i <= 1 && i + 2 < n && us[i + 1].ch == 'ل' &&
            !us[i + 1].vowel() && !us[i + 1].sh && !us[i].vowel()) return i + 1
        if (i == 1 && us[0].ch == 'ل' && us[0].k && us[1].ch == 'ل' &&
            !us[1].vowel() && !us[1].sh && n > 2) return 1
        return null
    }

    private fun vstr(u: U): String = when {
        u.tan == 'f' -> "an"
        u.tan == 'd' -> "un"
        u.tan == 'k' -> "in"
        u.f -> "a"
        u.d -> "u"
        u.k -> "i"
        else -> ""
    }

    private fun fv(u: U): String = if (u.d) "u" else if (u.k) "i" else if (u.f) "a" else ""

    private fun word(w: String): String {
        val us = parse(w)
        if (us.isEmpty()) return ""
        val base = us.map { it.ch }.joinToString("")
        if (base == "الله") return "Allaah" + fv(us.last())
        if (base == "اللهم") return "Allaahumma"
        if (base == "لله") return "lillaah" + fv(us.last())
        if (base.length == 4 && (base[0] == 'و' || base[0] == 'ف') && base.substring(1) == "لله")
            return cons[base[0]] + vstr(us[0]) + "lillaah" + fv(us.last())
        if (base.length == 5 && base[0] in "وفبكت" && base.substring(1) == "الله")
            return cons[base[0]] + vstr(us[0]) + "llaah" + fv(us.last())

        val out = StringBuilder()
        val n = us.size
        val supp = HashSet<Int>()
        val noHamza = HashSet<Int>()
        var i = 0
        while (i < n) {
            val u = us[i]
            val c = u.ch
            val lam = article(us, i)
            if (lam != null) {
                val hasAlif = c == 'ا'
                val sun = us[lam + 1]
                val pre = if (hasAlif && i == 0) "a" else ""
                if (sun.sh && SUN.indexOf(sun.ch) >= 0) {
                    out.append(pre).append(cons[sun.ch] ?: "").append("-")
                    supp.add(lam + 1)
                } else {
                    out.append(pre).append("l-")
                    noHamza.add(lam + 1)
                }
                i = lam + 1
                continue
            }
            if (c == 'ا' && u.madd) {
                out.append(if (i == 0) "aa" else "'aa"); i++; continue
            }
            if (c == 'ا') {
                if (i == 0) {
                    if (u.vowel()) out.append(vstr(u))
                    else if (i + 1 < n && !us[i + 1].vowel()) out.append("i")
                }
                i++; continue
            }
            if (c == 'ى') { out.append("aa"); i++; continue }

            val r: String = when {
                HAMZA.indexOf(c) >= 0 -> if (i == 0 || noHamza.contains(i)) "" else "'"
                c == 'ة' -> if (u.vowel()) "t" else "h"
                else -> cons[c] ?: ""
            }
            val s = if (u.sh && !supp.contains(i)) r + r else r
            var v = vstr(u)
            var consumed = 0
            val nxt = if (i + 1 < n) us[i + 1] else null
            if (u.dag) {
                v = "aa"
            } else if (nxt != null) {
                val nart = article(us, i + 1) != null
                val nv = nxt.vowel() || nxt.sh
                val wasl = i + 2 < n && us[i + 2].sk && !us[i + 2].vowel() && nxt.ch == 'ا'
                if (u.f && u.tan == ' ' && nxt.ch == 'ا' && !nv && !nart && !wasl) { v = "aa"; consumed = 1 }
                else if (u.f && u.tan == ' ' && nxt.ch == 'ى' && !nv) { v = "aa"; consumed = 1 }
                else if (u.d && u.tan == ' ' && nxt.ch == 'و' && !nv) { v = "oo"; consumed = 1 }
                else if (u.k && u.tan == ' ' && nxt.ch == 'ي' && !nv) { v = "ee"; consumed = 1 }
                else if (u.f && u.tan == ' ' && nxt.ch == 'و' && !nv) { v = "aw"; consumed = 1 }
                else if (u.f && u.tan == ' ' && nxt.ch == 'ي' && !nv) { v = "ay"; consumed = 1 }
                else if (u.tan == 'f' && nxt.ch == 'ا' && !nv) { consumed = 1 }
            }
            out.append(s).append(v)
            i += 1 + consumed
            // silent alif written after the plural "oo" ending (كَفَرُوا)
            if (consumed == 1 && v == "oo" && i == n - 1 && us[i].ch == 'ا' && !us[i].vowel()) i++
        }
        return out.toString()
    }

    /** Roman English for [text], or "" when nothing could be made. */
    fun toRoman(text: String): String {
        val words = text.trim().split(Regex("\\s+")).map {
            if (it == "ﷺ") "sallallaahu 'alayhi wa sallam" else word(it)
        }.filter { it.isNotEmpty() }
        val r = words.joinToString(" ")
        return if (r.isEmpty()) r else r.substring(0, 1).uppercase() + r.substring(1)
    }

    /** Share of the real letters that carry a vowel mark (0.0 – 1.0). Low = text is not vowelled. */
    fun coverage(text: String): Double {
        var letters = 0
        var voc = 0
        for (w in text.trim().split(Regex("\\s+"))) {
            for (u in parse(w)) {
                if ("اوىيی".indexOf(u.ch) >= 0) continue
                letters++
                if (u.vowel() || u.sh || u.sk) voc++
            }
        }
        return if (letters == 0) 0.0 else voc.toDouble() / letters
    }
}
