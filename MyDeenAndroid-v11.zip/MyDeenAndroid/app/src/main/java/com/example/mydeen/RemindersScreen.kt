package com.example.mydeen

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.provider.OpenableColumns
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

@Composable
fun RemindersScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var version by remember { mutableIntStateOf(0) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    var soundChoice by remember { mutableIntStateOf(AlarmSound.selected(context)) }
    var customName by remember { mutableStateOf(AlarmSound.customName(context)) }
    var soundMessage by remember { mutableStateOf("") }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            var name = "My sound"
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && col >= 0) name = c.getString(col) ?: name
                }
            } catch (e: Exception) { }
            if (AlarmSound.saveCustom(context, uri, name)) {
                soundChoice = AlarmSound.CUSTOM
                customName = name
                soundMessage = "Using “$name” for your alarms."
            } else {
                soundMessage = "Couldn’t read that audio file. Try another one."
            }
        }
    }

    LaunchedEffect(Unit) {
        AlarmService.createChannel(context)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Alarm sound", style = MaterialTheme.typography.titleLarge)
                    Text("Reminders ring like an alarm, with a full-screen Stop / Snooze page, even when your phone is locked.")
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AlarmSound.names.forEachIndexed { i, name ->
                            FilterChip(
                                selected = soundChoice == i,
                                enabled = i != AlarmSound.CUSTOM || AlarmSound.hasCustom(context),
                                onClick = { soundChoice = i; prefs.edit().putInt("alarm_sound", i).apply() },
                                label = { Text(name) }
                            )
                        }
                    }
                    if (AlarmSound.hasCustom(context) && customName.isNotEmpty()) Text("Your sound: $customName", style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = { audioPicker.launch("audio/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text("Choose my own sound (e.g. Adhan)")
                    }
                    Button(
                        onClick = { AlarmService.ring(context, 899, "Test alarm", "This is how your reminders will ring.") },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Test the alarm") }
                    if (soundMessage.isNotEmpty()) Text(soundMessage, style = MaterialTheme.typography.bodySmall)
                    Text("Your own sound plays once, up to 90 seconds. The built-in tones repeat until you stop them. The alarm uses your phone’s alarm volume.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Task reminders", style = MaterialTheme.typography.titleLarge)
                    Text("Switch on a reminder for any task and pick its time. A reminder rings every day, and is skipped if you have already finished that task today.")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                Reminder.items.forEach { Reminder.update(context, it, true, Reminder.hourOf(prefs, it), Reminder.minuteOf(prefs, it)) }
                                version++
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Turn all on") }
                        OutlinedButton(
                            onClick = {
                                Reminder.items.forEach { Reminder.update(context, it, false, Reminder.hourOf(prefs, it), Reminder.minuteOf(prefs, it)) }
                                version++
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Turn all off") }
                    }
                    Text("Allow notifications when Android asks. Battery-saver modes on some phones can delay reminders; set My Deeni Tracker to “Unrestricted” battery use if they arrive late.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(Reminder.items, key = { it.id }) { item ->
            val on = remember(version) { Reminder.isOn(prefs, item) }
            val h = remember(version) { Reminder.hourOf(prefs, item) }
            val m = remember(version) { Reminder.minuteOf(prefs, item) }
            DeenCard {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(item.title, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, hh, mm ->
                            Reminder.update(context, item, true, hh, mm)
                            version++
                        }, h, m, false).show()
                    }) { Text(Reminder.timeText(h, m)) }
                    Switch(
                        checked = on,
                        onCheckedChange = { v ->
                            Reminder.update(context, item, v, h, m)
                            version++
                        },
                        modifier = Modifier.semantics { contentDescription = "Reminder for " + item.title }
                    )
                }
            }
        }
    }
}
