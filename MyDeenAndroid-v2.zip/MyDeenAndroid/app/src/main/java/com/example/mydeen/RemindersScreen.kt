package com.example.mydeen

import android.Manifest
import android.app.TimePickerDialog
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

@Composable
fun RemindersScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var version by remember { mutableIntStateOf(0) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Task reminders", style = MaterialTheme.typography.titleLarge)
                    Text("Switch on a reminder for any task and pick its time. A reminder rings every day, and is skipped if you have already finished that task today.")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                Reminder.items.forEach { Reminder.update(context, it, true, Reminder.hourOf(prefs, it), Reminder.minuteOf(prefs, it)) }
                                version++
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Turn all on") }
                        OutlinedButton(
                            onClick = {
                                Reminder.items.forEach { Reminder.update(context, it, false, Reminder.hourOf(prefs, it), Reminder.minuteOf(prefs, it)) }
                                version++
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Turn all off") }
                    }
                    Text("Allow notifications when Android asks. Battery-saver modes on some phones can delay reminders; set My Deen to “Unrestricted” battery use if they arrive late.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(Reminder.items, key = { it.id }) { item ->
            val on = remember(version) { Reminder.isOn(prefs, item) }
            val h = remember(version) { Reminder.hourOf(prefs, item) }
            val m = remember(version) { Reminder.minuteOf(prefs, item) }
            DeenCard {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(item.title, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = {
                        TimePickerDialog(context, { _, hh, mm ->
                            Reminder.update(context, item, true, hh, mm)
                            version++
                        }, h, m, false).show()
                    }) { Text(Reminder.timeText(h, m)) }
                    Switch(
                        checked = on,
                        onCheckedChange = { v ->
                            Reminder.update(context, item, v, h, m)
                            version++
                        },
                        modifier = Modifier.semantics { contentDescription = "Reminder for " + item.title }
                    )
                }
            }
        }
    }
}
