package com.example.mydeen

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Islamic Status maker: choose Quran or Hadees, tap Generate and get a random wallpaper with a random
 * verse (Arabic + Roman English + English + Roman Urdu). Then share it to WhatsApp Status or save it.
 */
@Composable
fun StatusScreen() {
    val context = LocalContext.current
    var filter by rememberSaveable { mutableStateOf("quran") }   // quran / hadith
    var verse by remember { mutableStateOf(StatusArt.verses.filter { it.isQuran }.random()) }
    var selectedWall by remember { mutableStateOf<OnlineWallpaper?>(null) }
    var generating by remember { mutableStateOf(false) }
    var genError by remember { mutableStateOf(false) }
    var wallLoading by remember { mutableStateOf(false) }
    var wallError by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val appContext = context.applicationContext
    val fallbackStyle = StatusArt.styles[0]   // plain background used until a wallpaper arrives (or when offline)

    fun generate(kind: String = filter) {
        if (generating) return
        generating = true
        genError = false
        scope.launch {
            // endless: a fresh random ayah / hadith from the internet, fetched while the wallpaper loads
            val onlineVerse = async(Dispatchers.IO) { runCatching { OnlineVerses.random(kind) }.getOrNull() }
            // new wallpaper: random topic and random page, so it is a fresh mix every time
            var wall: OnlineWallpaper? = null
            try {
                val topic = Wallpapers.topics.random().second
                val offset = (0 until 5).random() * Wallpapers.PAGE
                var list = withContext(Dispatchers.IO) { Wallpapers.search(topic, offset, Wallpapers.API_KEY).first }
                if (list.isEmpty() && offset > 0) {
                    list = withContext(Dispatchers.IO) { Wallpapers.search(topic, 0, Wallpapers.API_KEY).first }
                }
                if (list.isNotEmpty()) wall = list.random() else genError = true
            } catch (e: Exception) {
                genError = true
            }
            // offline (or the online source is busy): use the built-in list instead, never the same one twice in a row
            val pool = StatusArt.verses.filter { if (kind == "quran") it.isQuran else !it.isQuran }
            verse = onlineVerse.await() ?: pool.filter { it !== verse }.ifEmpty { pool }.random()
            if (wall != null) selectedWall = wall
            generating = false
        }
    }

    // first picture is made automatically when the screen opens
    LaunchedEffect(Unit) { generate() }

    val wallBmp by produceState<Bitmap?>(initialValue = null, selectedWall) {
        val w = selectedWall
        if (w == null) {
            value = null; wallLoading = false; wallError = false
        } else {
            wallLoading = true; wallError = false
            val b = withContext(Dispatchers.IO) { Wallpapers.downloadFull(w) }
            value = b; wallLoading = false; wallError = (b == null)
        }
    }
    val bmp by produceState<Bitmap?>(initialValue = null, verse, wallBmp, selectedWall) {
        if (selectedWall != null && wallBmp == null && !wallError) return@produceState   // wallpaper still downloading
        value = withContext(Dispatchers.Default) { StatusArt.render(appContext, fallbackStyle, verse, true, wallBmp) }
    }
    val busy = generating || wallLoading

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // preview, same 9:16 shape as a WhatsApp status
        Box(
            Modifier.fillMaxWidth(0.72f).aspectRatio(9f / 16f).clip(RoundedCornerShape(16.dp))
                .background(Color(fallbackStyle.top)),
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b != null) {
                Image(b.asImageBitmap(), contentDescription = "Status preview", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            if (b == null || busy) CircularProgressIndicator(color = Color.White)
        }
        if (genError || wallError) {
            Text("Couldn't load a wallpaper. Check your internet and tap Generate again.", style = MaterialTheme.typography.bodySmall)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(selected = filter == "quran", onClick = { filter = "quran"; generate("quran") }, label = { Text("📖 Quran") })
            FilterChip(selected = filter == "hadith", onClick = { filter = "hadith"; generate("hadith") }, label = { Text("📜 Hadees") })
        }

        Button(
            onClick = { generate() },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "Generating…" else "✨ Generate") }

        OutlinedButton(
            onClick = { bmp?.let { StatusShare.share(context, it, whatsApp = true) } },
            enabled = bmp != null && !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Share to WhatsApp Status") }
        OutlinedButton(
            onClick = { bmp?.let { StatusShare.share(context, it, whatsApp = false) } },
            enabled = bmp != null && !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Share in another app") }
        OutlinedButton(
            onClick = {
                bmp?.let {
                    val ok = StatusShare.saveToGallery(context, it)
                    Toast.makeText(
                        context,
                        if (ok) "Saved in Pictures/MyDeen" else "Saving needs Android 10 or newer. Use Share instead.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            enabled = bmp != null && !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save to gallery") }
        Text(
            "Pick Quran or Hadees, then tap Generate for a new wallpaper and verse. In WhatsApp choose “My status” to post it.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
