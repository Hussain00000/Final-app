package com.example.mydeen

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(openDay: String = "", onBackToToday: () -> Unit = {}, profile: android.graphics.Bitmap? = null, onProfileClick: () -> Unit = {}, onOpenAccount: () -> Unit = {}, onOpenPeople: () -> Unit = {}, onOpenStatus: () -> Unit = {}) {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    val todayKey = remember { Store.dayKey() }
    val day = if (openDay.isNotEmpty() && openDay <= todayKey) openDay else todayKey
    val isToday = day == todayKey
    var refresh by remember { mutableIntStateOf(0) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var timerRunning by remember { mutableStateOf(false) }
    var submitted by remember(day) { mutableStateOf(Store.isSubmitted(prefs, day)) }
    var showSubmit by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    var reviewReason by remember(day) { mutableStateOf(prefs.getString("review_reason_$day", "") ?: "") }
    var reviewPlan by remember(day) { mutableStateOf(prefs.getString("review_plan_$day", "") ?: "") }

    LaunchedEffect(Unit) {
        // A timer left running from an earlier day is stopped and credited to that day.
        if (Store.timerRunning(prefs) && Store.timerDay(prefs) != todayKey) Store.pauseTimer(prefs, System.currentTimeMillis())
        timerRunning = Store.timerRunning(prefs)
        now = System.currentTimeMillis()
        refresh++
    }
    LaunchedEffect(timerRunning) {
        while (timerRunning) {
            now = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val total = Tasks.all.size
    val done = remember(refresh, now, day) { Store.doneCount(prefs, day, now) }
    val percent = if (total == 0) 0 else done * 100 / total

    if (showSubmit) {
        AlertDialog(
            onDismissRequest = { showSubmit = false },
            title = { Text(if (isToday) "Submit today?" else "Save this day?") },
            text = { Text("You completed $done of $total activities ($percent%). Submitting saves today’s result to your weekly and monthly analysis and locks the checklist. You can reopen the day if you need to.") },
            confirmButton = {
                TextButton(onClick = {
                    prefs.edit().putString("review_reason_$day", reviewReason).putString("review_plan_$day", reviewPlan).apply()
                    Store.submitDay(prefs, day, System.currentTimeMillis())
                    timerRunning = false
                    submitted = true
                    showSubmit = false
                    now = System.currentTimeMillis()
                    refresh++
                }) { Text("Submit") }
            },
            dismissButton = { TextButton(onClick = { showSubmit = false }) { Text("Not yet") } }
        )
    }
    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Reset today’s Deen timer?") },
            text = { Text("This sets today’s tracked time back to 0:00:00.") },
            confirmButton = {
                TextButton(onClick = {
                    Store.resetTimer(prefs, day)
                    timerRunning = false
                    showReset = false
                    now = System.currentTimeMillis()
                    refresh++
                }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancel") } }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            DeenCard(color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ProfileAvatar(profile, 64.dp, onClick = onProfileClick)
                        Column(Modifier.weight(1f)) {
                            Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", style = MaterialTheme.typography.titleLarge)
                            Text(SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(day) ?: Date()))
                        }
                    }
                    if (!isToday) {
                        TextButton(onClick = onBackToToday) { Text("Editing a previous day · Back to today") }
                    }
                    Text("$percent%", style = MaterialTheme.typography.headlineLarge)
                    LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("$done of $total activities completed")
                    if (submitted) {
                        Text(if (isToday) "Submitted ✓ — today is saved to your analysis" else "Submitted ✓ — this day is saved to your analysis", fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = { Store.reopenDay(prefs, day); submitted = false }, modifier = Modifier.fillMaxWidth()) { Text(if (isToday) "Reopen day" else "Edit this day") }
                    } else {
                        Button(onClick = { showSubmit = true }, modifier = Modifier.fillMaxWidth()) { Text(if (isToday) "Submit today" else "Save this day") }
                    }
                }
            }
        }
        if (Account.email(context).isNotEmpty() && !prefs.getBoolean("account_drive", false)) {
            item {
                DeenCard(color = MaterialTheme.colorScheme.secondaryContainer) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Google Drive backup is not on yet.", fontWeight = FontWeight.Bold)
                        Text("Your Drive already has a backup. Choose Restore or Backup now to switch automatic backup on.", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = onOpenAccount, modifier = Modifier.fillMaxWidth()) { Text("Open Account & Backup") }
                    }
                }
            }
        }
        if (isToday) item { PrayerWidget() }
        if (isToday) item { HadithCard(onMakeStatus = onOpenStatus) }
        Tasks.groups.forEach { group ->
            item {
                Text(group.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
            }
            items(group.items, key = { it.title }) { task ->
                val valueKey = "$day:${task.title}"
                when (task.kind) {
                    "timer" -> {
                        val ms = Store.timerMillis(prefs, day, now)
                        TimerCard(
                            ms = ms,
                            running = timerRunning && isToday,
                            locked = submitted,
                            canRun = isToday,
                            onStart = {
                                Store.startTimer(prefs, day, System.currentTimeMillis())
                                timerRunning = true
                                now = System.currentTimeMillis()
                            },
                            onPause = {
                                Store.pauseTimer(prefs, System.currentTimeMillis())
                                timerRunning = false
                                now = System.currentTimeMillis()
                                refresh++
                            },
                            onAdd = {
                                Store.addTimerMinutes(prefs, day, 10)
                                now = System.currentTimeMillis()
                                refresh++
                            },
                            onReset = { showReset = true }
                        )
                    }
                    "check" -> {
                        var checked by remember(day, task.title) { mutableStateOf(prefs.getBoolean(valueKey, false)) }
                        DeenCard {
                            Row(
                                Modifier.fillMaxWidth()
                                    .toggleable(
                                        value = checked,
                                        enabled = !submitted,
                                        role = Role.Checkbox,
                                        onValueChange = { v ->
                                            checked = v
                                            prefs.edit().putBoolean(valueKey, v).apply()
                                            refresh++
                                        }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = checked, onCheckedChange = null, enabled = !submitted)
                                Spacer(Modifier.width(10.dp))
                                Text(task.title)
                            }
                        }
                    }
                    "visits" -> VisitsCard(prefs, valueKey, task.title, submitted, { refresh++ }, onOpenPeople)
                    else -> {
                        var amount by remember(day, task.title) { mutableIntStateOf(prefs.getInt(valueKey, 0)) }
                        DeenCard {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(task.title, modifier = Modifier.weight(1f))
                                OutlinedTextField(
                                    value = amount.toString(),
                                    onValueChange = { v ->
                                        amount = v.filter { it.isDigit() }.take(6).toIntOrNull() ?: 0
                                        prefs.edit().putInt(valueKey, amount).apply()
                                        refresh++
                                    },
                                    enabled = !submitted,
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.width(96.dp),
                                    label = { Text("Count") }
                                )
                                if (task.kind == "counter") {
                                    TextButton(
                                        onClick = {
                                            amount += 100
                                            prefs.edit().putInt(valueKey, amount).apply()
                                            refresh++
                                        },
                                        enabled = !submitted
                                    ) { Text("+100") }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Nightly Muhasabah", style = MaterialTheme.typography.titleLarge)
                    Text("What made today’s activities difficult?")
                    OutlinedTextField(reviewReason, { reviewReason = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Text("What will I improve tomorrow?")
                    OutlinedTextField(reviewPlan, { reviewPlan = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Button(
                        onClick = { prefs.edit().putString("review_reason_$day", reviewReason).putString("review_plan_$day", reviewPlan).apply() },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save nightly review") }
                    Text((if (isToday) "Today" else "This day") + ": $done / $total activities ($percent%)")
                }
            }
        }
    }
}

@Composable
private fun TimerCard(
    ms: Long,
    running: Boolean,
    locked: Boolean,
    canRun: Boolean,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onAdd: () -> Unit,
    onReset: () -> Unit
) {
    val goal = Tasks.TIMER_GOAL_MS
    val reached = ms >= goal
    DeenCard(color = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(Tasks.TIMER_TITLE, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(Store.formatHms(ms), fontSize = 40.sp, fontWeight = FontWeight.Bold)
            LinearProgressIndicator(progress = { (ms.toFloat() / goal.toFloat()).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            if (reached) {
                Text("Goal reached ✓ — MashaAllah")
            } else {
                Text("Remaining ${Store.formatHms(goal - ms)} of ${Tasks.TIMER_GOAL_TEXT}")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (running) {
                    Button(onClick = onPause, enabled = !locked, modifier = Modifier.weight(1f)) { Text("Pause") }
                } else {
                    Button(onClick = onStart, enabled = !locked && canRun, modifier = Modifier.weight(1f)) { Text(if (ms > 0L) "Resume" else "Start") }
                }
                OutlinedButton(onClick = onAdd, enabled = !locked, modifier = Modifier.weight(1f)) { Text("+10 min") }
                OutlinedButton(onClick = onReset, enabled = !locked && ms > 0L, modifier = Modifier.weight(1f)) { Text("Reset") }
            }
            Text(if (canRun) "The timer keeps counting even if you close the app." else "Editing a past day: use +10 min to add time.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Ghar Ghar Mulakhat: a simple counter of today's mulakhat, plus an optional "add a person" button. */
@Composable
private fun VisitsCard(prefs: SharedPreferences, valueKey: String, title: String, locked: Boolean, onChange: () -> Unit, onOpenPeople: () -> Unit) {
    var count by remember(valueKey) { mutableIntStateOf(prefs.getInt(valueKey, 0)) }
    var peopleCount by remember { mutableIntStateOf(loadContacts(prefs).size) }
    var showAdd by remember { mutableStateOf(false) }

    fun setCount(v: Int) {
        count = v.coerceIn(0, 9999)
        prefs.edit().putInt(valueKey, count).apply()
        onChange()
    }

    if (showAdd) {
        ContactDialog(
            initial = null,
            onSave = { n, num, notes ->
                val list = loadContacts(prefs) + Mulakhat(System.currentTimeMillis(), n, num, notes)
                saveContacts(prefs, list)
                peopleCount = list.size
                showAdd = false
            },
            onDelete = null,
            onDismiss = { showAdd = false }
        )
    }

    DeenCard {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterHorizontally)
            ) {
                OutlinedButton(onClick = { setCount(count - 1) }, enabled = !locked && count > 0) { Text("−") }
                Text("$count", fontSize = 36.sp, fontWeight = FontWeight.Bold)
                Button(onClick = { setCount(count + 1) }, enabled = !locked) { Text("+") }
            }
            Text("Mulakhat done today", style = MaterialTheme.typography.bodySmall, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("Add a person (if needed)") }
            TextButton(onClick = onOpenPeople, modifier = Modifier.fillMaxWidth()) { Text("View people & notes ($peopleCount)") }
        }
    }
}
