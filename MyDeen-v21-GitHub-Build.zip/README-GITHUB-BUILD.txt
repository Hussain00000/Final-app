MY DEEN — GITHUB APK BUILD

IMPORTANT: Uploading the ZIP file itself to GitHub does not build an APK.
GitHub must contain the extracted project files and the workflow file.

EASIEST METHOD:
1. Extract this ZIP on your phone/computer.
2. Open your GitHub repository.
3. Upload the contents of this ZIP (not the ZIP file itself), keeping the
   MyDeenAndroid folder and the .github folder at the repository root.
4. Commit the upload to the main or master branch.
5. On GitHub, open the repository's Actions tab.
6. Select "Build My Deen APK". If it has not started automatically, select
   "Run workflow".
7. Wait for the green successful check.
8. Open the completed workflow run and download the artifact named
   "My-Deen-debug-APK". Extract it to get app-debug.apk.

The workflow builds the debug APK and attaches it as an Actions artifact.
It does not publish a GitHub Release.
