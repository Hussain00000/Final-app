package com.example.mydeen

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PHRASES = listOf("SubhanAllah", "Alhamdulillah", "Allahu Akbar", "Durood Shareef", "Astaghfirullah", "La ilaha illallah", "La hawla wa la quwwata")
private val ARABIC = listOf(
    "سُبْحَانَ ٱللَّٰهِ",
    "ٱلْحَمْدُ لِلَّٰهِ",
    "ٱللَّٰهُ أَكْبَرُ",
    "ٱللَّٰهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ",
    "أَسْتَغْفِرُ ٱللَّٰهَ",
    "لَا إِلَٰهَ إِلَّا ٱللَّٰهُ",
    "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ الْعَلِيِّ الْعَظِيمِ"
)
private val TARGETS = listOf(33, 99, 100, 500, 1000)
private const val DUROOD_INDEX = 3

@Composable
fun TasbihScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    val haptics = LocalHapticFeedback.current
    var count by remember { mutableIntStateOf(prefs.getInt("tasbih_count", 0)) }
    var target by remember { mutableIntStateOf(prefs.getInt("tasbih_target", 33)) }
    var phrase by remember { mutableIntStateOf(prefs.getInt("tasbih_phrase", 0).coerceIn(0, PHRASES.size - 1)) }
    var vibrate by remember { mutableStateOf(prefs.getBoolean("tasbih_vibrate", true)) }
    var showReset by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    val rounds = if (target > 0) count / target else 0
    val inRound = if (target > 0) count % target else count
    val roundText = if (count > 0 && inRound == 0) "Target reached ✓ — $rounds round(s) complete" else "Round ${rounds + 1} · $inRound / $target"

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Reset the counter?") },
            text = { Text("The count of $count will be set back to 0.") },
            confirmButton = {
                TextButton(onClick = {
                    count = 0
                    prefs.edit().putInt("tasbih_count", 0).apply()
                    showReset = false
                    message = ""
                }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancel") } }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PHRASES.forEachIndexed { i, name ->
                FilterChip(
                    selected = phrase == i,
                    onClick = { phrase = i; prefs.edit().putInt("tasbih_phrase", i).apply() },
                    label = { Text(name) }
                )
            }
        }
        Text(ARABIC[phrase], fontSize = 30.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                count++
                prefs.edit().putInt("tasbih_count", count).apply()
                message = ""
                if (vibrate) {
                    val hit = target > 0 && count % target == 0
                    haptics.performHapticFeedback(if (hit) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove)
                }
            },
            shape = CircleShape,
            modifier = Modifier.size(230.dp).semantics { contentDescription = "Count $count. Double tap to add one." }
        ) {
            Text("$count", fontSize = if (count >= 10000) 44.sp else 64.sp, fontWeight = FontWeight.Bold)
        }
        Text(roundText, style = MaterialTheme.typography.titleMedium)

        Text("Target per round", style = MaterialTheme.typography.labelLarge)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TARGETS.forEach { t ->
                FilterChip(
                    selected = target == t,
                    onClick = { target = t; prefs.edit().putInt("tasbih_target", t).apply() },
                    label = { Text("$t") }
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = {
                    if (count > 0) {
                        count--
                        prefs.edit().putInt("tasbih_count", count).apply()
                    }
                },
                enabled = count > 0,
                modifier = Modifier.weight(1f)
            ) { Text("Undo (−1)") }
            OutlinedButton(onClick = { showReset = true }, enabled = count > 0, modifier = Modifier.weight(1f)) { Text("Reset") }
        }

        if (phrase == DUROOD_INDEX && count > 0) {
            Button(
                onClick = {
                    val key = Store.dayKey() + ":" + Tasks.DUROOD_TITLE
                    prefs.edit().putInt(key, prefs.getInt(key, 0) + count).apply()
                    message = "Added $count to today’s Durood count."
                    count = 0
                    prefs.edit().putInt("tasbih_count", 0).apply()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Add $count to today’s Durood") }
        }
        if (message.isNotEmpty()) Text(message, style = MaterialTheme.typography.bodyMedium)

        Row(
            Modifier.fillMaxWidth().toggleable(
                value = vibrate,
                role = Role.Switch,
                onValueChange = { v -> vibrate = v; prefs.edit().putBoolean("tasbih_vibrate", v).apply() }
            ).padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Vibrate on each tap", modifier = Modifier.weight(1f))
            Switch(checked = vibrate, onCheckedChange = null)
        }
    }
}
