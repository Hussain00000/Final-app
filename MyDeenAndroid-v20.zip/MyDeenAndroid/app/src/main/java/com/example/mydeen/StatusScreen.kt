package com.example.mydeen

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Gold = Color(0xFFFFC857)

/** Menu screen: one Islamic teaching for every day, shareable as an image (for WhatsApp status etc.) or text. */
@Composable
fun StatusScreen() {
    val context = LocalContext.current
    var offset by remember { mutableIntStateOf(0) }
    val date = LocalDate.now().plusDays(offset.toLong())
    val st = DailyStatuses.forDay(date.toEpochDay())
    val dateText = date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()))

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF0B3D2E), Color(0xFF041A13))))
                .padding(22.dp)
        ) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(if (offset == 0) "Today’s Islamic Status" else "Islamic Status", color = Gold, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(dateText, color = Color(0xCCFFFFFF), fontSize = 14.sp)
                Text(st.type, color = Gold, fontWeight = FontWeight.Bold)
                if (st.arabic.isNotEmpty()) {
                    Text(st.arabic, color = Color.White, fontSize = 28.sp, lineHeight = 46.sp, textAlign = TextAlign.Center)
                }
                Text(st.roman, color = Color.White, fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text(st.english, color = Color(0xFFD9E6DF), fontSize = 16.sp, fontStyle = FontStyle.Italic, textAlign = TextAlign.Center)
                Text("— ${st.source}", color = Gold, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { offset -= 1 }, modifier = Modifier.weight(1f)) { Text("◀ Previous") }
            OutlinedButton(onClick = { offset = 0 }, enabled = offset != 0, modifier = Modifier.weight(1f)) { Text("Today") }
            OutlinedButton(onClick = { offset += 1 }, modifier = Modifier.weight(1f)) { Text("Next ▶") }
        }
        Button(onClick = { shareStatusImage(context, st, dateText) }, modifier = Modifier.fillMaxWidth()) { Text("Share as image (status)") }
        OutlinedButton(onClick = { shareStatusText(context, st, dateText) }, modifier = Modifier.fillMaxWidth()) { Text("Share as text") }
        Text("A new teaching appears every day.", style = MaterialTheme.typography.bodySmall)
    }
}

private fun shareStatusText(context: Context, st: DailyStatus, dateText: String) {
    val body = buildString {
        append("Islamic Status — ").append(dateText).append("\n\n")
        if (st.arabic.isNotEmpty()) append(st.arabic).append("\n\n")
        append(st.roman).append("\n\n").append(st.english).append("\n\n— ").append(st.source)
        append("\n\nShared from My Deeni Tracker")
    }
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, body)
    }
    context.startActivity(Intent.createChooser(send, "Share status").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private fun shareStatusImage(context: Context, st: DailyStatus, dateText: String) {
    try {
        val bmp = buildStatusImage(st, dateText)
        val dir = File(context.cacheDir, "status").apply { mkdirs() }
        val file = File(dir, "islamic_status.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, st.roman + "\n\n— " + st.source)
            clipData = ClipData.newRawUri("status", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, "Share status").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(context, "Could not create the image. Try Share as text.", Toast.LENGTH_LONG).show()
    }
}

/** Draws the teaching on a green card (1080 px wide) that looks good as a WhatsApp / Instagram status. */
private fun buildStatusImage(st: DailyStatus, dateText: String): Bitmap {
    val w = 1080
    val pad = 100
    val cw = w - 2 * pad
    val gold = 0xFFFFC857.toInt()
    val white = 0xFFFFFFFF.toInt()
    val soft = 0xFFD9E6DF.toInt()

    fun layout(text: String, size: Float, color: Int, bold: Boolean = false, italic: Boolean = false): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.textSize = size
        tp.color = color
        val style = when {
            bold && italic -> Typeface.BOLD_ITALIC
            bold -> Typeface.BOLD
            italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        tp.typeface = Typeface.create(Typeface.DEFAULT, style)
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, cw)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, 1.2f)
            .build()
    }

    val parts = mutableListOf<Pair<StaticLayout, Int>>()
    parts.add(Pair(layout("My Deeni Tracker", 40f, gold, bold = true), 40))
    parts.add(Pair(layout(dateText, 30f, soft), 70))
    parts.add(Pair(layout(st.type, 36f, gold, bold = true), 40))
    if (st.arabic.isNotEmpty()) parts.add(Pair(layout(st.arabic, 66f, white), 50))
    parts.add(Pair(layout(st.roman, 48f, white, bold = true), 40))
    parts.add(Pair(layout(st.english, 38f, soft, italic = true), 50))
    parts.add(Pair(layout("— " + st.source, 34f, gold), 0))

    val total = parts.sumOf { it.first.height + it.second }
    val h = maxOf(1350, total + 2 * 150)
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF0B3D2E.toInt(), 0xFF041A13.toInt(), Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)

    val line = Paint(Paint.ANTI_ALIAS_FLAG)
    line.color = gold
    c.drawRect(pad.toFloat(), 90f, (w - pad).toFloat(), 94f, line)
    c.drawRect(pad.toFloat(), (h - 130).toFloat(), (w - pad).toFloat(), (h - 126).toFloat(), line)

    var y = (h - total) / 2f
    for (p in parts) {
        c.save()
        c.translate(pad.toFloat(), y)
        p.first.draw(c)
        c.restore()
        y += p.first.height + p.second
    }

    val foot = TextPaint(Paint.ANTI_ALIAS_FLAG)
    foot.textSize = 28f
    foot.color = soft
    foot.textAlign = Paint.Align.CENTER
    c.drawText("Shared from My Deeni Tracker", w / 2f, (h - 70).toFloat(), foot)
    return bmp
}
