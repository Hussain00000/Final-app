package com.example.mydeen

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.abs

data class Masjid(
    val name: String,
    val lat: Double,
    val lon: Double,
    val distanceM: Float,
    val bearing: Float,
    val address: String,
    val phone: String
)

/**
 * Finds mosques around a point using OpenStreetMap data through the free Overpass API
 * (no key needed, internet required). The last result is saved so it can still be shown offline.
 */
object MasjidFinder {
    private const val UA = "MyDeenApp/1.0 (Android; nearby masjid finder)"
    private val endpoints = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass.private.coffee/api/interpreter"
    )

    private fun request(url: String, body: String?, readMs: Int): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 4000
        c.readTimeout = readMs
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept", "application/json")
        try {
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            if (c.responseCode != 200) throw IOException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun make(name: String, la: Double, lo: Double, from: DoubleArray, address: String, phone: String): Masjid {
        val res = FloatArray(2)
        Location.distanceBetween(from[0], from[1], la, lo, res)
        return Masjid(name.ifBlank { "Masjid" }, la, lo, res[0], (res[1] + 360f) % 360f, address, phone)
    }

    private val notMuslim = Regex("church|cathedral|chapel|temple|mandir|gurdwara|synagogue|buddh|vihara|kovil|shrine|monastery|christian|hindu|sikh", RegexOption.IGNORE_CASE)
    private val muslimHint = Regex("masjid|mosque|jama|jame|musalla|musalah|idgah|eidgah|islam|muslim|madrasa|markaz|dargah", RegexOption.IGNORE_CASE)

    /** Nominatim: fast place search limited to a box around you. */
    private fun nominatim(lat: Double, lon: Double, radiusM: Int): List<Masjid> {
        val dLat = radiusM / 111320.0
        val dLon = radiusM / (111320.0 * Math.cos(Math.toRadians(lat)).coerceAtLeast(0.2))
        val vb = String.format(Locale.US, "%.5f,%.5f,%.5f,%.5f", lon - dLon, lat + dLat, lon + dLon, lat - dLat)
        val url = "https://nominatim.openstreetmap.org/search?q=mosque&format=jsonv2&limit=40&bounded=1&viewbox=$vb"
        val arr = JSONArray(request(url, null, 8000))
        val out = ArrayList<Masjid>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val la = o.optString("lat").toDoubleOrNull() ?: continue
            val lo = o.optString("lon").toDoubleOrNull() ?: continue
            val display = o.optString("display_name", "")
            val name = o.optString("name", "").ifBlank { display.substringBefore(",").trim() }
            if (notMuslim.containsMatchIn(name) || notMuslim.containsMatchIn(o.optString("type", ""))) continue
            val rest = display.substringAfter(",", "").split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(3).joinToString(", ")
            out.add(make(name, la, lo, doubleArrayOf(lat, lon), rest, ""))
        }
        return out
    }

    /** Photon (Komoot): fast search that favours results close to you. */
    private fun photon(lat: Double, lon: Double, term: String): List<Masjid> {
        val url = "https://photon.komoot.io/api/?q=$term&lat=$lat&lon=$lon&limit=30&osm_tag=amenity:place_of_worship"
        val feats = JSONObject(request(url, null, 8000)).optJSONArray("features") ?: return emptyList()
        val out = ArrayList<Masjid>()
        for (i in 0 until feats.length()) {
            val f = feats.optJSONObject(i) ?: continue
            val coords = f.optJSONObject("geometry")?.optJSONArray("coordinates") ?: continue
            val pr = f.optJSONObject("properties") ?: continue
            val religion = pr.optString("extra", "")
            if (notMuslim.containsMatchIn(religion) || notMuslim.containsMatchIn(pr.optString("name", ""))) continue
            // Photon is a fuzzy text search: only keep places that really look like a masjid
            if (!muslimHint.containsMatchIn(pr.optString("name", "") + " " + religion)) continue
            val addr = listOf(
                listOf(pr.optString("housenumber", ""), pr.optString("street", "")).filter { it.isNotBlank() }.joinToString(" "),
                pr.optString("district", ""), pr.optString("city", "")
            ).filter { it.isNotBlank() }.joinToString(", ")
            out.add(make(pr.optString("name", ""), coords.optDouble(1), coords.optDouble(0), doubleArrayOf(lat, lon), addr, ""))
        }
        return out
    }

    /** Overpass: the most accurate data. All mirrors are asked at once and the first answer wins. */
    private fun overpass(lat: Double, lon: Double, radiusM: Int): List<Masjid> {
        val around = "(around:$radiusM,$lat,$lon)"
        val muslim = "[\"amenity\"=\"place_of_worship\"][\"religion\"=\"muslim\"]"
        val building = "[\"building\"=\"mosque\"]"
        val byName = "[\"amenity\"=\"place_of_worship\"][\"name\"~\"masjid|mosque|jama|jame|musalla|idgah|eidgah\",i]"
        val query = "[out:json][timeout:10];(nwr$muslim$around;nwr$building$around;nwr$byName$around;);out center tags qt 200;"
        val body = "data=" + URLEncoder.encode(query, "UTF-8")
        val pool = java.util.concurrent.Executors.newFixedThreadPool(endpoints.size)
        val cs = java.util.concurrent.ExecutorCompletionService<List<Masjid>>(pool)
        try {
            endpoints.forEach { ep -> cs.submit(java.util.concurrent.Callable { parse(request(ep, body, 11000), lat, lon) }) }
            var last: Exception? = null
            repeat(endpoints.size) {
                val f = cs.poll(12, java.util.concurrent.TimeUnit.SECONDS) ?: throw IOException("Timed out")
                try { return f.get() } catch (e: Exception) { last = e }
            }
            throw IOException(last?.message ?: "No connection")
        } finally {
            pool.shutdownNow()
        }
    }

    /**
     * Blocking: call from a background thread. Fast services (Nominatim, Photon) show first results
     * in about a second; Overpass is the accurate one. As soon as Overpass answers we stop waiting
     * for the others. If Overpass is too slow we give up after ~12 s and keep what we have.
     */
    fun search(lat: Double, lon: Double, radiusM: Int, onPartial: (List<Masjid>) -> Unit = {}): List<Masjid> {
        val names = listOf("overpass", "nominatim", "photon")
        val tasks: List<() -> List<Masjid>> = listOf(
            { overpass(lat, lon, radiusM) },
            { nominatim(lat, lon, radiusM) },
            { photon(lat, lon, "masjid") }
        )
        val pool = java.util.concurrent.Executors.newFixedThreadPool(tasks.size)
        val cs = java.util.concurrent.ExecutorCompletionService<Pair<String, List<Masjid>>>(pool)
        try {
            tasks.forEachIndexed { i, task -> cs.submit(java.util.concurrent.Callable { Pair(names[i], task()) }) }
            val fast = ArrayList<Masjid>()
            var overpassList: List<Masjid>? = null
            var answered = 0
            var succeeded = 0
            val deadline = System.currentTimeMillis() + 12000L
            while (answered < tasks.size && overpassList == null) {
                val wait = deadline - System.currentTimeMillis()
                if (wait <= 0) break
                val f = cs.poll(wait, java.util.concurrent.TimeUnit.MILLISECONDS) ?: break
                answered++
                try {
                    val (src, r) = f.get()
                    succeeded++
                    val inRange = r.filter { it.distanceM <= radiusM }
                    if (src == "overpass") overpassList = inRange else fast.addAll(inRange)
                    onPartial(dedupe((overpassList ?: emptyList()) + fast))
                } catch (e: Exception) { }
            }
            if (succeeded == 0) throw IOException("No connection")
            // Overpass is the reference list. Fuzzy results are only added if they are not already in it.
            return dedupe((overpassList ?: emptyList()) + fast)
        } finally {
            pool.shutdownNow()
        }
    }

    private fun dedupe(list: List<Masjid>): List<Masjid> {
        // services that only return "Masjid" with no real name are kept, but a named copy wins
        val sorted = list.sortedBy { it.distanceM }
        val unique = ArrayList<Masjid>()
        for (m in sorted) {
            // the same masjid often comes back from several services: match by name or by being right next to each other
            val dup = unique.any { u ->
                val gap = abs(u.distanceM - m.distanceM)
                (u.name.equals(m.name, ignoreCase = true) && coordGap(u, m) < 300f) || coordGap(u, m) < 40f
            }
            if (!dup) unique.add(m)
        }
        return unique.take(200)
    }

    private fun coordGap(a: Masjid, b: Masjid): Float {
        val r = FloatArray(1)
        Location.distanceBetween(a.lat, a.lon, b.lat, b.lon, r)
        return r[0]
    }

    private fun parse(body: String, lat: Double, lon: Double): List<Masjid> {
        val elements = JSONObject(body).optJSONArray("elements") ?: return emptyList()
        val out = ArrayList<Masjid>()
        for (i in 0 until elements.length()) {
            val el = elements.optJSONObject(i) ?: continue
            val tags = el.optJSONObject("tags") ?: JSONObject()
            val center = el.optJSONObject("center")
            val la = if (el.has("lat")) el.optDouble("lat") else center?.optDouble("lat") ?: Double.NaN
            val lo = if (el.has("lon")) el.optDouble("lon") else center?.optDouble("lon") ?: Double.NaN
            if (la.isNaN() || lo.isNaN()) continue
            val name = listOf("name", "name:en", "int_name", "alt_name")
                .map { tags.optString(it, "").trim() }.firstOrNull { it.isNotEmpty() } ?: "Masjid"
            val res = FloatArray(2)
            Location.distanceBetween(lat, lon, la, lo, res)
            val bearing = (res[1] + 360f) % 360f
            val address = listOf(
                listOf(tags.optString("addr:housenumber", ""), tags.optString("addr:street", "")).filter { it.isNotBlank() }.joinToString(" "),
                tags.optString("addr:suburb", ""),
                tags.optString("addr:city", "")
            ).filter { it.isNotBlank() }.joinToString(", ")
            val phone = tags.optString("phone", tags.optString("contact:phone", "")).trim()
            out.add(Masjid(name, la, lo, res[0], bearing, address, phone))
        }
        return out
    }

    fun direction(bearing: Float): String {
        val names = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return names[(((bearing + 22.5f) % 360f) / 45f).toInt().coerceIn(0, 7)]
    }

    fun distanceText(m: Float): String =
        if (m < 1000f) "${(Math.round(m / 10f) * 10).coerceAtLeast(10)} m" else String.format(Locale.US, "%.1f km", m / 1000f)

    fun walkText(m: Float): String {
        if (m > 2500f) return ""
        val mins = Math.round(m / 80f).coerceAtLeast(1)
        return "about $mins min walk"
    }

    // ---- saved copy for offline use ----
    fun save(context: Context, lat: Double, lon: Double, list: List<Masjid>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().put("n", m.name).put("la", m.lat).put("lo", m.lon).put("d", m.distanceM.toDouble())
                .put("b", m.bearing.toDouble()).put("a", m.address).put("p", m.phone))
        }
        Store.prefs(context).edit().putString("masjid_cache", arr.toString())
            .putString("masjid_cache_lat", lat.toString()).putString("masjid_cache_lon", lon.toString())
            .putLong("masjid_cache_time", System.currentTimeMillis()).apply()
    }

    fun loadSaved(context: Context): List<Masjid> {
        val s = Store.prefs(context).getString("masjid_cache", null) ?: return emptyList()
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Masjid(o.getString("n"), o.getDouble("la"), o.getDouble("lo"), o.getDouble("d").toFloat(),
                    o.getDouble("b").toFloat(), o.optString("a", ""), o.optString("p", ""))
            }
        } catch (e: Exception) { emptyList() }
    }
}

private fun openMaps(context: Context, m: Masjid, directions: Boolean) {
    val label = Uri.encode(m.name)
    val primary = if (directions) Uri.parse("google.navigation:q=${m.lat},${m.lon}&mode=w")
    else Uri.parse("geo:${m.lat},${m.lon}?q=${m.lat},${m.lon}($label)")
    val web = Uri.parse(
        if (directions) "https://www.google.com/maps/dir/?api=1&destination=${m.lat},${m.lon}&travelmode=walking"
        else "https://www.google.com/maps/search/?api=1&query=${m.lat},${m.lon}"
    )
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, primary).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, web).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) { }
    }
}

private fun callPhone(context: Context, phone: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { }
}

@Composable
fun MasjidScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var lat by remember { mutableStateOf(prefs.getString("loc_lat", null)?.toDoubleOrNull()) }
    var lon by remember { mutableStateOf(prefs.getString("loc_lon", null)?.toDoubleOrNull()) }
    var radiusKm by remember { mutableIntStateOf(prefs.getInt("masjid_radius_km", 3)) }
    var tick by remember { mutableIntStateOf(0) }
    var locating by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var offlineCopy by remember { mutableStateOf(false) }
    var masjids by remember { mutableStateOf(MasjidFinder.loadSaved(context)) }
    var searched by remember { mutableStateOf(false) }

    fun onLocation(loc: Location?) {
        locating = false
        if (loc != null) {
            lat = loc.latitude
            lon = loc.longitude
            prefs.edit().putString("loc_lat", loc.latitude.toString()).putString("loc_lon", loc.longitude.toString()).apply()
            status = ""
        } else {
            status = "Couldn’t get your location. Turn on Location (GPS) in your phone settings and try again."
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) {
            locating = true
            status = "Finding your location…"
            LocationHelper.fetch(context, true) { loc -> onLocation(loc) }
        } else {
            status = "Location permission was denied. Allow it for My Deeni Tracker in your phone’s app settings to find masjids near you."
        }
    }

    fun locate() {
        val granted = context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            return
        }
        locating = true
        status = "Finding your location…"
        LocationHelper.fetch(context, true) { loc -> onLocation(loc) }
    }

    val la = lat
    val lo = lon
    LaunchedEffect(la, lo, radiusKm, tick) {
        if (la == null || lo == null) return@LaunchedEffect
        // a search done a few minutes ago from the same spot is still good: show it instantly
        if (tick == 0 && masjids.isNotEmpty()) {
            val cl = prefs.getString("masjid_cache_lat", null)?.toDoubleOrNull()
            val co = prefs.getString("masjid_cache_lon", null)?.toDoubleOrNull()
            val age = System.currentTimeMillis() - prefs.getLong("masjid_cache_time", 0L)
            val rr = prefs.getInt("masjid_cache_radius", -1)
            if (cl != null && co != null && rr == radiusKm && age < 20 * 60000L) {
                val r = FloatArray(1)
                Location.distanceBetween(la, lo, cl, co, r)
                if (r[0] < 150f) { searched = true; return@LaunchedEffect }
            }
        }
        loading = true
        status = ""
        val found: List<Masjid>? = withContext(Dispatchers.IO) {
            try {
                MasjidFinder.search(la, lo, radiusKm * 1000) { partial ->
                    masjids = partial
                    offlineCopy = false
                }
            } catch (e: Exception) { null }
        }
        loading = false
        searched = true
        if (found != null) {
            masjids = found
            offlineCopy = false
            MasjidFinder.save(context, la, lo, found)
            prefs.edit().putInt("masjid_cache_radius", radiusKm).apply()
        } else {
            offlineCopy = masjids.isNotEmpty()
            status = if (masjids.isNotEmpty()) "No internet connection. Showing your last saved list."
            else "Couldn’t load masjids. Check your internet connection and try again."
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (la != null) "Masjids around your saved location" else "Find the masjids closest to you. Allow location to begin.",
                    style = MaterialTheme.typography.titleMedium
                )
                Button(onClick = { locate() }, enabled = !locating && !loading, modifier = Modifier.fillMaxWidth()) {
                    Text(if (la != null) "Update my location" else "Use my location")
                }
                Text("Search distance", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 3, 5, 10, 20).forEach { km ->
                        FilterChip(
                            selected = radiusKm == km,
                            onClick = { radiusKm = km; prefs.edit().putInt("masjid_radius_km", km).apply() },
                            label = { Text("$km km") }
                        )
                    }
                }
                if (loading || locating) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                        Text(if (locating) "Finding your location…" else if (masjids.isNotEmpty()) "Still searching for more masjids…" else "Searching for masjids…", style = MaterialTheme.typography.bodyMedium)
                    }
                } else if (status.isNotEmpty()) {
                    Text(status, style = MaterialTheme.typography.bodyMedium)
                    if (la != null) TextButton(onClick = { tick++ }) { Text("Try again") }
                }
            }
        }

        if (la != null && lo != null) {
            if (!loading && searched && masjids.isEmpty() && status.isEmpty()) {
                DeenCard {
                    Text(
                        "No masjids found within $radiusKm km. Try a larger search distance. Masjid data comes from OpenStreetMap, so a few places may be missing.",
                        Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
            if (masjids.isNotEmpty()) {
                Text(
                    (if (offlineCopy) "Saved list · " else "") + "${masjids.size} masjid${if (masjids.size == 1) "" else "s"} · nearest first",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
            masjids.forEach { m ->
                DeenCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Text(m.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(12.dp))
                            Text(MasjidFinder.distanceText(m.distanceM) + " " + MasjidFinder.direction(m.bearing), style = MaterialTheme.typography.titleMedium)
                        }
                        val walk = MasjidFinder.walkText(m.distanceM)
                        if (walk.isNotEmpty()) Text(walk, style = MaterialTheme.typography.bodySmall)
                        if (m.address.isNotEmpty()) Text(m.address, style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                            Button(onClick = { openMaps(context, m, true) }) { Text("Directions") }
                            OutlinedButton(onClick = { openMaps(context, m, false) }) { Text("View on map") }
                            if (m.phone.isNotEmpty()) TextButton(onClick = { callPhone(context, m.phone) }) { Text("Call") }
                        }
                    }
                }
            }
            DeenCard {
                Text(
                    "Masjid locations come from OpenStreetMap contributors. Timings and facilities are not listed, so please confirm with the masjid.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
