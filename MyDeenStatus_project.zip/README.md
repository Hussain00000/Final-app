# My Deen Status (new app)

Daily Islamic status image: themed background + ORIGINAL ARABIC at the top, translation, source.
Buttons: Prev / Next, Share, Save (to Pictures/MyDeenStatus), Live sheet.

## Build the APK on GitHub (no Android Studio needed)
1. Create a repo, upload the CONTENTS of this folder to the repo root
   (settings.gradle.kts, build.gradle.kts, app/, .github/ ...). Do not upload the folder itself.
   Tip: easiest is `git init`, `git add .`, `git commit`, `git push` so the hidden .github folder is included.
2. Open the repo > Actions > "Build My Deen Status APK" (it runs on every push, or press Run workflow).
3. When green, open the run > Artifacts > MyDeenStatus-debug-apk > download, unzip, install the .apk on your phone
   (allow "install unknown apps").

## Live statuses and backgrounds from Google
1. Google Sheets: File > Import > sample_status_sheet.csv (columns: date,kind,arabic,text,source,theme,bg_url).
2. File > Share > Publish to web > pick the tab > CSV > Publish > copy the link.
3. In the app tap "Live sheet", paste the link, "Save & load". Edit the sheet anytime; the app reloads it on launch.
4. Backgrounds: put your own 1080x1920 images in Drive (Anyone with the link), paste the share link in bg_url.
   Blank bg_url = built-in themed art (chosen by `theme`, or by the meaning of the text).
Only use images you own or that are licensed for this.
