package com.deen.status

data class Status(
    val kind: String,          // ayah | hadith | dua | action
    val arabic: String,        // original Arabic
    val text: String,          // translation / reminder
    val source: String = "",
    val theme: String = "",    // dua, quran, hadith, namaz, sabr, shukr, tauba, sadaqah, family, default
    val bgUrl: String = "",    // optional live background image link
    val date: String = ""      // optional yyyy-MM-dd
)
