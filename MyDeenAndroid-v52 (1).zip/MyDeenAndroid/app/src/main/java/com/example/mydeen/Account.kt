package com.example.mydeen

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Google account details and the backup/restore of all saved data as JSON. */
object Account {
    private val EXCLUDED = setOf("account_email", "account_name", "account_drive", "drive_last", "login_done", "account_phone")

    fun email(context: Context): String = Store.prefs(context).getString("account_email", "") ?: ""
    fun name(context: Context): String = Store.prefs(context).getString("account_name", "") ?: ""

    fun signIn(context: Context, email: String, name: String) {
        Store.prefs(context).edit().putString("account_email", email.trim().lowercase(Locale.US)).putString("account_name", name).putBoolean("login_done", true).apply()
    }

    fun signOut(context: Context) {
        Store.prefs(context).edit().remove("account_email").remove("account_name").remove("account_drive").remove("drive_last").remove("account_phone").putBoolean("login_done", false).apply()
        DriveBackup.cancel(context)
    }

    fun turnOnAuto(context: Context) {
        Store.prefs(context).edit().putBoolean("account_drive", true).apply()
        DriveBackup.schedule(context)
    }

    fun hasLocalData(context: Context): Boolean {
        val re = Regex("^\\d{4}-\\d{2}-\\d{2}:")
        return Store.prefs(context).all.keys.any { re.containsMatchIn(it) }
    }

    /** All saved data (checklist, tasbih, timer, settings…) as one JSON text. */
    fun export(context: Context): String {
        val root = JSONObject()
        for ((k, v) in Store.prefs(context).all) {
            if (k in EXCLUDED) continue
            val o = JSONObject()
            when (v) {
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Set<*> -> { o.put("t", "set"); o.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            root.put(k, o)
        }
        return root.toString()
    }

    /** Returns how many items were restored, or -1 if the text is not a valid backup. */
    fun restore(context: Context, text: String): Int {
        return try {
            val a = text.indexOf('{')
            val b = text.lastIndexOf('}')
            if (a < 0 || b <= a) return -1
            val root = JSONObject(text.substring(a, b + 1))
            val e = Store.prefs(context).edit()
            var n = 0
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                if (k in EXCLUDED) continue
                val o = root.getJSONObject(k)
                when (o.getString("t")) {
                    "b" -> e.putBoolean(k, o.getBoolean("v"))
                    "i" -> e.putInt(k, o.getInt("v"))
                    "l" -> e.putLong(k, o.getLong("v"))
                    "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                    "s" -> e.putString(k, o.getString("v"))
                    "set" -> {
                        val arr = o.getJSONArray("v")
                        e.putStringSet(k, (0 until arr.length()).map { arr.getString(it) }.toSet())
                    }
                    else -> continue
                }
                n++
            }
            e.apply()
            n
        } catch (ex: Exception) { -1 }
    }
}

@Composable
fun AccountScreen(onLogout: () -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf(Account.email(context)) }
    var name by remember { mutableStateOf(Account.name(context)) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var lastBackup by remember { mutableLongStateOf(Store.prefs(context).getLong("drive_last", 0L)) }
    var driveOn by remember { mutableStateOf(Store.prefs(context).getBoolean("account_drive", false)) }

    fun refreshState() {
        val p = Store.prefs(context)
        lastBackup = p.getLong("drive_last", 0L)
        driveOn = p.getBoolean("account_drive", false)
    }

    val g = rememberGoogleLogin { _ ->
        email = Account.email(context)
        name = Account.name(context)
        refreshState()
    }

    fun runBackup() {
        busy = true
        msg = "Saving to Google Drive…"
        scope.launch {
            val o = withContext(Dispatchers.IO) { DriveBackup.backupNow(context) }
            if (o.ok) Account.turnOnAuto(context)
            msg = o.message
            refreshState()
            busy = false
        }
    }

    fun runRestore() {
        busy = true
        msg = "Loading from Google Drive…"
        scope.launch {
            val o = withContext(Dispatchers.IO) { DriveBackup.restoreNow(context) }
            if (o.ok) Account.turnOnAuto(context)
            msg = o.message
            refreshState()
            busy = false
        }
    }

    fun runDelete() {
        busy = true
        msg = "Deleting from Google Drive…"
        scope.launch {
            val o = withContext(Dispatchers.IO) { DriveBackup.deleteBackup(context) }
            msg = o.message
            refreshState()
            busy = false
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete Drive backup?") },
            text = { Text("This permanently removes your My Deeni Tracker backup from your Google Drive. Data on this phone is not touched.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; runDelete() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }

    val shown = if (g.msg.isNotEmpty()) g.msg else msg

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Profile", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                if (email.isEmpty()) {
                    Text("You are using Guest mode. Your data stays only on this phone.", style = MaterialTheme.typography.bodyMedium)
                    Text("Login with Google to save it automatically to your own Google Drive.", style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { msg = ""; g.start() }, enabled = !g.busy, modifier = Modifier.fillMaxWidth()) { Text("Login with Google") }
                } else {
                    if (name.isNotEmpty()) Text(name, style = MaterialTheme.typography.titleMedium)
                    Text(email, style = MaterialTheme.typography.bodyLarge)
                    OutlinedButton(onClick = {
                        Account.signOut(context)
                        email = ""; name = ""
                        refreshState()
                        onLogout()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Logout") }
                }
                if (shown.isNotEmpty()) Text(shown, style = MaterialTheme.typography.bodyMedium)
            }
        }

        if (email.isNotEmpty()) {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Google Drive backup", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text(
                        (if (driveOn) "Automatic backup is ON: saved when you leave the app and once a day." else "Automatic backup is OFF until you backup or restore once.") +
                            "\nLast backup: " + (if (lastBackup > 0L) SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(lastBackup)) else "never"),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = { runBackup() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Backup now") }
                    OutlinedButton(onClick = { runRestore() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Restore from Drive") }
                    TextButton(onClick = { confirmDelete = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Delete my Drive backup") }
                    Text("The backup is stored in a private app folder in your Drive.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
