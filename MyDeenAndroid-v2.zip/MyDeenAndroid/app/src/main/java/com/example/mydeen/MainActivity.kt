package com.example.mydeen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminder.createChannel(this)
        Reminder.scheduleAll(this)
        setContent { MyDeenTheme { MyDeenApp() } }
    }
}

private val MENU = listOf(
    "home" to "Today’s checklist",
    "tasbih" to "Digital Tasbih",
    "prayer" to "Prayer Times",
    "analysis" to "Weekly & Monthly Analysis",
    "reminders" to "Reminders"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyDeenApp() {
    var screen by rememberSaveable { mutableStateOf("home") }
    var menuOpen by remember { mutableStateOf(false) }
    BackHandler(enabled = screen != "home") { screen = "home" }
    val title = MENU.firstOrNull { it.first == screen }?.second ?: "My Deen"

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (screen == "home") "My Deen  •  Daily Tracker" else title) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Text("⋮", fontSize = 28.sp, modifier = Modifier.semantics { contentDescription = "Menu" })
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            MENU.forEach { entry ->
                                DropdownMenuItem(
                                    text = { Text(entry.second, fontWeight = if (screen == entry.first) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = { screen = entry.first; menuOpen = false }
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                "tasbih" -> TasbihScreen()
                "prayer" -> PrayerScreen()
                "analysis" -> AnalysisScreen()
                "reminders" -> RemindersScreen()
                else -> HomeScreen()
            }
        }
    }
}
