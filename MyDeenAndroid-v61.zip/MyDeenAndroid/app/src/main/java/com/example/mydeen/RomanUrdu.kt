package com.example.mydeen

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Writes the Roman Urdu line (Urdu in English letters) for online verses and hadith,
 * using the Claude API on the English meaning. Built-in verses already have hand-written Roman Urdu.
 *
 * Setup: put your Anthropic API key in [API_KEY]. While it is empty, online verses simply show no Urdu line.
 * NOTE: a key inside an app can be extracted from the APK. Use it for your own phone only, or move the call
 * to a small server of yours and point [ENDPOINT] at it.
 */
object RomanUrdu {
    const val API_KEY = ""                                   // <- paste your key here (sk-ant-...)
    const val ENDPOINT = "https://api.anthropic.com/v1/messages"
    private const val MODEL = "claude-haiku-5-5"

    private val cache = HashMap<String, String>()

    val enabled: Boolean get() = API_KEY.isNotBlank()

    /** Same verse with the Roman Urdu line filled in; the original if it already has one or the call fails. */
    fun fill(v: StatusVerse): StatusVerse {
        if (v.urdu.isNotBlank() || !enabled) return v
        val key = v.source
        val text = cache[key] ?: translate(v)?.also { cache[key] = it } ?: return v
        return StatusVerse(v.arabic, v.roman, v.translation, text, v.source, v.isQuran, false)
    }

    private fun translate(v: StatusVerse): String? {
        return try {
            val kind = if (v.isQuran) "Quran verse" else "hadith"
            val prompt = "Translate this $kind into Roman Urdu (Urdu written in English letters, the way Pakistanis and Indians " +
                "text it, e.g. \"Be-shak Allah sabr karne walon ke saath hai.\"). Stay faithful to the meaning, " +
                "use respectful simple words, keep it about as short as the English. Reply with ONLY the Roman Urdu sentence, " +
                "no quotes, no notes.\n\nArabic: ${v.arabic}\nEnglish: ${v.translation}\nReference: ${v.source}"
            val body = JSONObject()
                .put("model", MODEL)
                .put("max_tokens", 300)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            val c = URL(ENDPOINT).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 6000
            c.readTimeout = 15000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", API_KEY)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            try {
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                if (c.responseCode != 200) return null
                val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val arr = json.getJSONArray("content")
                val sb = StringBuilder()
                for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
                val out = sb.toString().trim().trim('"', '“', '”')
                if (out.isBlank() || out.length > 400 || out.any { it in '\u0600'..'\u06FF' }) null else out
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }
}
