package com.example.mydeen

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(profile: android.graphics.Bitmap? = null, onProfileClick: () -> Unit = {}, onOpenAccount: () -> Unit = {}) {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    val day = remember { Store.dayKey() }
    var refresh by remember { mutableIntStateOf(0) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var timerRunning by remember { mutableStateOf(false) }
    var submitted by remember { mutableStateOf(Store.isSubmitted(prefs, day)) }
    var showSubmit by remember { mutableStateOf(false) }
    var showReset by remember { mutableStateOf(false) }
    var reviewReason by remember { mutableStateOf(prefs.getString("review_reason_$day", "") ?: "") }
    var reviewPlan by remember { mutableStateOf(prefs.getString("review_plan_$day", "") ?: "") }

    LaunchedEffect(Unit) {
        // A timer left running from an earlier day is stopped and credited to that day.
        if (Store.timerRunning(prefs) && Store.timerDay(prefs) != day) Store.pauseTimer(prefs, System.currentTimeMillis())
        timerRunning = Store.timerRunning(prefs)
        now = System.currentTimeMillis()
        refresh++
    }
    LaunchedEffect(timerRunning) {
        while (timerRunning) {
            now = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val total = Tasks.all.size
    val done = remember(refresh, now) { Store.doneCount(prefs, day, now) }
    val percent = if (total == 0) 0 else done * 100 / total

    if (showSubmit) {
        AlertDialog(
            onDismissRequest = { showSubmit = false },
            title = { Text("Submit today?") },
            text = { Text("You completed $done of $total activities ($percent%). Submitting saves today’s result to your weekly and monthly analysis and locks the checklist. You can reopen the day if you need to.") },
            confirmButton = {
                TextButton(onClick = {
                    prefs.edit().putString("review_reason_$day", reviewReason).putString("review_plan_$day", reviewPlan).apply()
                    Store.submitDay(prefs, day, System.currentTimeMillis())
                    timerRunning = false
                    submitted = true
                    showSubmit = false
                    now = System.currentTimeMillis()
                    refresh++
                }) { Text("Submit") }
            },
            dismissButton = { TextButton(onClick = { showSubmit = false }) { Text("Not yet") } }
        )
    }
    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Reset today’s Deen timer?") },
            text = { Text("This sets today’s tracked time back to 0:00:00.") },
            confirmButton = {
                TextButton(onClick = {
                    Store.resetTimer(prefs, day)
                    timerRunning = false
                    showReset = false
                    now = System.currentTimeMillis()
                    refresh++
                }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { showReset = false }) { Text("Cancel") } }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            DeenCard(color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ProfileAvatar(profile, 64.dp, onClick = onProfileClick)
                        Column(Modifier.weight(1f)) {
                            Text("بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", style = MaterialTheme.typography.titleLarge)
                            Text(SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()))
                        }
                    }
                    Text("$percent%", style = MaterialTheme.typography.headlineLarge)
                    LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth())
                    Text("$done of $total activities completed")
                    if (submitted) {
                        Text("Submitted ✓ — today is saved to your analysis", fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = { Store.reopenDay(prefs, day); submitted = false }, modifier = Modifier.fillMaxWidth()) { Text("Reopen day") }
                    } else {
                        Button(onClick = { showSubmit = true }, modifier = Modifier.fillMaxWidth()) { Text("Submit today") }
                    }
                }
            }
        }
        if (Account.email(context).isNotEmpty() && !prefs.getBoolean("account_drive", false)) {
            item {
                DeenCard(color = MaterialTheme.colorScheme.secondaryContainer) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Google Drive backup is not on yet.", fontWeight = FontWeight.Bold)
                        Text("Your Drive already has a backup. Choose Restore or Backup now to switch automatic backup on.", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = onOpenAccount, modifier = Modifier.fillMaxWidth()) { Text("Open Account & Backup") }
                    }
                }
            }
        }
        item { PrayerWidget() }
        item { HadithCard() }
        Tasks.groups.forEach { group ->
            item {
                Text(group.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
            }
            items(group.items, key = { it.title }) { task ->
                val valueKey = "$day:${task.title}"
                when (task.kind) {
                    "timer" -> {
                        val ms = Store.timerMillis(prefs, day, now)
                        TimerCard(
                            ms = ms,
                            running = timerRunning,
                            locked = submitted,
                            onStart = {
                                Store.startTimer(prefs, day, System.currentTimeMillis())
                                timerRunning = true
                                now = System.currentTimeMillis()
                            },
                            onPause = {
                                Store.pauseTimer(prefs, System.currentTimeMillis())
                                timerRunning = false
                                now = System.currentTimeMillis()
                                refresh++
                            },
                            onAdd = {
                                Store.addTimerMinutes(prefs, day, 10)
                                now = System.currentTimeMillis()
                                refresh++
                            },
                            onReset = { showReset = true }
                        )
                    }
                    "check" -> {
                        var checked by remember(day, task.title) { mutableStateOf(prefs.getBoolean(valueKey, false)) }
                        DeenCard {
                            Row(
                                Modifier.fillMaxWidth()
                                    .toggleable(
                                        value = checked,
                                        enabled = !submitted,
                                        role = Role.Checkbox,
                                        onValueChange = { v ->
                                            checked = v
                                            prefs.edit().putBoolean(valueKey, v).apply()
                                            refresh++
                                        }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = checked, onCheckedChange = null, enabled = !submitted)
                                Spacer(Modifier.width(10.dp))
                                Text(task.title)
                            }
                        }
                    }
                    "visits" -> VisitsCard(prefs, valueKey, task.title, submitted) { refresh++ }
                    else -> {
                        var amount by remember(day, task.title) { mutableIntStateOf(prefs.getInt(valueKey, 0)) }
                        DeenCard {
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(task.title, modifier = Modifier.weight(1f))
                                OutlinedTextField(
                                    value = amount.toString(),
                                    onValueChange = { v ->
                                        amount = v.filter { it.isDigit() }.take(6).toIntOrNull() ?: 0
                                        prefs.edit().putInt(valueKey, amount).apply()
                                        refresh++
                                    },
                                    enabled = !submitted,
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.width(96.dp),
                                    label = { Text("Count") }
                                )
                                if (task.kind == "counter") {
                                    TextButton(
                                        onClick = {
                                            amount += 100
                                            prefs.edit().putInt(valueKey, amount).apply()
                                            refresh++
                                        },
                                        enabled = !submitted
                                    ) { Text("+100") }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Nightly Muhasabah", style = MaterialTheme.typography.titleLarge)
                    Text("What made today’s activities difficult?")
                    OutlinedTextField(reviewReason, { reviewReason = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Text("What will I improve tomorrow?")
                    OutlinedTextField(reviewPlan, { reviewPlan = it }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Button(
                        onClick = { prefs.edit().putString("review_reason_$day", reviewReason).putString("review_plan_$day", reviewPlan).apply() },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save nightly review") }
                    Text("Today: $done / $total activities ($percent%)")
                }
            }
        }
    }
}

@Composable
private fun TimerCard(
    ms: Long,
    running: Boolean,
    locked: Boolean,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onAdd: () -> Unit,
    onReset: () -> Unit
) {
    val goal = Tasks.TIMER_GOAL_MS
    val reached = ms >= goal
    DeenCard(color = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(Tasks.TIMER_TITLE, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(Store.formatHms(ms), fontSize = 40.sp, fontWeight = FontWeight.Bold)
            LinearProgressIndicator(progress = { (ms.toFloat() / goal.toFloat()).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            if (reached) {
                Text("Goal reached ✓ — MashaAllah")
            } else {
                Text("Remaining ${Store.formatHms(goal - ms)} of ${Tasks.TIMER_GOAL_TEXT}")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (running) {
                    Button(onClick = onPause, enabled = !locked, modifier = Modifier.weight(1f)) { Text("Pause") }
                } else {
                    Button(onClick = onStart, enabled = !locked, modifier = Modifier.weight(1f)) { Text(if (ms > 0L) "Resume" else "Start") }
                }
                OutlinedButton(onClick = onAdd, enabled = !locked, modifier = Modifier.weight(1f)) { Text("+10 min") }
                OutlinedButton(onClick = onReset, enabled = !locked && ms > 0L, modifier = Modifier.weight(1f)) { Text("Reset") }
            }
            Text("The timer keeps counting even if you close the app.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

private data class Mulakhat(val id: Long, val name: String, val number: String, val notes: String)

private const val CONTACTS_KEY = "mulakhat_list"

private fun loadContacts(prefs: SharedPreferences): List<Mulakhat> = try {
    val arr = JSONArray(prefs.getString(CONTACTS_KEY, "[]") ?: "[]")
    (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        Mulakhat(o.getLong("id"), o.optString("name"), o.optString("number"), o.optString("notes"))
    }
} catch (e: Exception) { emptyList() }

private fun saveContacts(prefs: SharedPreferences, list: List<Mulakhat>) {
    val arr = JSONArray()
    list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("number", it.number).put("notes", it.notes)) }
    prefs.edit().putString(CONTACTS_KEY, arr.toString()).apply()
}

private fun loadDone(prefs: SharedPreferences, valueKey: String): Set<Long> =
    (prefs.getString("$valueKey:done", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.toSet()

/**
 * Ghar Ghar Mulakhat: a permanent list of people / houses (name, number, notes).
 * Each day you tick the ones you visited; today's count feeds the checklist and the analysis.
 */
@Composable
private fun VisitsCard(prefs: SharedPreferences, valueKey: String, title: String, locked: Boolean, onChange: () -> Unit) {
    val context = LocalContext.current
    var contacts by remember { mutableStateOf(loadContacts(prefs)) }
    var done by remember(valueKey) { mutableStateOf(loadDone(prefs, valueKey)) }
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Mulakhat?>(null) }
    var confirmDelete by remember { mutableStateOf<Mulakhat?>(null) }

    fun applyDone(ids: Set<Long>, list: List<Mulakhat>) {
        done = ids
        prefs.edit()
            .putString("$valueKey:done", ids.joinToString(","))
            .putInt(valueKey, ids.count { id -> list.any { it.id == id } })
            .apply()
        onChange()
    }

    val visitedToday = done.count { id -> contacts.any { it.id == id } }

    if (showDialog) {
        ContactDialog(
            initial = editing,
            onSave = { n, num, notes ->
                val cur = editing
                val list = if (cur == null) contacts + Mulakhat(System.currentTimeMillis(), n, num, notes)
                else contacts.map { if (it.id == cur.id) Mulakhat(cur.id, n, num, notes) else it }
                contacts = list
                saveContacts(prefs, list)
                showDialog = false
                editing = null
            },
            onDelete = editing?.let { cur -> { confirmDelete = cur; showDialog = false; editing = null } },
            onDismiss = { showDialog = false; editing = null }
        )
    }
    confirmDelete?.let { victim ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete ${victim.name}?") },
            text = { Text("This removes them from your Ghar Ghar Mulakhat list. Past counts are kept.") },
            confirmButton = {
                TextButton(onClick = {
                    val list = contacts.filter { it.id != victim.id }
                    contacts = list
                    saveContacts(prefs, list)
                    applyDone(done - victim.id, list)
                    confirmDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }

    DeenCard {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text("Today: $visitedToday of ${contacts.size}")
            }
            if (contacts.isEmpty()) {
                Text("Add the people or houses you want to visit. Then tick each one on the day you meet them.", style = MaterialTheme.typography.bodySmall)
            }
            contacts.forEach { c ->
                val checked = c.id in done
                Row(verticalAlignment = Alignment.Top) {
                    Checkbox(
                        checked = checked,
                        onCheckedChange = { v -> applyDone(if (v) done + c.id else done - c.id, contacts) },
                        enabled = !locked
                    )
                    Column(Modifier.weight(1f).padding(top = 12.dp)) {
                        Text(c.name, fontWeight = FontWeight.Bold)
                        if (c.number.isNotEmpty()) Text(c.number, style = MaterialTheme.typography.bodySmall)
                        if (c.notes.isNotEmpty()) Text(c.notes, style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        TextButton(onClick = { editing = c; showDialog = true }) { Text("Edit") }
                        if (c.number.isNotEmpty()) {
                            TextButton(onClick = {
                                try {
                                    val tel = c.number.filter { it.isDigit() || it == '+' }
                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$tel")))
                                } catch (e: Exception) { }
                            }) { Text("Call") }
                        }
                    }
                }
            }
            Button(onClick = { editing = null; showDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("Add person / house") }
        }
    }
}

@Composable
private fun ContactDialog(initial: Mulakhat?, onSave: (String, String, String) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var number by remember { mutableStateOf(initial?.number ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add person / house" else "Edit details") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it.replace("\n", " ").take(60) }, singleLine = true, label = { Text("Name / house") })
                OutlinedTextField(
                    value = number,
                    onValueChange = { v -> number = v.filter { it.isDigit() || it == '+' || it == ' ' || it == '-' }.take(20) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    label = { Text("Number (optional)") }
                )
                OutlinedTextField(value = notes, onValueChange = { notes = it.take(300) }, minLines = 2, label = { Text("Notes (optional)") })
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name.trim(), number.trim(), notes.trim()) }, enabled = name.isNotBlank()) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete") }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    )
}
