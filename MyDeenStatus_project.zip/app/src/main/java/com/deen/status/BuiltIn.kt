package com.deen.status

/** Offline statuses (used until / unless a Google Sheet is connected). */
object BuiltIn {
    val list = listOf(
        Status("ayah", "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا", "Allah does not burden a soul beyond its capacity.", "Quran 2:286", "sabr"),
        Status("ayah", "إِنَّ مَعَ الْعُسْرِ يُسْرًا", "Indeed, with hardship comes ease.", "Quran 94:6", "sabr"),
        Status("ayah", "لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ", "If you are grateful, I will surely increase you.", "Quran 14:7", "shukr"),
        Status("ayah", "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ", "Indeed, Allah is with the patient.", "Quran 2:153", "sabr"),
        Status("ayah", "حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ", "Allah is enough for us, and He is the best disposer of affairs.", "Quran 3:173", "quran"),
        Status("ayah", "إِنَّ اللَّهَ يُحِبُّ الْمُحْسِنِينَ", "Indeed, Allah loves those who do good.", "Quran 2:195", "sadaqah"),
        Status("ayah", "إِنَّ اللَّهَ يُحِبُّ التَّوَّابِينَ وَيُحِبُّ الْمُتَطَهِّرِينَ", "Allah loves those who repeatedly repent and those who purify themselves.", "Quran 2:222", "tauba"),
        Status("ayah", "وَاعْتَصِمُوا بِحَبْلِ اللَّهِ جَمِيعًا وَلَا تَفَرَّقُوا", "Hold firmly to the rope of Allah all together and do not become divided.", "Quran 3:103", "family"),
        Status("dua", "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", "Our Lord, give us good in this world and good in the Hereafter, and protect us from the punishment of the Fire.", "Quran 2:201", "dua"),
        Status("dua", "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي", "My Lord, expand my chest and make my task easy for me.", "Quran 20:25-26", "dua"),
        Status("dua", "رَبِّ زِدْنِي عِلْمًا", "My Lord, increase me in knowledge.", "Quran 20:114", "dua"),
        Status("dua", "رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ", "My Lord, forgive me and my parents.", "Quran 71:28", "family"),
        Status("dua", "اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي", "O Allah, You are Forgiving and love forgiveness, so forgive me.", "Tirmidhi", "tauba"),
        Status("dua", "يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ", "O Turner of hearts, keep my heart firm upon Your religion.", "Tirmidhi", "dua"),
        Status("hadith", "إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ", "Actions are judged by intentions.", "Bukhari & Muslim", "hadith"),
        Status("hadith", "تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ صَدَقَةٌ", "Your smile in the face of your brother is charity.", "Tirmidhi", "sadaqah"),
        Status("hadith", "الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ", "A good word is charity.", "Bukhari & Muslim", "sadaqah"),
        Status("hadith", "إِنَّ اللَّهَ رَفِيقٌ يُحِبُّ الرِّفْقَ فِي الْأَمْرِ كُلِّهِ", "Allah is gentle and loves gentleness in all matters.", "Bukhari & Muslim", "sadaqah"),
        Status("hadith", "الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ", "A Muslim is the one from whose tongue and hand other Muslims are safe.", "Bukhari & Muslim", "family"),
        Status("hadith", "الدِّينُ النَّصِيحَةُ", "Religion is sincere advice.", "Muslim", "hadith")
    )
}
