package com.example.mydeen

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.abs

data class Masjid(
    val name: String,
    val lat: Double,
    val lon: Double,
    val distanceM: Float,
    val bearing: Float,
    val address: String,
    val phone: String
)

/**
 * Finds mosques around a point using OpenStreetMap data through the free Overpass API
 * (no key needed, internet required). The last result is saved so it can still be shown offline.
 */
object MasjidFinder {
    private const val UA = "MyDeenApp/1.0 (Android; nearby masjid finder)"
    private val endpoints = listOf(
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter"
    )

    private fun post(endpoint: String, query: String): String {
        val c = URL(endpoint).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 25000
        c.requestMethod = "POST"
        c.doOutput = true
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        try {
            c.outputStream.use { it.write(("data=" + URLEncoder.encode(query, "UTF-8")).toByteArray()) }
            if (c.responseCode != 200) throw IOException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Blocking: call from a background thread. Throws IOException when no server could be reached. */
    fun search(lat: Double, lon: Double, radiusM: Int): List<Masjid> {
        val around = "(around:$radiusM,$lat,$lon)"
        val filter = "[\"amenity\"=\"place_of_worship\"][\"religion\"=\"muslim\"]"
        val query = "[out:json][timeout:25];(node$filter$around;way$filter$around;relation$filter$around;);out center tags;"
        var last: Exception? = null
        for (ep in endpoints) {
            try {
                return parse(post(ep, query), lat, lon)
            } catch (e: Exception) {
                last = e
            }
        }
        throw IOException(last?.message ?: "No connection")
    }

    private fun parse(body: String, lat: Double, lon: Double): List<Masjid> {
        val elements = JSONObject(body).optJSONArray("elements") ?: return emptyList()
        val out = ArrayList<Masjid>()
        for (i in 0 until elements.length()) {
            val el = elements.optJSONObject(i) ?: continue
            val tags = el.optJSONObject("tags") ?: JSONObject()
            val center = el.optJSONObject("center")
            val la = if (el.has("lat")) el.optDouble("lat") else center?.optDouble("lat") ?: Double.NaN
            val lo = if (el.has("lon")) el.optDouble("lon") else center?.optDouble("lon") ?: Double.NaN
            if (la.isNaN() || lo.isNaN()) continue
            val name = listOf("name", "name:en", "int_name", "alt_name")
                .map { tags.optString(it, "").trim() }.firstOrNull { it.isNotEmpty() } ?: "Masjid"
            val res = FloatArray(2)
            Location.distanceBetween(lat, lon, la, lo, res)
            val bearing = (res[1] + 360f) % 360f
            val address = listOf(
                listOf(tags.optString("addr:housenumber", ""), tags.optString("addr:street", "")).filter { it.isNotBlank() }.joinToString(" "),
                tags.optString("addr:suburb", ""),
                tags.optString("addr:city", "")
            ).filter { it.isNotBlank() }.joinToString(", ")
            val phone = tags.optString("phone", tags.optString("contact:phone", "")).trim()
            out.add(Masjid(name, la, lo, res[0], bearing, address, phone))
        }
        // Drop duplicates (a masjid is sometimes mapped as both a point and a building)
        val sorted = out.sortedBy { it.distanceM }
        val unique = ArrayList<Masjid>()
        for (m in sorted) {
            val dup = unique.any { u ->
                u.name.equals(m.name, ignoreCase = true) && abs(u.distanceM - m.distanceM) < 80f
            }
            if (!dup) unique.add(m)
        }
        return unique.take(50)
    }

    fun direction(bearing: Float): String {
        val names = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
        return names[(((bearing + 22.5f) % 360f) / 45f).toInt().coerceIn(0, 7)]
    }

    fun distanceText(m: Float): String =
        if (m < 1000f) "${(Math.round(m / 10f) * 10).coerceAtLeast(10)} m" else String.format(Locale.US, "%.1f km", m / 1000f)

    fun walkText(m: Float): String {
        if (m > 2500f) return ""
        val mins = Math.round(m / 80f).coerceAtLeast(1)
        return "about $mins min walk"
    }

    // ---- saved copy for offline use ----
    fun save(context: Context, lat: Double, lon: Double, list: List<Masjid>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().put("n", m.name).put("la", m.lat).put("lo", m.lon).put("d", m.distanceM.toDouble())
                .put("b", m.bearing.toDouble()).put("a", m.address).put("p", m.phone))
        }
        Store.prefs(context).edit().putString("masjid_cache", arr.toString())
            .putString("masjid_cache_lat", lat.toString()).putString("masjid_cache_lon", lon.toString()).apply()
    }

    fun loadSaved(context: Context): List<Masjid> {
        val s = Store.prefs(context).getString("masjid_cache", null) ?: return emptyList()
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Masjid(o.getString("n"), o.getDouble("la"), o.getDouble("lo"), o.getDouble("d").toFloat(),
                    o.getDouble("b").toFloat(), o.optString("a", ""), o.optString("p", ""))
            }
        } catch (e: Exception) { emptyList() }
    }
}

private fun openMaps(context: Context, m: Masjid, directions: Boolean) {
    val label = Uri.encode(m.name)
    val primary = if (directions) Uri.parse("google.navigation:q=${m.lat},${m.lon}&mode=w")
    else Uri.parse("geo:${m.lat},${m.lon}?q=${m.lat},${m.lon}($label)")
    val web = Uri.parse(
        if (directions) "https://www.google.com/maps/dir/?api=1&destination=${m.lat},${m.lon}&travelmode=walking"
        else "https://www.google.com/maps/search/?api=1&query=${m.lat},${m.lon}"
    )
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, primary).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, web).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) { }
    }
}

private fun callPhone(context: Context, phone: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { }
}

@Composable
fun MasjidScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var lat by remember { mutableStateOf(prefs.getString("loc_lat", null)?.toDoubleOrNull()) }
    var lon by remember { mutableStateOf(prefs.getString("loc_lon", null)?.toDoubleOrNull()) }
    var radiusKm by remember { mutableIntStateOf(prefs.getInt("masjid_radius_km", 5)) }
    var tick by remember { mutableIntStateOf(0) }
    var locating by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var offlineCopy by remember { mutableStateOf(false) }
    var masjids by remember { mutableStateOf(MasjidFinder.loadSaved(context)) }
    var searched by remember { mutableStateOf(false) }

    fun onLocation(loc: Location?) {
        locating = false
        if (loc != null) {
            lat = loc.latitude
            lon = loc.longitude
            prefs.edit().putString("loc_lat", loc.latitude.toString()).putString("loc_lon", loc.longitude.toString()).apply()
            status = ""
        } else {
            status = "Couldn’t get your location. Turn on Location (GPS) in your phone settings and try again."
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) {
            locating = true
            status = "Finding your location…"
            LocationHelper.fetch(context, true) { loc -> onLocation(loc) }
        } else {
            status = "Location permission was denied. Allow it for My Deeni Tracker in your phone’s app settings to find masjids near you."
        }
    }

    fun locate() {
        val granted = context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            return
        }
        locating = true
        status = "Finding your location…"
        LocationHelper.fetch(context, true) { loc -> onLocation(loc) }
    }

    val la = lat
    val lo = lon
    LaunchedEffect(la, lo, radiusKm, tick) {
        if (la == null || lo == null) return@LaunchedEffect
        loading = true
        status = ""
        val found: List<Masjid>? = withContext(Dispatchers.IO) {
            try { MasjidFinder.search(la, lo, radiusKm * 1000) } catch (e: Exception) { null }
        }
        loading = false
        searched = true
        if (found != null) {
            masjids = found
            offlineCopy = false
            MasjidFinder.save(context, la, lo, found)
        } else {
            offlineCopy = masjids.isNotEmpty()
            status = if (masjids.isNotEmpty()) "No internet connection. Showing your last saved list."
            else "Couldn’t load masjids. Check your internet connection and try again."
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (la != null) "Masjids around your saved location" else "Find the masjids closest to you. Allow location to begin.",
                    style = MaterialTheme.typography.titleMedium
                )
                Button(onClick = { locate() }, enabled = !locating && !loading, modifier = Modifier.fillMaxWidth()) {
                    Text(if (la != null) "Update my location" else "Use my location")
                }
                Text("Search distance", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(2, 5, 10, 20, 50).forEach { km ->
                        FilterChip(
                            selected = radiusKm == km,
                            onClick = { radiusKm = km; prefs.edit().putInt("masjid_radius_km", km).apply() },
                            label = { Text("$km km") }
                        )
                    }
                }
                if (loading || locating) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                        Text(if (locating) "Finding your location…" else "Searching for masjids…", style = MaterialTheme.typography.bodyMedium)
                    }
                } else if (status.isNotEmpty()) {
                    Text(status, style = MaterialTheme.typography.bodyMedium)
                    if (la != null) TextButton(onClick = { tick++ }) { Text("Try again") }
                }
            }
        }

        if (la != null && lo != null) {
            if (!loading && searched && masjids.isEmpty() && status.isEmpty()) {
                DeenCard {
                    Text(
                        "No masjids found within $radiusKm km. Try a larger search distance. Masjid data comes from OpenStreetMap, so a few places may be missing.",
                        Modifier.padding(16.dp), style = MaterialTheme.typography.bodyLarge
                    )
                }
            }
            if (masjids.isNotEmpty()) {
                Text(
                    (if (offlineCopy) "Saved list · " else "") + "${masjids.size} masjid${if (masjids.size == 1) "" else "s"} · nearest first",
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
            masjids.forEach { m ->
                DeenCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Text(m.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(12.dp))
                            Text(MasjidFinder.distanceText(m.distanceM) + " " + MasjidFinder.direction(m.bearing), style = MaterialTheme.typography.titleMedium)
                        }
                        val walk = MasjidFinder.walkText(m.distanceM)
                        if (walk.isNotEmpty()) Text(walk, style = MaterialTheme.typography.bodySmall)
                        if (m.address.isNotEmpty()) Text(m.address, style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                            Button(onClick = { openMaps(context, m, true) }) { Text("Directions") }
                            OutlinedButton(onClick = { openMaps(context, m, false) }) { Text("View on map") }
                            if (m.phone.isNotEmpty()) TextButton(onClick = { callPhone(context, m.phone) }) { Text("Call") }
                        }
                    }
                }
            }
            DeenCard {
                Text(
                    "Masjid locations come from OpenStreetMap contributors. Timings and facilities are not listed, so please confirm with the masjid.",
                    Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
