package com.example.mydeen

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Islamic Status maker: pick a background (moon & flowers, mosque, star pattern, Makkah / Madinah) and a Quran ayah or hadith (Arabic + Roman English),
 * then share it to WhatsApp Status (or any app) or save it to the gallery.
 */
@Composable
fun StatusScreen() {
    val context = LocalContext.current
    var styleIdx by rememberSaveable { mutableIntStateOf(0) }
    var filter by rememberSaveable { mutableStateOf("all") }   // all / quran / hadith
    var pos by rememberSaveable { mutableIntStateOf(0) }
    val showRoman = true   // Roman English line is always shown under the Arabic

    val shown = remember(filter) {
        when (filter) {
            "quran" -> StatusArt.verses.filter { it.isQuran }
            "hadith" -> StatusArt.verses.filter { !it.isQuran }
            else -> StatusArt.verses
        }
    }
    val safePos = pos.coerceIn(0, shown.size - 1)
    val verse = shown[safePos]
    val style = StatusArt.styles[styleIdx.coerceIn(0, StatusArt.styles.size - 1)]

    // ---- online wallpapers (endless, from Wikimedia Commons) ----
    var tab by rememberSaveable { mutableIntStateOf(0) }          // 0 = built-in designs, 1 = online wallpapers
    var topicIdx by rememberSaveable { mutableIntStateOf(0) }
    val walls = remember { mutableStateListOf<OnlineWallpaper>() }
    var wallsLoading by remember { mutableStateOf(false) }
    var wallsError by remember { mutableStateOf(false) }
    var endReached by remember { mutableStateOf(false) }
    var nextOffset by remember { mutableIntStateOf(0) }
    var selectedWall by remember { mutableStateOf<OnlineWallpaper?>(null) }
    var wallLoading by remember { mutableStateOf(false) }
    var wallError by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun loadMore() {
        if (wallsLoading) return
        wallsLoading = true
        wallsError = false
        val topic = topicIdx
        scope.launch {
            try {
                var off = nextOffset
                var got = 0
                var tries = 0
                while (got < 8 && tries < 4 && !endReached) {
                    val (list, raw) = withContext(Dispatchers.IO) { Wallpapers.search(Wallpapers.topics[topic].second, off) }
                    if (topic != topicIdx) return@launch
                    walls.addAll(list)
                    got += list.size
                    off += Wallpapers.PAGE
                    tries++
                    if (raw < Wallpapers.PAGE) endReached = true
                }
                nextOffset = off
            } catch (e: Exception) {
                if (topic == topicIdx) wallsError = true
            } finally {
                if (topic == topicIdx) wallsLoading = false
            }
        }
    }

    LaunchedEffect(topicIdx, tab) {
        if (tab == 1) {
            walls.clear(); nextOffset = 0; endReached = false; wallsError = false; wallsLoading = false
            loadMore()
        }
    }

    val appContext = context.applicationContext
    val wallBmp by produceState<Bitmap?>(initialValue = null, selectedWall) {
        val w = selectedWall
        if (w == null) {
            value = null; wallLoading = false; wallError = false
        } else {
            wallLoading = true; wallError = false
            val b = withContext(Dispatchers.IO) { Wallpapers.downloadFull(w) }
            value = b; wallLoading = false; wallError = (b == null)
        }
    }
    val bmp by produceState<Bitmap?>(initialValue = null, styleIdx, filter, safePos, showRoman, wallBmp, selectedWall) {
        if (selectedWall != null && wallBmp == null) return@produceState   // wallpaper still downloading
        value = withContext(Dispatchers.Default) { StatusArt.render(appContext, style, verse, showRoman, wallBmp) }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // preview, same 9:16 shape as a WhatsApp status
        Box(
            Modifier.fillMaxWidth(0.72f).aspectRatio(9f / 16f).clip(RoundedCornerShape(16.dp))
                .background(Color(style.top)),
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            if (b != null) {
                Image(b.asImageBitmap(), contentDescription = "Status preview", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                CircularProgressIndicator(color = Color.White)
            }
            if (wallLoading && b != null) CircularProgressIndicator(color = Color.White)
        }
        if (wallError) Text("Couldn't download this wallpaper. Check your internet or pick another.", style = MaterialTheme.typography.bodySmall)

        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tab == 0, onClick = { tab = 0 }, label = { Text("Designs (${StatusArt.styles.size})") })
                    FilterChip(selected = tab == 1, onClick = { tab = 1 }, label = { Text("Wallpapers ∞") })
                }
                if (tab == 0) {
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    StatusArt.styles.forEachIndexed { i, s ->
                        val selected = i == styleIdx && selectedWall == null
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(60.dp).clip(CircleShape)
                                    .background(Brush.verticalGradient(listOf(Color(s.top), Color(s.bottom))))
                                    .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline), CircleShape)
                                    .clickable { styleIdx = i; selectedWall = null },
                                contentAlignment = Alignment.Center
                            ) {
                                if (s.kind == StatusArt.KIND_PHOTO && s.res != 0) {
                                    Image(painterResource(s.res), contentDescription = s.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                                }
                                val symbol = when (s.kind) {
                                    StatusArt.KIND_MOSQUE -> "🕌"
                                    StatusArt.KIND_PATTERN -> "✦"
                                    StatusArt.KIND_PHOTO -> ""
                                    else -> "☾"
                                }
                                val mark = if (selected) "✓" else symbol
                                if (mark.isNotEmpty()) Text(mark, color = Color(s.accent))
                            }
                            Text(s.name, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                OutlinedButton(
                    onClick = { styleIdx = (0 until StatusArt.styles.size).random(); selectedWall = null },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("🎨 Random background") }
                } else {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Wallpapers.topics.forEachIndexed { i, t ->
                            FilterChip(selected = topicIdx == i, onClick = { topicIdx = i }, label = { Text(t.first) })
                        }
                    }
                    if (walls.isEmpty() && wallsLoading) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            Text("Loading wallpapers…", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (wallsError && walls.isEmpty()) {
                        Text("Couldn't load wallpapers. Check your internet connection.", style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = { loadMore() }, modifier = Modifier.fillMaxWidth()) { Text("Try again") }
                    }
                    if (walls.isNotEmpty()) {
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            walls.forEach { wp ->
                                val selected = selectedWall === wp
                                Box(
                                    Modifier.width(68.dp).height(120.dp).clip(RoundedCornerShape(10.dp))
                                        .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline), RoundedCornerShape(10.dp))
                                        .clickable { selectedWall = wp }
                                ) {
                                    RemoteThumb(wp, Modifier.fillMaxSize())
                                    if (selected) Text("✓", color = Color.White, modifier = Modifier.align(Alignment.Center))
                                }
                            }
                            if (!endReached) {
                                OutlinedButton(onClick = { loadMore() }, enabled = !wallsLoading) { Text(if (wallsLoading) "…" else "More ▶") }
                            }
                        }
                        OutlinedButton(onClick = { selectedWall = walls.random() }, modifier = Modifier.fillMaxWidth()) { Text("🎲 Random wallpaper") }
                    }
                    Text("Photos come from Wikimedia Commons and need internet. Tap “More” for new ones, or pick another topic.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Quran & Hadees", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("all" to "All", "quran" to "Quran", "hadith" to "Hadees").forEach { (key, label) ->
                        FilterChip(selected = filter == key, onClick = { filter = key; pos = 0 }, label = { Text(label) })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { pos = (safePos - 1 + shown.size) % shown.size }, modifier = Modifier.weight(1f)) { Text("◀ Previous") }
                    OutlinedButton(onClick = { pos = (safePos + 1) % shown.size }, modifier = Modifier.weight(1f)) { Text("Next ▶") }
                }
                OutlinedButton(onClick = { pos = (0 until shown.size).random() }, modifier = Modifier.fillMaxWidth()) { Text("🔀 Surprise me") }
                Text("${safePos + 1} of ${shown.size}", style = MaterialTheme.typography.bodySmall)
            }
        }

        Button(
            onClick = { bmp?.let { StatusShare.share(context, it, whatsApp = true) } },
            enabled = bmp != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Share to WhatsApp Status") }
        OutlinedButton(
            onClick = { bmp?.let { StatusShare.share(context, it, whatsApp = false) } },
            enabled = bmp != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Share in another app") }
        OutlinedButton(
            onClick = {
                bmp?.let {
                    val ok = StatusShare.saveToGallery(context, it)
                    Toast.makeText(
                        context,
                        if (ok) "Saved in Pictures/MyDeen" else "Saving needs Android 10 or newer. Use Share instead.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            enabled = bmp != null,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save to gallery") }
        Text(
            "In WhatsApp choose “My status” to post it. The picture is 1080 × 1920, the full-screen status size.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}


/** Small preview picture of an online wallpaper (downloaded once, then kept in memory). */
@Composable
private fun RemoteThumb(wp: OnlineWallpaper, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(initialValue = Wallpapers.cached(Wallpapers.thumbUrl(wp)), wp) {
        if (value == null) value = withContext(Dispatchers.IO) { Wallpapers.loadThumb(wp) }
    }
    val b = bmp
    if (b != null) {
        Image(b.asImageBitmap(), contentDescription = wp.title, contentScale = ContentScale.Crop, modifier = modifier)
    } else {
        Box(modifier.background(Color(0x22000000)))
    }
}
