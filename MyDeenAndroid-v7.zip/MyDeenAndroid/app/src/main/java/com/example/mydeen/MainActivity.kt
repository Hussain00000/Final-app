package com.example.mydeen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Reminder.createChannel(this)
        Reminder.scheduleAll(this)
        setContent { MyDeenTheme { MyDeenApp() } }
    }
}

private val MENU = listOf(
    "home" to "Today’s checklist",
    "tasbih" to "Digital Tasbih",
    "prayer" to "Prayer Times",
    "analysis" to "Weekly & Monthly Analysis",
    "background" to "Background",
    "reminders" to "Reminders"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyDeenApp() {
    var screen by rememberSaveable { mutableStateOf("home") }
    var menuOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var profile by remember { mutableStateOf(Profile.load(context)) }
    var photoDialog by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Profile.save(context, uri)?.let { profile = it }
    }
    var bg by remember { mutableStateOf(loadBgState(context, Store.prefs(context))) }
    val pickPhoto = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    BackHandler(enabled = screen != "home") { screen = "home" }
    val title = MENU.firstOrNull { it.first == screen }?.second ?: "My Deeni Tracker"

    if (photoDialog) {
        AlertDialog(
            onDismissRequest = { photoDialog = false },
            title = { Text("Profile photo") },
            text = { Text(if (profile == null) "Choose a photo from your gallery." else "Change or remove your profile photo.") },
            confirmButton = { TextButton(onClick = { photoDialog = false; pickPhoto() }) { Text(if (profile == null) "Choose photo" else "Change photo") } },
            dismissButton = {
                if (profile != null) TextButton(onClick = { Profile.remove(context); profile = null; photoDialog = false }) { Text("Remove") }
                else TextButton(onClick = { photoDialog = false }) { Text("Cancel") }
            }
        )
    }

    Box(Modifier.fillMaxSize()) {
    BackgroundLayer(bg.kind, bg.color, bg.preset, bg.custom)
    Scaffold(
        containerColor = androidx.compose.ui.graphics.Color.Transparent,
        topBar = {
            TopAppBar(
                title = { Text(if (screen == "home") "My Deeni Tracker" else title) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                navigationIcon = {
                    ProfileAvatar(profile, 36.dp, onClick = { photoDialog = true }, modifier = Modifier.padding(start = 12.dp))
                },
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Text("⋮", fontSize = 28.sp, modifier = Modifier.semantics { contentDescription = "Menu" })
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            MENU.forEach { entry ->
                                DropdownMenuItem(
                                    text = { Text(entry.second, fontWeight = if (screen == entry.first) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = { screen = entry.first; menuOpen = false }
                                )
                            }
                        }
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (screen) {
                "tasbih" -> TasbihScreen()
                "prayer" -> PrayerScreen()
                "analysis" -> AnalysisScreen()
                "background" -> BackgroundScreen(bg) { k, c, p, bmp -> bg = BgState(k, c, p, bmp) }
                "reminders" -> RemindersScreen()
                else -> HomeScreen(profile = profile, onProfileClick = { photoDialog = true })
            }
        }
    }
    }
}
