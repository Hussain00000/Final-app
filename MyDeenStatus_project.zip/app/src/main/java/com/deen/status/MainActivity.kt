package com.deen.status

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var image: ImageView
    private lateinit var caption: TextView
    private var list: List<Status> = BuiltIn.list
    private var index = 0
    private var current: Bitmap? = null
    private var token = 0

    private val prefs by lazy { getSharedPreferences("deen", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (12 * dp).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B1F18"))
        root.setPadding(pad, (28 * dp).toInt(), pad, pad)

        image = ImageView(this)
        image.scaleType = ImageView.ScaleType.FIT_CENTER
        root.addView(image, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        caption = TextView(this)
        caption.setTextColor(Color.parseColor("#E5C36A"))
        caption.gravity = Gravity.CENTER
        caption.setPadding(0, pad / 2, 0, pad / 2)
        root.addView(caption, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        root.addView(row(button("‹ Prev") { step(-1) }, button("Next ›") { step(1) }))
        root.addView(row(
            button("Share") { share() },
            button("Save") { save() },
            button("Live sheet") { askSheet() }
        ))
        setContentView(root)

        RemoteStatus.loadCache(this)?.let { list = it }
        index = RemoteStatus.pickIndex(list)
        render()
        refreshLive(false)
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(vararg buttons: Button): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (b in buttons) {
            r.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        return r
    }

    private fun step(d: Int) {
        index = ((index + d) % list.size + list.size) % list.size
        render()
    }

    private fun render() {
        val s = list[index % list.size]
        val my = ++token
        caption.text = "${index % list.size + 1} / ${list.size}   ${s.source}"
        Thread {
            val bg = RemoteStatus.background(this, s.bgUrl)
            val theme = StatusTheme.values().firstOrNull { it.name.equals(s.theme, true) }
            val bmp = StatusBackgrounds.render(
                this, s.arabic, s.text, s.source.ifBlank { null }, s.kind,
                themeOverride = theme, remoteBackground = bg
            )
            runOnUiThread {
                if (my == token) {
                    current = bmp
                    image.setImageBitmap(bmp)
                }
            }
        }.start()
    }

    private fun refreshLive(manual: Boolean) {
        val url = prefs.getString("sheet_url", "") ?: ""
        if (!url.startsWith("http")) {
            if (manual) toast("Paste a published Google Sheet CSV link first")
            return
        }
        Thread {
            val fresh = RemoteStatus.fetch(this, url)
            runOnUiThread {
                if (fresh != null && fresh.isNotEmpty()) {
                    list = fresh
                    index = RemoteStatus.pickIndex(fresh)
                    render()
                    if (manual) toast("Loaded ${fresh.size} statuses")
                } else if (manual) {
                    toast("Could not read that sheet link")
                }
            }
        }.start()
    }

    private fun askSheet() {
        val et = EditText(this)
        et.setText(prefs.getString("sheet_url", ""))
        et.hint = "Published CSV link from Google Sheets"
        et.inputType = InputType.TYPE_TEXT_VARIATION_URI
        AlertDialog.Builder(this)
            .setTitle("Live Google Sheet")
            .setView(et)
            .setPositiveButton("Save & load") { _, _ ->
                prefs.edit().putString("sheet_url", et.text.toString().trim()).apply()
                refreshLive(true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun saveImage(): Uri? {
        val bmp = current ?: return null
        val v = ContentValues()
        v.put(MediaStore.Images.Media.DISPLAY_NAME, "deen_status_${System.currentTimeMillis()}.png")
        v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MyDeenStatus")
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return uri
    }

    private fun save() {
        if (saveImage() != null) toast("Saved to Pictures/MyDeenStatus") else toast("Not ready yet")
    }

    private fun share() {
        val uri = saveImage()
        if (uri == null) { toast("Not ready yet"); return }
        val i = Intent(Intent.ACTION_SEND)
        i.type = "image/png"
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share status"))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
