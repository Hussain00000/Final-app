package com.example.mydeen

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** One online wallpaper (a photo from Wikimedia Commons). */
class OnlineWallpaper(val title: String, val url: String, val width: Int, val height: Int)

/**
 * Endless ready-made wallpapers from Wikimedia Commons (free, no account or key needed).
 * Each topic can be paged through again and again, so the list never really ends. Needs internet.
 */
object Wallpapers {
    const val PAGE = 30

    /** Label to show, search words to use. */
    val topics = listOf(
        "🕋 Makkah" to "Kaaba Masjid al-Haram",
        "🕌 Madinah" to "Masjid an-Nabawi Medina",
        "🕌 Mosques" to "mosque",
        "🌅 Sunset" to "mosque sunset",
        "🌙 Night" to "mosque night",
        "🏛 Architecture" to "Islamic architecture",
        "✨ Domes" to "mosque dome interior",
        "📖 Quran" to "Quran",
        "🖋 Calligraphy" to "Islamic calligraphy"
    )

    private const val UA = "MyDeenApp/1.0 (Android; Islamic status maker)"
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun cached(url: String): Bitmap? = cache.get(url)

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.setRequestProperty("User-Agent", UA)
        return c
    }

    private fun getText(url: String): String {
        val c = open(url)
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun getBytes(url: String): ByteArray? {
        return try {
            val c = open(url)
            try {
                if (c.responseCode != 200) null else c.inputStream.use { it.readBytes() }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Picture URL at a standard Wikimedia thumbnail width (falls back to the original file). */
    private fun sized(wp: OnlineWallpaper, wantWidth: Int): String {
        val marker = "/wikipedia/commons/"
        if (wantWidth >= wp.width || !wp.url.contains(marker)) return wp.url
        val name = wp.url.substringAfterLast('/')
        val path = wp.url.substringAfter(marker)
        return "https://upload.wikimedia.org/wikipedia/commons/thumb/$path/${wantWidth}px-$name"
    }

    fun thumbUrl(wp: OnlineWallpaper): String = sized(wp, 250)

    /** Returns the usable wallpapers of one page and how many raw results the page had (less than PAGE means the end). */
    fun search(query: String, offset: Int): Pair<List<OnlineWallpaper>, Int> {
        val api = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrnamespace=6&gsrlimit=$PAGE&gsroffset=$offset" +
            "&gsrsearch=" + URLEncoder.encode("$query filetype:bitmap", "UTF-8") +
            "&prop=imageinfo&iiprop=url%7Csize%7Cmime"
        val json = JSONObject(getText(api))
        val pages = json.optJSONObject("query")?.optJSONObject("pages") ?: return Pair(emptyList(), 0)
        val rows = ArrayList<Pair<Int, OnlineWallpaper>>()
        var raw = 0
        val keys = pages.keys()
        while (keys.hasNext()) {
            val p = pages.getJSONObject(keys.next())
            raw++
            val info = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            val w = info.optInt("width")
            val h = info.optInt("height")
            if (info.optString("mime") != "image/jpeg") continue
            if (w < 900 || h < 1200) continue                       // too small for a sharp status
            if (w.toFloat() / h.toFloat() > 2.2f) continue          // panoramas crop badly
            val title = p.optString("title").removePrefix("File:").substringBeforeLast('.')
            rows.add(Pair(p.optInt("index"), OnlineWallpaper(title, info.optString("url"), w, h)))
        }
        return Pair(rows.sortedBy { it.first }.map { it.second }, raw)
    }

    private fun decode(bytes: ByteArray, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    /** Small preview picture for the picker. */
    fun loadThumb(wp: OnlineWallpaper): Bitmap? {
        val key = thumbUrl(wp)
        cache.get(key)?.let { return it }
        return try {
            val bytes = getBytes(key) ?: getBytes(wp.url) ?: return null
            val bmp = decode(bytes, 400) ?: return null
            cache.put(key, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }

    /** Big picture used for the status (about 1280 to 1920 px wide). */
    fun downloadFull(wp: OnlineWallpaper): Bitmap? {
        return try {
            val need = maxOf(1080, (1920f * wp.width / wp.height).toInt())
            val width = if (need <= 1280) 1280 else 1920
            val bytes = getBytes(sized(wp, width)) ?: getBytes(wp.url) ?: return null
            decode(bytes, 2400)
        } catch (e: Exception) {
            null
        }
    }
}
