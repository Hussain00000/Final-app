package com.example.mydeen

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Random

/**
 * Endless Quran verses and hadith from free public sources (no key needed, internet required):
 *  - Quran: api.alquran.cloud (Arabic, transliteration in English letters, Sahih International English)
 *  - Hadith: the fawazahmed0 hadith-api on jsDelivr (Arabic, English). Urdu is only shown in Roman letters (built-in verses), never in Urdu script.
 * Only short ones that fit on a status picture are used.
 */
object OnlineVerses {
    private val rnd = Random()
    private const val UA = "MyDeenApp/1.0 (Android; Islamic status maker)"

    private class Collection(val id: String, val name: String, val max: Int)

    private val collections = listOf(
        Collection("bukhari", "Sahih al-Bukhari", 7000),
        Collection("muslim", "Sahih Muslim", 5000),
        Collection("tirmidhi", "Jami at-Tirmidhi", 3800),
        Collection("abudawud", "Sunan Abi Dawud", 5000),
        Collection("ibnmajah", "Sunan Ibn Majah", 4300),
        Collection("nasai", "Sunan an-Nasa'i", 5600)
    )

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", UA)
        try {
            if (c.responseCode != 200) throw java.io.IOException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun clean(s: String): String = s.replace(Regex("<[^>]*>"), "").replace(Regex("\\s+"), " ").trim()

    /** A new random verse or hadith. [filter] is "all", "quran" or "hadith". Null when nothing could be loaded. */
    fun random(filter: String): StatusVerse? {
        val wantQuran = when (filter) {
            "quran" -> true
            "hadith" -> false
            else -> rnd.nextBoolean()
        }
        val first = if (wantQuran) randomAyah() else randomHadith()
        if (first != null || filter != "all") return first
        return if (wantQuran) randomHadith() else randomAyah()
    }

    private fun randomAyah(): StatusVerse? {
        val deadline = System.currentTimeMillis() + 15000
        for (attempt in 0 until 12) {
            if (System.currentTimeMillis() > deadline) break
            try {
                val n = 1 + rnd.nextInt(6236)
                val json = JSONObject(get("https://api.alquran.cloud/v1/ayah/$n/editions/quran-uthmani,en.transliteration,en.sahih"))
                val arr = json.getJSONArray("data")
                var ar = ""; var ro = ""; var en = ""; var ur = ""
                var surahName = ""; var surahNo = 0; var inSurah = 0
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val text = clean(o.optString("text"))
                    when (o.getJSONObject("edition").optString("identifier")) {
                        "quran-uthmani" -> ar = text
                        "en.transliteration" -> ro = text
                        "en.sahih" -> en = text
                    }
                    val surah = o.optJSONObject("surah")
                    if (surah != null) {
                        surahName = surah.optString("englishName")
                        surahNo = surah.optInt("number")
                    }
                    inSurah = o.optInt("numberInSurah")
                }
                if (inSurah == 1 && surahNo != 1) continue          // first verses carry the Bismillah in the text
                if (ar.isEmpty() || en.isEmpty() || ro.isEmpty()) continue   // Roman English is required
                if (ar.length > 230 || en.length > 330) continue    // too long for one status
                return StatusVerse(ar, ro, en, ur, "Surah $surahName $surahNo:$inSurah", true)
            } catch (e: Exception) {
                // try another verse
            }
        }
        return null
    }

    private fun hadithText(json: String): String {
        val root = JSONObject(json)
        val obj = root.optJSONArray("hadiths")?.optJSONObject(0) ?: root
        return clean(obj.optString("text"))
    }

    private fun randomHadith(): StatusVerse? {
        val deadline = System.currentTimeMillis() + 18000
        for (attempt in 0 until 40) {
            if (System.currentTimeMillis() > deadline) break
            try {
                val col = collections[rnd.nextInt(collections.size)]
                val n = 1 + rnd.nextInt(col.max)
                val base = "https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/"
                val en = hadithText(get("${base}eng-${col.id}/$n.json"))
                if (en.isEmpty() || en.length > 320) continue
                val ar = hadithText(get("${base}ara-${col.id}/$n.json"))
                if (ar.isEmpty() || ar.length > 260) continue
                if (Transliterator.coverage(ar) < 0.7) continue           // not vowelled: Roman English would be wrong
                val ro = Transliterator.toRoman(ar)
                if (ro.isBlank()) continue
                return StatusVerse(ar, ro, en, "", "${col.name} $n", false)
            } catch (e: Exception) {
                // try another hadith
            }
        }
        return null
    }
}
