package com.example.mydeen

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar
import java.util.Locale

data class ReminderItem(
    val id: Int,
    val title: String,
    val body: String,
    val taskIndex: Int,
    val defHour: Int,
    val defMinute: Int,
    val defOn: Boolean
)

object Reminder {
    const val CHANNEL = "my_deen_reminders"
    const val MUHASABAH_ID = 900
    private const val TASK_BASE = 1000

    private val defaultTimes = mapOf(
        "Tahajjud" to Pair(3, 30), "Ishraq" to Pair(6, 30), "Chasht" to Pair(10, 0), "Awwabin" to Pair(18, 30)
    )

    /**
     * Reminder ids are kept stable across app versions (they used to be the task's position in the list),
     * so alarms and times you already set keep belonging to the same task when tasks are added or removed.
     */
    private val legacyOrder = listOf(
        "5 daily Salah with Takbir", "Sunnat-e-Muakkadah", "Tahajjud", "Ishraq", "Chasht", "Awwabin",
        "Umari Qaza", "3 Tasbeeh — first daily entry", "3 Tasbeeh — second daily entry", Tasks.DUROOD_TITLE,
        "Quran — 1 Juz", "Quran Taleem", "Ghar ki Taleem", Tasks.TIMER_TITLE,
        "Avoid Ghibat (backbiting)", "Ghar Ghar Mulakhatan", "Daily personal hygiene"
    )
    /** Ids of tasks that were removed from the tracker; their old alarms are cancelled. */
    private val removedIds = listOf(TASK_BASE + 6, TASK_BASE + 14, TASK_BASE + 16)

    private fun taskId(title: String, index: Int): Int {
        val legacy = legacyOrder.indexOf(title)
        return TASK_BASE + if (legacy >= 0) legacy else 100 + index
    }

    /** Nightly Muhasabah first, then one reminder per checklist task (Qaza namaz tick boxes have none). */
    val items: List<ReminderItem> = listOf(
        ReminderItem(MUHASABAH_ID, "Nightly Muhasabah", "Time for nightly Muhasabah — finish your checklist and reflect on your day.", -1, 21, 30, true)
    ) + Tasks.all.withIndex().filter { it.value.reminder }.map { (i, t) ->
        val d = defaultTimes[t.title] ?: Pair(8, 0)
        ReminderItem(taskId(t.title, i), t.title, "Reminder: ${t.title}", i, d.first, d.second, false)
    }

    fun createChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Deen task reminders", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Reminders for your daily Deen tasks and nightly Muhasabah"
        })
    }

    fun isOn(p: SharedPreferences, item: ReminderItem): Boolean = p.getBoolean("rem_on_${item.id}", item.defOn)
    fun hourOf(p: SharedPreferences, item: ReminderItem): Int = p.getInt("rem_h_${item.id}", item.defHour)
    fun minuteOf(p: SharedPreferences, item: ReminderItem): Int = p.getInt("rem_m_${item.id}", item.defMinute)

    fun timeText(h: Int, m: Int): String {
        val ampm = if (h >= 12) "PM" else "AM"
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format(Locale.US, "%d:%02d %s", h12, m, ampm)
    }

    fun update(context: Context, item: ReminderItem, on: Boolean, h: Int, m: Int) {
        Store.prefs(context).edit()
            .putBoolean("rem_on_${item.id}", on)
            .putInt("rem_h_${item.id}", h)
            .putInt("rem_m_${item.id}", m)
            .apply()
        if (on) schedule(context, item) else cancel(context, item)
    }

    fun scheduleAll(context: Context) {
        val p = Store.prefs(context)
        removedIds.forEach { id -> cancel(context, ReminderItem(id, "", "", -1, 0, 0, false)) }
        items.forEach { if (isOn(p, it)) schedule(context, it) else cancel(context, it) }
    }

    private fun makePending(context: Context, item: ReminderItem, flag: Int): PendingIntent? {
        val intent = Intent(context, ReminderReceiver::class.java).apply { putExtra("id", item.id) }
        return PendingIntent.getBroadcast(context, item.id, intent, flag or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(context: Context, item: ReminderItem) {
        val p = Store.prefs(context)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hourOf(p, item))
            set(Calendar.MINUTE, minuteOf(p, item))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val pending = makePending(context, item, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarm.canScheduleExactAlarms()
        if (exactAllowed) {
            try {
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
            } catch (e: SecurityException) {
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
            }
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
        }
    }

    fun cancel(context: Context, item: ReminderItem) {
        val pending = makePending(context, item, PendingIntent.FLAG_NO_CREATE) ?: return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pending)
        pending.cancel()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val item = Reminder.items.firstOrNull { it.id == id } ?: return
        val p = Store.prefs(context)
        val day = Store.dayKey()
        // Don't nag about something that is already finished today.
        val finished = if (item.taskIndex >= 0) Store.isDone(p, day, Tasks.all[item.taskIndex]) else Store.isSubmitted(p, day)
        if (!finished) {
            Reminder.createChannel(context)
            val open = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = NotificationCompat.Builder(context, Reminder.CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(item.title)
                .setContentText(item.body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(item.body))
                .setContentIntent(open)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            context.getSystemService(NotificationManager::class.java).notify(id, notification)
        }
        // Set up tomorrow's alarm.
        if (Reminder.isOn(p, item)) Reminder.schedule(context, item)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { Reminder.scheduleAll(context) }
}
