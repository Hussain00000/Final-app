package com.example.mydeen

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Gold = Color(0xFFFFC857)
private val Ink = Color(0xFF041A13)

private val statusBgLabels = listOf("Makkah\nDay", "Makkah\nNight", "Madinah\nDay", "Madinah\nNight")

/** Menu screen: one Islamic teaching for every day, with an Arabic verse / hadees on top, on a Makkah or Madinah background. Shareable as an image (WhatsApp status etc.) or text. */
@Composable
fun StatusScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var offset by remember { mutableIntStateOf(0) }
    var bgIdx by remember { mutableIntStateOf(prefs.getInt("status_bg", 0).coerceIn(0, Bg.presets.size - 1)) }
    val date = LocalDate.now().plusDays(offset.toLong())
    val st = DailyStatuses.forDay(date.toEpochDay())
    val dateText = date.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()))

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(if (offset == 0) "Today’s Islamic Status" else "Islamic Status", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)

        // Preview card (9:16, same look as the shared image)
        Box(Modifier.fillMaxWidth().aspectRatio(9f / 16f).clip(RoundedCornerShape(20.dp)).background(Ink)) {
            Image(painterResource(Bg.presets[bgIdx].res), contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
            Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(Ink.copy(alpha = 0.85f), Ink.copy(alpha = 0.15f), Ink.copy(alpha = 0.15f), Ink.copy(alpha = 0.55f)))))
            Column(Modifier.matchParentSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                // Arabic at the top
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.width(60.dp).height(2.dp).background(Gold))
                    if (st.arabic.isNotEmpty()) {
                        Text(st.arabic, color = Color.White, fontSize = 24.sp, lineHeight = 40.sp, textAlign = TextAlign.Center)
                        Text("— ${st.arabicSource}", color = Gold, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                    Box(Modifier.width(60.dp).height(2.dp).background(Gold))
                }
                // Translation at the bottom
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Ink.copy(alpha = 0.65f)).padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(st.type, color = Gold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(st.roman, color = Color.White, fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Text(st.english, color = Color(0xFFD9E6DF), fontSize = 13.sp, fontStyle = FontStyle.Italic, textAlign = TextAlign.Center)
                    Text("— ${st.source}", color = Gold, fontSize = 12.sp, textAlign = TextAlign.Center)
                    Text(dateText, color = Color(0xAAFFFFFF), fontSize = 11.sp)
                }
            }
        }

        Text("Background", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Bg.presets.forEachIndexed { i, preset ->
                val sel = i == bgIdx
                Column(
                    Modifier.weight(1f).clickable { bgIdx = i; prefs.edit().putInt("status_bg", i).apply() },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Image(
                        painterResource(preset.res), contentDescription = preset.label, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().aspectRatio(0.62f).clip(RoundedCornerShape(10.dp))
                            .border(BorderStroke(if (sel) 3.dp else 1.dp, if (sel) Gold else Color(0x55000000)), RoundedCornerShape(10.dp))
                    )
                    Text(statusBgLabels.getOrElse(i) { preset.label }, fontSize = 11.sp, textAlign = TextAlign.Center, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { offset -= 1 }, modifier = Modifier.weight(1f)) { Text("◀ Previous") }
            OutlinedButton(onClick = { offset = 0 }, enabled = offset != 0, modifier = Modifier.weight(1f)) { Text("Today") }
            OutlinedButton(onClick = { offset += 1 }, modifier = Modifier.weight(1f)) { Text("Next ▶") }
        }
        Button(onClick = { shareStatusImage(context, st, dateText, Bg.presets[bgIdx].res) }, modifier = Modifier.fillMaxWidth()) { Text("Share as image (status)") }
        OutlinedButton(onClick = { shareStatusText(context, st, dateText) }, modifier = Modifier.fillMaxWidth()) { Text("Share as text") }
        Text("A new teaching appears every day.", style = MaterialTheme.typography.bodySmall)
    }
}

private fun shareStatusText(context: Context, st: DailyStatus, dateText: String) {
    val body = buildString {
        append("Islamic Status — ").append(dateText).append("\n\n")
        if (st.arabic.isNotEmpty()) append(st.arabic).append("\n— ").append(st.arabicSource).append("\n\n")
        append(st.roman).append("\n\n").append(st.english).append("\n\n— ").append(st.source)
        append("\n\nShared from My Deeni Tracker")
    }
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, body)
    }
    context.startActivity(Intent.createChooser(send, "Share status").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private fun shareStatusImage(context: Context, st: DailyStatus, dateText: String, bgRes: Int) {
    try {
        val bmp = buildStatusImage(context, st, dateText, bgRes)
        val dir = File(context.cacheDir, "status").apply { mkdirs() }
        val file = File(dir, "islamic_status.png")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, (if (st.arabic.isNotEmpty()) st.arabic + "\n\n" else "") + st.roman + "\n\n— " + st.source)
            clipData = ClipData.newRawUri("status", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, "Share status").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(context, "Could not create the image. Try Share as text.", Toast.LENGTH_LONG).show()
    }
}

/** Draws a 1080x1920 (9:16) status: Makkah/Madinah picture, Arabic verse/hadees at the top, translation at the bottom. */
private fun buildStatusImage(context: Context, st: DailyStatus, dateText: String, bgRes: Int): Bitmap {
    val w = 1080
    val h = 1920
    val pad = 90
    val cw = w - 2 * pad
    val gold = 0xFFFFC857.toInt()
    val white = 0xFFFFFFFF.toInt()
    val soft = 0xFFD9E6DF.toInt()
    val ink = 0xFF041A13.toInt()

    fun layout(text: String, size: Float, color: Int, width: Int, bold: Boolean = false, italic: Boolean = false, spacing: Float = 1.2f): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.textSize = size
        tp.color = color
        val style = when {
            bold && italic -> Typeface.BOLD_ITALIC
            bold -> Typeface.BOLD
            italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        tp.typeface = Typeface.create(Typeface.DEFAULT, style)
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, spacing)
            .build()
    }

    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)

    // 1. Background picture, centre-cropped to fill 9:16
    val src = BitmapFactory.decodeResource(context.resources, bgRes)
    if (src != null) {
        val scale = maxOf(w / src.width.toFloat(), h / src.height.toFloat())
        val dw = src.width * scale
        val dh = src.height * scale
        c.drawBitmap(src, null, RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f), Paint(Paint.FILTER_BITMAP_FLAG))
    } else {
        c.drawColor(ink)
    }

    // 2. Dark fades at the top and bottom so the text is easy to read
    val fade = Paint()
    fade.shader = LinearGradient(0f, 0f, 0f, 760f, 0xE6041A13.toInt(), 0x00041A13, Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, w.toFloat(), 760f, fade)
    fade.shader = LinearGradient(0f, 1100f, 0f, h.toFloat(), 0x00041A13, 0xE6041A13.toInt(), Shader.TileMode.CLAMP)
    c.drawRect(0f, 1100f, w.toFloat(), h.toFloat(), fade)

    val line = Paint(Paint.ANTI_ALIAS_FLAG)
    line.color = gold

    // 3. Arabic at the top (shrinks to fit long hadees)
    var arSize = 74f
    var arabic: StaticLayout? = null
    if (st.arabic.isNotEmpty()) {
        arabic = layout(st.arabic, arSize, white, cw, spacing = 1.35f)
        while (arabic!!.height > 560 && arSize > 40f) {
            arSize -= 4f
            arabic = layout(st.arabic, arSize, white, cw, spacing = 1.35f)
        }
    }
    var y = 120f
    c.drawRect((w / 2f) - 70f, y, (w / 2f) + 70f, y + 5f, line)
    y += 50f
    if (arabic != null) {
        c.save(); c.translate(pad.toFloat(), y); arabic.draw(c); c.restore()
        y += arabic.height + 24f
        val ref = layout("— " + st.arabicSource, 32f, gold, cw)
        c.save(); c.translate(pad.toFloat(), y); ref.draw(c); c.restore()
        y += ref.height + 30f
    }
    c.drawRect((w / 2f) - 70f, y, (w / 2f) + 70f, y + 5f, line)

    // 4. Translation in a soft panel at the bottom (shrinks to fit)
    val panelX = 60f
    val panelW = w - 2 * panelX
    val innerW = (panelW - 100f).toInt()
    val maxPanelH = 800
    var k = 1.0f
    var parts: List<Pair<StaticLayout, Int>>
    var total: Int
    do {
        parts = listOf(
            Pair(layout(st.type, 34f * k, gold, innerW, bold = true), (30 * k).toInt()),
            Pair(layout(st.roman, 46f * k, white, innerW, bold = true), (30 * k).toInt()),
            Pair(layout(st.english, 36f * k, soft, innerW, italic = true), (30 * k).toInt()),
            Pair(layout("— " + st.source, 32f * k, gold, innerW), 0)
        )
        total = parts.sumOf { it.first.height + it.second } + 100
        k -= 0.05f
    } while (total > maxPanelH && k > 0.4f)

    val panelBottom = h - 190f
    val panelTop = panelBottom - total
    val panel = Paint(Paint.ANTI_ALIAS_FLAG)
    panel.color = 0xB3041A13.toInt()
    c.drawRoundRect(RectF(panelX, panelTop, panelX + panelW, panelBottom), 40f, 40f, panel)
    panel.style = Paint.Style.STROKE
    panel.strokeWidth = 3f
    panel.color = 0x99FFC857.toInt()
    c.drawRoundRect(RectF(panelX, panelTop, panelX + panelW, panelBottom), 40f, 40f, panel)

    var ty = panelTop + 50f
    for (p in parts) {
        c.save()
        c.translate(panelX + 50f, ty)
        p.first.draw(c)
        c.restore()
        ty += p.first.height + p.second
    }

    // 5. Footer
    val foot = TextPaint(Paint.ANTI_ALIAS_FLAG)
    foot.textAlign = Paint.Align.CENTER
    foot.textSize = 28f
    foot.color = soft
    c.drawText(dateText, w / 2f, (h - 120).toFloat(), foot)
    foot.color = gold
    foot.typeface = Typeface.DEFAULT_BOLD
    c.drawText("My Deeni Tracker", w / 2f, (h - 70).toFloat(), foot)
    return bmp
}
