package com.example.mydeen

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private class DayStat(val key: String, val cal: Calendar, val pct: Int, val submitted: Boolean, val future: Boolean)

private fun buildDays(p: SharedPreferences, mode: Int, offset: Int, todayKey: String): List<DayStat> {
    val start = Calendar.getInstance()
    val count: Int
    if (mode == 0) {
        start.add(Calendar.DAY_OF_YEAR, offset * 7 - 6)
        count = 7
    } else {
        start.set(Calendar.DAY_OF_MONTH, 1)
        start.add(Calendar.MONTH, offset)
        count = start.getActualMaximum(Calendar.DAY_OF_MONTH)
    }
    val out = ArrayList<DayStat>()
    for (i in 0 until count) {
        val c = start.clone() as Calendar
        c.add(Calendar.DAY_OF_YEAR, i)
        val key = Store.dayKey(c)
        val future = key > todayKey
        out.add(DayStat(key, c, if (future) 0 else Store.percent(p, key), Store.isSubmitted(p, key), future))
    }
    return out
}

private fun fmt(pattern: String): SimpleDateFormat = SimpleDateFormat(pattern, Locale.getDefault())

@Composable
fun AnalysisScreen() {
    val context = LocalContext.current
    val prefs = remember { Store.prefs(context) }
    var mode by remember { mutableIntStateOf(0) }
    var offset by remember { mutableIntStateOf(0) }
    val todayKey = Store.dayKey()
    val days = remember(mode, offset) { buildDays(prefs, mode, offset, todayKey) }
    val past = days.filter { !it.future }
    val avg = if (past.isEmpty()) 0 else past.sumOf { it.pct } / past.size
    val best = past.maxByOrNull { it.pct }
    val perfect = past.count { it.pct == 100 }
    val submittedCount = past.count { it.submitted }
    val perTask = remember(days) { Tasks.all.map { t -> Pair(t, past.count { d -> Store.isDone(prefs, d.key, t) }) } }
    val label = if (mode == 0) {
        fmt("MMM d").format(days.first().cal.time) + " – " + fmt("MMM d").format(days.last().cal.time)
    } else {
        fmt("MMMM yyyy").format(days.first().cal.time)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 32.dp)
    ) {
        item {
            TabRow(selectedTabIndex = mode, containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.primary) {
                Tab(selected = mode == 0, onClick = { mode = 0; offset = 0 }, text = { Text("Weekly") })
                Tab(selected = mode == 1, onClick = { mode = 1; offset = 0 }, text = { Text("Monthly") })
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { offset-- }) { Text("‹ Previous") }
                Text(label, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { offset++ }, enabled = offset < 0) { Text("Next ›") }
            }
        }
        item {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (mode == 0) "Daily completion" else "Month at a glance", style = MaterialTheme.typography.titleMedium)
                    if (mode == 0) WeekBars(days) else MonthGrid(days)
                }
            }
        }
        item {
            DeenCard(color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Summary", style = MaterialTheme.typography.titleMedium)
                    Text("$avg%", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("average completion over ${past.size} day(s)")
                    if (best != null) Text("Best day: " + fmt("EEE, MMM d").format(best.cal.time) + " (" + best.pct + "%)")
                    Text("Perfect days (100%): $perfect")
                    Text("Days submitted: $submittedCount of ${past.size}")
                }
            }
        }
        item {
            Text("Activity breakdown", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        }
        items(perTask, key = { it.first.title }) { entry ->
            val n = entry.second
            val m = past.size
            DeenCard {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth()) {
                        Text(entry.first.title, modifier = Modifier.weight(1f))
                        Text("$n / $m days")
                    }
                    LinearProgressIndicator(progress = { if (m == 0) 0f else n.toFloat() / m.toFloat() }, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun WeekBars(days: List<DayStat>) {
    val dayFmt = remember { fmt("EEE") }
    Row(
        Modifier.fillMaxWidth().height(190.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        days.forEach { d ->
            val name = dayFmt.format(d.cal.time)
            val status = if (d.future) "upcoming" else d.pct.toString() + " percent"
            val desc = name + ": " + status + (if (d.submitted) ", submitted" else "")
            Column(
                Modifier.weight(1f).fillMaxHeight().semantics(mergeDescendants = true) { contentDescription = desc },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(if (d.future) "" else d.pct.toString(), fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                if (!d.future) {
                    Box(
                        Modifier.fillMaxWidth().height((d.pct * 1.2f).coerceAtLeast(3f).dp)
                            .background(DeenGreen, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(name, fontSize = 11.sp, maxLines = 1)
                Text(if (d.submitted) "✓" else " ", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun MonthGrid(days: List<DayStat>) {
    val lead = days.first().cal.get(Calendar.DAY_OF_WEEK) - 1
    val cells = ArrayList<DayStat?>()
    repeat(lead) { cells.add(null) }
    cells.addAll(days)
    while (cells.size % 7 != 0) cells.add(null)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf("S", "M", "T", "W", "T", "F", "S").forEach { Text(it, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold) }
    }
    cells.chunked(7).forEach { week ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            week.forEach { d ->
                if (d == null) {
                    Spacer(Modifier.weight(1f).aspectRatio(1f))
                } else {
                    DayCell(d, Modifier.weight(1f))
                }
            }
        }
    }
    Text("Darker green = more activities completed. ✓ = day submitted.", style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun DayCell(d: DayStat, modifier: Modifier) {
    val bg = if (d.future) Color.Transparent else DeenGreen.copy(alpha = 0.12f + 0.88f * d.pct / 100f)
    val fg = if (!d.future && d.pct >= 50) Color.White else DeenInk
    val dayNum = d.cal.get(Calendar.DAY_OF_MONTH)
    val status = if (d.future) "upcoming" else d.pct.toString() + " percent"
    val desc = fmt("MMMM d").format(d.cal.time) + ": " + status + (if (d.submitted) ", submitted" else "")
    Box(
        modifier.aspectRatio(1f).background(bg, RoundedCornerShape(8.dp)).semantics(mergeDescendants = true) { contentDescription = desc },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (d.submitted) "${dayNum}✓" else dayNum.toString(), color = fg, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            if (!d.future) Text("${d.pct}%", color = fg, fontSize = 10.sp)
        }
    }
}
