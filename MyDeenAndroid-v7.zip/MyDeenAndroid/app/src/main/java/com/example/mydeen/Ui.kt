package com.example.mydeen

import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

val DeenGreen = Color(0xFF1B5E20)
val DeenInk = Color(0xFF10281A)

private val GreenScheme = lightColorScheme(
    primary = DeenGreen, onPrimary = Color.White,
    primaryContainer = Color(0xFFB5DEBC), onPrimaryContainer = DeenInk,
    secondary = Color(0xFF2E7D32), onSecondary = Color.White,
    secondaryContainer = Color(0xFFA5D6AD), onSecondaryContainer = DeenInk,
    tertiary = Color(0xFF00695C), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFB2DFDB), onTertiaryContainer = DeenInk,
    background = Color(0xFFCDE9D1), onBackground = DeenInk,
    surface = Color(0xFFF3FAF4), onSurface = DeenInk,
    surfaceVariant = Color(0xFFDCEBDE), onSurfaceVariant = Color(0xFF2F4A38),
    surfaceTint = DeenGreen,
    outline = Color(0xFF4F7058), outlineVariant = Color(0xFFB0CDB5),
    surfaceBright = Color(0xFFF3FAF4), surfaceDim = Color(0xFFC3DCC8),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF3FAF4),
    surfaceContainer = Color(0xFFEAF5EC), surfaceContainerHigh = Color(0xFFE3F1E6), surfaceContainerHighest = Color(0xFFDCEBDE)
)

@Composable
fun MyDeenTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = GreenScheme, content = content)
}

@Composable
fun DeenCard(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = color, contentColor = MaterialTheme.colorScheme.onSurface),
        content = content
    )
}
