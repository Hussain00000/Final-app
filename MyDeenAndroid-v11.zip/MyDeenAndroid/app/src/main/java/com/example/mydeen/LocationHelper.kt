package com.example.mydeen

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper

object LocationHelper {
    /** Calls onResult on the main thread with a location, or null if none could be found. */
    @SuppressLint("MissingPermission")
    fun fetch(context: Context, preferFresh: Boolean, onResult: (Location?) -> Unit) {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers: List<String> = try { lm.getProviders(true) } catch (e: Exception) { emptyList() }
        var best: Location? = null
        for (p in providers) {
            val l: Location? = try { lm.getLastKnownLocation(p) } catch (e: Exception) { null }
            val current = best
            if (l != null && (current == null || l.time > current.time)) best = l
        }
        val last = best
        if (last != null && !preferFresh) { onResult(last); return }

        val provider: String? = when {
            providers.contains(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            providers.contains(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) { onResult(last); return }

        val handler = Handler(Looper.getMainLooper())
        var finished = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (finished) return
                finished = true
                handler.removeCallbacksAndMessages(null)
                onResult(location)
            }
            override fun onStatusChanged(name: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(name: String) {}
            override fun onProviderDisabled(name: String) {}
        }
        try {
            lm.requestSingleUpdate(provider, listener, Looper.getMainLooper())
        } catch (e: Exception) {
            onResult(last)
            return
        }
        handler.postDelayed({
            if (!finished) {
                finished = true
                try { lm.removeUpdates(listener) } catch (e: Exception) { }
                onResult(last)
            }
        }, 20000L)
    }
}
