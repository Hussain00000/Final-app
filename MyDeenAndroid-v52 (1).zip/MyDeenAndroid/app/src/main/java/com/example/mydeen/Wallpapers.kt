package com.example.mydeen

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** One online wallpaper (a photo from Wikimedia Commons). */
class OnlineWallpaper(
    val title: String, val url: String, val width: Int, val height: Int,
    val thumb: String? = null, val full: String? = null   // ready-made picture links (Pexels)
)

/**
 * Endless ready-made wallpapers. With a free Pixabay or Pexels key the search is fast and gives tall (portrait) photos;
 * without a key it uses Wikimedia Commons (free, no key, but slower).
 * Each topic can be paged through again and again, so the list never really ends. Needs internet.
 */
object Wallpapers {
    const val PAGE = 30

    /** Pixabay key used for fast search. */
    const val API_KEY = "58672578-9c21ca25c33a3d03a27cc30a2"

    /** Label to show, search words to use. */
    val topics = listOf(
        "🕋 Makkah" to "Kaaba Masjid al-Haram",
        "🕌 Madinah" to "Masjid an-Nabawi Medina",
        "🕌 Mosques" to "mosque",
        "🌅 Sunset" to "mosque sunset",
        "🌙 Night" to "mosque night",
        "🏛 Architecture" to "Islamic architecture",
        "✨ Domes" to "mosque dome interior",
        "📖 Quran" to "Quran",
        "🖋 Calligraphy" to "Islamic calligraphy"
    )

    private const val UA = "MyDeenApp/1.0 (Android; Islamic status maker)"
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun cached(url: String): Bitmap? = cache.get(url)

    private val searchCache = HashMap<String, Pair<List<OnlineWallpaper>, Int>>()

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", UA)
        return c
    }

    private fun getText(url: String): String {
        val c = open(url)
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun getBytes(url: String): ByteArray? {
        return try {
            val c = open(url)
            try {
                if (c.responseCode != 200) null else c.inputStream.use { it.readBytes() }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Picture URL at a standard Wikimedia thumbnail width (falls back to the original file). */
    private fun sized(wp: OnlineWallpaper, wantWidth: Int): String {
        val marker = "/wikipedia/commons/"
        if (wantWidth >= wp.width || !wp.url.contains(marker)) return wp.url
        val name = wp.url.substringAfterLast('/')
        val path = wp.url.substringAfter(marker)
        return "https://upload.wikimedia.org/wikipedia/commons/thumb/$path/${wantWidth}px-$name"
    }

    fun thumbUrl(wp: OnlineWallpaper): String = wp.thumb ?: sized(wp, 250)

    /** Returns the usable wallpapers of one page and how many raw results the page had (less than PAGE means the end). */
    fun search(query: String, offset: Int, apiKey: String = ""): Pair<List<OnlineWallpaper>, Int> {
        val cacheKey = "$query|$offset|${apiKey.isNotBlank()}"
        synchronized(searchCache) { searchCache[cacheKey] }?.let { return it }
        val key = apiKey.trim()
        val result = when {
            key.isBlank() -> searchOnline(query, offset)
            isPixabayKey(key) -> searchPixabay(query, offset, key)
            else -> searchPexels(query, offset, key)
        }
        synchronized(searchCache) { searchCache[cacheKey] = result }
        return result
    }

    /** Pixabay keys look like 12345678-0123456789abcdef01234567; Pexels keys are a long mix of letters and numbers. */
    private fun isPixabayKey(key: String): Boolean = Regex("^\\d+-[0-9a-fA-F]+$").matches(key)

    /** Fast search on Pixabay (needs the free key): tall photos, safe search on. */
    private fun searchPixabay(query: String, offset: Int, apiKey: String): Pair<List<OnlineWallpaper>, Int> {
        val page = offset / PAGE + 1
        val api = "https://pixabay.com/api/?key=" + URLEncoder.encode(apiKey, "UTF-8") +
            "&q=" + URLEncoder.encode(query.take(100), "UTF-8") +
            "&image_type=photo&orientation=vertical&safesearch=true&min_height=1200&per_page=$PAGE&page=$page"
        val c = open(api)
        val text = try {
            if (c.responseCode != 200) throw java.io.IOException("Pixabay error " + c.responseCode)
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
        val hits = JSONObject(text).optJSONArray("hits") ?: return Pair(emptyList(), 0)
        val list = ArrayList<OnlineWallpaper>()
        for (i in 0 until hits.length()) {
            val h = hits.getJSONObject(i)
            val large = h.optString("largeImageURL")
            val web = h.optString("webformatURL")
            if (large.isEmpty() || web.isEmpty()) continue
            val title = h.optString("tags").ifBlank { "Pixabay photo" }
            list.add(OnlineWallpaper(title, large, h.optInt("imageWidth"), h.optInt("imageHeight"), web.replace("_640", "_340"), large))
        }
        return Pair(list, hits.length())
    }

    /** Fast search on Pexels (needs the free key): tall photos, one small answer. */
    private fun searchPexels(query: String, offset: Int, apiKey: String): Pair<List<OnlineWallpaper>, Int> {
        val page = offset / PAGE + 1
        val api = "https://api.pexels.com/v1/search?query=" + URLEncoder.encode(query, "UTF-8") +
            "&orientation=portrait&per_page=$PAGE&page=$page"
        val c = open(api)
        c.setRequestProperty("Authorization", apiKey)
        val text = try {
            if (c.responseCode != 200) throw java.io.IOException("Pexels error " + c.responseCode)
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
        val photos = JSONObject(text).optJSONArray("photos") ?: return Pair(emptyList(), 0)
        val list = ArrayList<OnlineWallpaper>()
        for (i in 0 until photos.length()) {
            val ph = photos.getJSONObject(i)
            val src = ph.optJSONObject("src") ?: continue
            val portrait = src.optString("portrait")
            if (portrait.isEmpty()) continue
            val full = portrait.replace("h=1200", "h=1920").replace("w=800", "w=1080")
            val title = ph.optString("alt").ifBlank { "Pexels photo" }
            list.add(OnlineWallpaper(title, src.optString("original", portrait), ph.optInt("width"), ph.optInt("height"), src.optString("medium", portrait), full))
        }
        return Pair(list, photos.length())
    }

    private fun searchOnline(query: String, offset: Int): Pair<List<OnlineWallpaper>, Int> {
        val api = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrnamespace=6&gsrlimit=$PAGE&gsroffset=$offset" +
            "&gsrsearch=" + URLEncoder.encode("$query filetype:bitmap", "UTF-8") +
            "&prop=imageinfo&iiprop=url%7Csize%7Cmime"
        val json = JSONObject(getText(api))
        val pages = json.optJSONObject("query")?.optJSONObject("pages") ?: return Pair(emptyList(), 0)
        val rows = ArrayList<Pair<Int, OnlineWallpaper>>()
        var raw = 0
        val keys = pages.keys()
        while (keys.hasNext()) {
            val p = pages.getJSONObject(keys.next())
            raw++
            val info = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            val w = info.optInt("width")
            val h = info.optInt("height")
            if (info.optString("mime") != "image/jpeg") continue
            if (w < 900 || h < 1200) continue                       // too small for a sharp status
            if (w.toFloat() / h.toFloat() > 2.2f) continue          // panoramas crop badly
            val title = p.optString("title").removePrefix("File:").substringBeforeLast('.')
            rows.add(Pair(p.optInt("index"), OnlineWallpaper(title, info.optString("url"), w, h)))
        }
        return Pair(rows.sortedBy { it.first }.map { it.second }, raw)
    }

    private fun decode(bytes: ByteArray, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    /** Small preview picture for the picker. */
    fun loadThumb(wp: OnlineWallpaper): Bitmap? {
        val key = thumbUrl(wp)
        cache.get(key)?.let { return it }
        return try {
            val bytes = getBytes(key) ?: getBytes(wp.url) ?: return null
            val bmp = decode(bytes, 400) ?: return null
            cache.put(key, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }

    /** Big picture used for the status (about 1280 to 1920 px wide). */
    fun downloadFull(wp: OnlineWallpaper): Bitmap? {
        return try {
            val need = maxOf(1080, (1920f * wp.width / wp.height).toInt())
            val width = if (need <= 1280) 1280 else 1920
            val bytes = (wp.full?.let { getBytes(it) }) ?: getBytes(sized(wp, width)) ?: getBytes(wp.url) ?: return null
            decode(bytes, 2400)
        } catch (e: Exception) {
            null
        }
    }
}
