package com.example.mydeen

import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.android.gms.auth.api.identity.Identity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Gmail account + backup/restore. Everything is saved to the person's own Gmail as an email to themselves. */
object Account {
    private const val MARK = "MYDEEN-BACKUP-V1"
    private val EXCLUDED = setOf("account_email", "account_name", "account_drive", "drive_last")

    fun email(context: Context): String = Store.prefs(context).getString("account_email", "") ?: ""
    fun name(context: Context): String = Store.prefs(context).getString("account_name", "") ?: ""
    fun phone(context: Context): String = Store.prefs(context).getString("account_phone", "") ?: ""

    fun signIn(context: Context, email: String, name: String) {
        Store.prefs(context).edit().putString("account_email", email.trim().lowercase(Locale.US)).putString("account_name", name).apply()
    }

    fun signOut(context: Context) {
        Store.prefs(context).edit().remove("account_email").remove("account_name").remove("account_drive").remove("drive_last").apply()
        DriveBackup.cancel(context)
    }

    fun savePhone(context: Context, number: String) { Store.prefs(context).edit().putString("account_phone", number).apply() }

    /** Accepts 10 to 15 digits with an optional leading +; spaces and dashes are ignored. */
    fun cleanPhone(raw: String): String? {
        val x = raw.replace(" ", "").replace("-", "")
        return if (Regex("^\\+?[0-9]{10,15}$").matches(x)) x else null
    }

    fun hasLocalData(context: Context): Boolean {
        val re = Regex("^\\d{4}-\\d{2}-\\d{2}:")
        return Store.prefs(context).all.keys.any { re.containsMatchIn(it) }
    }

    /** All saved data (checklist, tasbih, timer, settings…) as one JSON text. */
    fun export(context: Context): String {
        val root = JSONObject()
        for ((k, v) in Store.prefs(context).all) {
            if (k in EXCLUDED) continue
            val o = JSONObject()
            when (v) {
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Set<*> -> { o.put("t", "set"); o.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            root.put(k, o)
        }
        return root.toString()
    }

    /** Returns how many items were restored, or -1 if the text is not a valid backup. */
    fun restore(context: Context, text: String): Int {
        return try {
            val a = text.indexOf('{')
            val b = text.lastIndexOf('}')
            if (a < 0 || b <= a) return -1
            val root = JSONObject(text.substring(a, b + 1))
            val e = Store.prefs(context).edit()
            var n = 0
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                if (k in EXCLUDED) continue
                val o = root.getJSONObject(k)
                when (o.getString("t")) {
                    "b" -> e.putBoolean(k, o.getBoolean("v"))
                    "i" -> e.putInt(k, o.getInt("v"))
                    "l" -> e.putLong(k, o.getLong("v"))
                    "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                    "s" -> e.putString(k, o.getString("v"))
                    "set" -> {
                        val arr = o.getJSONArray("v")
                        e.putStringSet(k, (0 until arr.length()).map { arr.getString(it) }.toSet())
                    }
                    else -> continue
                }
                n++
            }
            e.apply()
            n
        } catch (ex: Exception) { -1 }
    }

    /** Opens Gmail with a ready email to yourself containing the backup. */
    fun sendBackup(context: Context) {
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val body = "$MARK\nKeep this email. To restore: open it, copy this whole message, then in My Deen go to Menu > Account & Backup > Manual backup.\n\n${export(context)}"
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_EMAIL, arrayOf(email(context)))
            putExtra(Intent.EXTRA_SUBJECT, "My Deen backup $day")
            putExtra(Intent.EXTRA_TEXT, body)
        }
        try {
            context.startActivity(Intent(send).setPackage("com.google.android.gm").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            context.startActivity(Intent.createChooser(send, "Send backup").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun clipboardText(context: Context): String {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString() ?: ""
    }
}

@Composable
fun AccountScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf(Account.email(context)) }
    var name by remember { mutableStateOf(Account.name(context)) }
    var phone by remember { mutableStateOf(Account.phone(context)) }
    var phoneInput by remember { mutableStateOf(Account.phone(context)) }
    var pasted by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var lastBackup by remember { mutableLongStateOf(Store.prefs(context).getLong("drive_last", 0L)) }
    var driveOn by remember { mutableStateOf(Store.prefs(context).getBoolean("account_drive", false)) }

    fun refreshState() {
        val p = Store.prefs(context)
        lastBackup = p.getLong("drive_last", 0L)
        driveOn = p.getBoolean("account_drive", false)
    }

    fun turnOnAuto() {
        Store.prefs(context).edit().putBoolean("account_drive", true).apply()
        DriveBackup.schedule(context)
        refreshState()
    }

    fun onToken(token: String) {
        scope.launch {
            val info = withContext(Dispatchers.IO) { DriveBackup.userInfo(token) }
            if (info == null || info.first.isEmpty()) {
                msg = "Couldn’t read your Google account. Please try again."
                busy = false
                return@launch
            }
            Account.signIn(context, info.first, info.second)
            email = Account.email(context)
            name = Account.name(context)
            val remote = withContext(Dispatchers.IO) { DriveBackup.remoteInfo(token) }
            if (remote == null) {
                msg = "Logged in, but Google Drive could not be reached. Check your internet and the Drive setup, then tap Backup now."
            } else if (remote.isEmpty()) {
                val o = withContext(Dispatchers.IO) { DriveBackup.backupNow(context) }
                if (o.ok) turnOnAuto()
                msg = if (o.ok) "Logged in. Your first backup is saved. Automatic backup is on." else o.message
            } else if (!Account.hasLocalData(context)) {
                val o = withContext(Dispatchers.IO) { DriveBackup.restoreNow(context) }
                if (o.ok) turnOnAuto()
                msg = o.message
            } else {
                msg = "Logged in. A backup already exists in your Drive. Tap Restore to load it, or Backup now to replace it with this phone’s data. Automatic backup starts after you choose."
            }
            refreshState()
            busy = false
        }
    }

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        try {
            val r = Identity.getAuthorizationClient(context).getAuthorizationResultFromIntent(res.data)
            val t = r.accessToken
            if (t != null) onToken(t) else { busy = false; msg = "Login cancelled." }
        } catch (e: Exception) {
            busy = false
            msg = "Login cancelled or failed."
        }
    }

    fun login() {
        busy = true
        msg = "Opening Google…"
        DriveBackup.authorize(context)
            .addOnSuccessListener { r ->
                val pi = r.pendingIntent
                if (r.hasResolution() && pi != null) {
                    consent.launch(IntentSenderRequest.Builder(pi).build())
                } else {
                    val t = r.accessToken
                    if (t != null) onToken(t) else { busy = false; msg = "Login failed." }
                }
            }
            .addOnFailureListener {
                busy = false
                msg = "Google login failed (${it.message}). Check the Google Cloud setup: package name and SHA-1."
            }
    }

    fun runBackup() {
        busy = true
        msg = "Saving to Google Drive…"
        scope.launch {
            val o = withContext(Dispatchers.IO) { DriveBackup.backupNow(context) }
            if (o.ok) turnOnAuto()
            msg = o.message
            refreshState()
            busy = false
        }
    }

    fun runRestore() {
        busy = true
        msg = "Loading from Google Drive…"
        scope.launch {
            val o = withContext(Dispatchers.IO) { DriveBackup.restoreNow(context) }
            if (o.ok) turnOnAuto()
            msg = o.message
            refreshState()
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Profile login", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                if (email.isEmpty()) {
                    Text("Login with your Google (Gmail) account. Your data is then saved automatically to your own Google Drive.", style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { login() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Login with Google") }
                } else {
                    if (name.isNotEmpty()) Text(name, style = MaterialTheme.typography.titleMedium)
                    Text(email, style = MaterialTheme.typography.bodyLarge)
                    OutlinedButton(onClick = {
                        Account.signOut(context)
                        email = ""; name = ""; msg = "Logged out. Your data stays on this phone and in your Drive."
                        refreshState()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Logout") }
                }
                if (msg.isNotEmpty()) Text(msg, style = MaterialTheme.typography.bodyMedium)
            }
        }

        DeenCard {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Mobile number", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                OutlinedTextField(
                    value = phoneInput, onValueChange = { phoneInput = it }, singleLine = true,
                    label = { Text("+92 300 1234567") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    val c = Account.cleanPhone(phoneInput)
                    if (c != null) { Account.savePhone(context, c); phone = c; phoneInput = c; msg = "Mobile number saved to your profile." }
                    else msg = "Please enter a valid mobile number (10 to 15 digits)."
                }, modifier = Modifier.fillMaxWidth()) { Text("Save number") }
                if (phone.isNotEmpty()) Text("Saved: $phone (not verified by SMS)", style = MaterialTheme.typography.bodySmall)
            }
        }

        if (email.isNotEmpty()) {
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Google Drive backup", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Text(
                        (if (driveOn) "Automatic backup is ON: saved when you leave the app and once a day." else "Automatic backup is OFF until you backup or restore once.") +
                            "\nLast backup: " + (if (lastBackup > 0L) SimpleDateFormat("d MMM yyyy, h:mm a", Locale.getDefault()).format(Date(lastBackup)) else "never"),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = { runBackup() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Backup now") }
                    OutlinedButton(onClick = { runRestore() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Restore from Drive") }
                    Text("The backup is stored in a private app folder in your Drive.", style = MaterialTheme.typography.bodySmall)
                }
            }
            DeenCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Manual backup (email)", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    OutlinedButton(onClick = { Account.sendBackup(context) }, modifier = Modifier.fillMaxWidth()) { Text("Email backup to myself") }
                    OutlinedTextField(value = pasted, onValueChange = { pasted = it }, label = { Text("Paste emailed backup here") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pasted = Account.clipboardText(context) }) { Text("Paste") }
                        Button(onClick = {
                            val n = Account.restore(context, pasted)
                            msg = if (n >= 0) "Restored $n items. Restart the app to see everything." else "That doesn’t look like a My Deen backup."
                            if (n >= 0) pasted = ""
                        }) { Text("Restore") }
                    }
                }
            }
        }
    }
}
