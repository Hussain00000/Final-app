package com.example.mydeen

data class DailyStatus(val type: String, val arabic: String, val roman: String, val english: String, val source: String)

/** One teaching per day. The list repeats, so every day of the year has a status. */
object DailyStatuses {
    private fun q(roman: String, english: String, source: String, arabic: String = "") =
        DailyStatus("Quran (meaning)", arabic, roman, english, source)
    private fun h(roman: String, english: String, source: String) =
        DailyStatus("Hadees", "", roman, english, source)
    private fun d(arabic: String, roman: String, english: String, source: String) =
        DailyStatus("Dua & Zikr", arabic, roman, english, source)
    private fun r(roman: String, english: String) =
        DailyStatus("Islamic reminder", "", roman, english, "Islamic teaching")

    val all: List<DailyStatus> = listOf(
        q("Beshak mushkil ke saath aasani hai.", "Indeed, with hardship comes ease.", "Quran 94:6", "إِنَّ مَعَ الْعُسْرِ يُسْرًا"),
        h("Jo shakhs kisi musalman ki parda poshi karta hai, Allah duniya aur aakhirat mein uski parda poshi karta hai.", "Whoever conceals a Muslim’s faults, Allah will conceal his faults in this world and the next.", "Sahih Muslim"),
        r("Aaj ek ghalti par sacchi tauba karo aur dobara na karne ka pakka iraada karo.", "Today, sincerely repent for one mistake and resolve not to return to it."),
        q("Tum mujhe yaad karo, main tumhein yaad rakhunga.", "So remember Me; I will remember you.", "Quran 2:152"),
        d("رَبِّ زِدْنِي عِلْمًا", "Ae mere Rab! Mere ilm mein izafa farma.", "My Lord, increase me in knowledge.", "Quran 20:114"),
        h("Allah narm hai aur har kaam mein narmi ko pasand karta hai.", "Allah is gentle and loves gentleness in all matters.", "Bukhari, Muslim"),
        q("Allah kisi par uski taqat se zyada bojh nahi daalta.", "Allah does not burden a soul beyond its capacity.", "Quran 2:286"),
        r("Aaj kisi ek ko khush karo: ek achha lafz, ek tohfa ya ek madad.", "Today, make someone happy with a kind word, a gift or some help."),
        h("Achhi baat bhi sadqa hai.", "A good word is charity.", "Bukhari, Muslim"),
        q("Jo Allah par bharosa karta hai, Allah uske liye kaafi hai.", "Whoever relies on Allah, He is enough for them.", "Quran 65:3"),
        d("حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ", "Humein Allah kaafi hai aur woh behtareen kaarsaaz hai.", "Allah is enough for us, and He is the best disposer of affairs.", "Quran 3:173"),
        h("Jo Allah aur aakhirat par imaan rakhta hai woh apne mehman ki izzat kare.", "Whoever believes in Allah and the Last Day should honour his guest.", "Bukhari, Muslim"),
        q("Sun lo! Allah ke zikr se hi dilon ko sukoon milta hai.", "Surely, in the remembrance of Allah hearts find peace.", "Quran 13:28"),
        r("Aaj apne walidain ke liye dua karo aur unse pyaar se baat karo.", "Today, pray for your parents and speak to them with love."),
        h("Qayamat ke din bande se sab se pehle namaz ka hisaab liya jayega.", "The first thing a servant will be asked about on the Day of Judgement is his prayer.", "Tirmidhi, Nasai"),
        q("Sabr aur namaz ke zariye madad maango.", "Seek help through patience and prayer.", "Quran 2:45"),
        d("لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "Gunah se bachne ki taqat aur neki karne ki quwwat sirf Allah ki madad se hai.", "There is no power and no strength except with Allah.", "Bukhari, Muslim"),
        h("Chugli karne wala Jannat mein dakhil nahi hoga.", "The one who spreads gossip will not enter Paradise.", "Bukhari, Muslim"),
        r("Aaj apni zubaan ki hifazat karo: ghibat, jhoot aur chugli se bacho.", "Today, guard your tongue: avoid backbiting, lies and gossip."),
        q("Allah ki rehmat se na-umeed na ho.", "Do not despair of the mercy of Allah.", "Quran 39:53"),
        h("Jisne achhi tarah wuzu kiya, uske gunah uske jism se nikal jate hain.", "Whoever performs wudu well, his sins come out of his body.", "Sahih Muslim"),
        d("رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", "Ae hamare Rab! Hamein duniya mein bhi bhalai de aur aakhirat mein bhi, aur hamein aag ke azaab se bacha.", "Our Lord, give us good in this world and good in the Hereafter, and protect us from the Fire.", "Quran 2:201"),
        q("Agar tum shukar karoge to main tumhein aur zyada dunga.", "If you are grateful, I will surely give you more.", "Quran 14:7"),
        r("Aaj apni nemton ki list banao aur Allah ka shukar ada karo.", "Today, list your blessings and thank Allah for them."),
        h("Aadmi apne dost ke deen par hota hai, so dekh lo kis se dosti karte ho.", "A person follows the way of his close friend, so be careful who you befriend.", "Abu Dawud, Tirmidhi"),
        q("Mujh se dua maango, main qubool karunga.", "Call upon Me; I will respond to you.", "Quran 40:60"),
        h("Aapas mein salam ko aam karo, is se mohabbat badhti hai.", "Spread salam among yourselves; it increases love.", "Sahih Muslim"),
        d("اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي", "Ae Allah! Tu maaf karne wala hai, maafi ko pasand karta hai, mujhe maaf kar de.", "O Allah, You are Forgiving and love forgiveness, so forgive me.", "Tirmidhi"),
        q("Jo Allah se darta hai, Allah uske liye nikalne ka raasta bana deta hai.", "Whoever fears Allah, He makes a way out for them.", "Quran 65:2"),
        h("Jibreel (AS) mujhe padosi ke baare mein itni taakeed karte rahe ke mujhe laga woh use waris bana denge.", "Jibreel kept advising me about the neighbour until I thought he would make him an heir.", "Bukhari, Muslim"),
        r("Aaj kisi ghareeb ya zaroorat mand ko sadqa do, chahe thoda hi ho.", "Today, give charity to someone in need, even if it is small."),
        q("Neki aur taqwa mein ek doosre ka saath do, gunah aur zyadti mein nahi.", "Help one another in righteousness and piety, not in sin and aggression.", "Quran 5:2"),
        h("Kisi musalman bhai ko haqeer samajhna hi bure hone ke liye kaafi hai.", "It is enough evil for a person to look down on his Muslim brother.", "Sahih Muslim"),
        d("يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ", "Ae dilon ko palatne wale! Mere dil ko apne deen par sabit rakh.", "O Turner of hearts, keep my heart firm upon Your religion.", "Tirmidhi"),
        q("Logon se achhi baat kaho.", "Speak good words to people.", "Quran 2:83"),
        h("Jis ke dil mein zarra barabar takabbur hoga woh Jannat mein dakhil nahi hoga.", "Whoever has an atom’s weight of arrogance in his heart will not enter Paradise.", "Sahih Muslim"),
        r("Aaj har namaz ko awwal waqt par parhne ki koshish karo.", "Today, try to pray every prayer at its earliest time."),
        q("Beshak namaz behayai aur buri baaton se rokti hai.", "Indeed, prayer keeps one away from shameful and evil deeds.", "Quran 29:45"),
        h("Qayamat ke din mizaan mein achhe akhlaq se bhaari koi cheez nahi hogi.", "Nothing will be heavier on the Scale on the Day of Judgement than good character.", "Tirmidhi, Abu Dawud"),
        d("اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ", "Ae Allah! Apne zikr, shukar aur achhi ibadat par meri madad farma.", "O Allah, help me to remember You, thank You and worship You well.", "Abu Dawud, Nasai"),
        q("Apne maa baap ke saath achha sulook karo.", "Be good to your parents.", "Quran 17:23"),
        h("Hayaa imaan ka hissa hai.", "Modesty is a part of faith.", "Bukhari, Muslim"),
        r("Aaj Quran ki kuch ayaat tarjume ke saath parho aur un par ghaur karo.", "Today, read a few verses of the Quran with translation and reflect on them."),
        q("Apne rab se maafi maango, beshak woh bohat maaf karne wala hai.", "Ask forgiveness of your Lord; indeed He is Ever-Forgiving.", "Quran 71:10"),
        h("Jo shakhs din mein sau (100) baar SubhanAllahi wa bihamdihi kahe, uske gunah maaf kar diye jate hain, chahe samandar ke jhaag barabar hon.", "Whoever says SubhanAllahi wa bihamdihi 100 times a day, his sins are forgiven even if they are like the foam of the sea.", "Bukhari, Muslim"),
        d("رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي", "Ae mere Rab! Mera seena khol de aur mera kaam aasaan kar de.", "My Lord, expand my chest and make my task easy for me.", "Quran 20:25-26"),
        q("Allah tauba karne walon aur paak rehne walon ko pasand karta hai.", "Allah loves those who repeatedly repent and those who purify themselves.", "Quran 2:222"),
        h("Momin ka har kaam ajeeb hai: khushi mile to shukar karta hai, takleef pahunche to sabr karta hai, aur dono mein uske liye khair hai.", "How wonderful is the believer’s affair: if good comes he is grateful, if hardship comes he is patient, and both are good for him.", "Sahih Muslim"),
        r("Raat ko sone se pehle din ka muhasaba karo aur istighfar parho.", "Before sleeping, review your day and seek forgiveness."),
        q("Jo zarra barabar bhi neki karega, use dekh lega.", "Whoever does an atom’s weight of good will see it.", "Quran 99:7"),
        h("Tum mein se behtareen woh hai jo apne ghar walon ke liye behtareen ho.", "The best of you is the one who is best to his family.", "Tirmidhi"),
        d("رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ", "Ae mere Rab! Mujhe aur mere walidain ko bakhsh de.", "My Lord, forgive me and my parents.", "Quran 71:28"),
        q("Allah ki rassi ko mazbooti se thaam lo aur aapas mein firqe na bano.", "Hold firmly to the rope of Allah, all together, and do not divide.", "Quran 3:103"),
        h("Jo har farz namaz ke baad Ayat-ul-Kursi parhe, use Jannat mein jaane se sirf maut rokti hai.", "Whoever recites Ayat-ul-Kursi after every obligatory prayer, only death stands between him and Paradise.", "An-Nasai"),
        r("Aaj kisi rishtedaar ko phone ya mulaqat se yaad karo; silah rehmi karo.", "Today, call or visit a relative and keep family ties."),
        q("Beshak Allah sabr karne walon ke saath hai.", "Indeed, Allah is with the patient.", "Quran 2:153"),
        h("Fajr ki do sunnat duniya aur jo kuch us mein hai, sab se behtar hain.", "The two rak’ahs of Fajr are better than this world and all it contains.", "Sahih Muslim"),
        d("أَسْتَغْفِرُ اللَّهَ", "Main Allah se maafi maangta hoon. Rozana istighfar ki aadat daalo.", "I seek forgiveness from Allah. Make istighfar a daily habit.", "Bukhari"),
        q("Allah ihsaan karne walon ko pasand karta hai.", "Allah loves those who do good.", "Quran 2:195"),
        h("Jo subah is haal mein uthe ke jism salamat ho, apni jagah aman mein ho aur uske paas us din ka khana ho, goya use poori duniya mil gayi.", "Whoever wakes up safe in his body, secure in his place, with his day’s food, it is as if the whole world was given to him.", "Tirmidhi, Ibn Majah"),
        r("Aaj ek ghar ki taleem ya Ghar Ghar Mulakhat zaroor karo.", "Today, do a home taleem or a Ghar Ghar Mulakhat visit."),
        d("رَبَّنَا ظَلَمْنَا أَنفُسَنَا وَإِن لَّمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ", "Ae hamare Rab! Hum ne apni jaanon par zulm kiya; agar tu humein maaf na kare aur reham na kare to hum nuqsan uthane walon mein se honge.", "Our Lord, we have wronged ourselves; if You do not forgive us and have mercy on us, we will be among the losers.", "Quran 7:23"),
        q("Apni chaal mein miyana-ravi rakho aur awaaz past rakho.", "Be moderate in your pace and lower your voice.", "Quran 31:19"),
        h("Ek doosre ko tohfa do, aapas mein mohabbat badhegi.", "Give gifts to one another and you will love one another.", "Al-Adab al-Mufrad")
    )

    fun forDay(epochDay: Long): DailyStatus = all[Math.floorMod(epochDay, all.size.toLong()).toInt()]
}
